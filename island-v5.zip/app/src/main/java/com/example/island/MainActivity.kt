package com.example.island

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var accessBadge: TextView? = null
    private var notifBadge: TextView? = null
    private var overlayBadge: TextView? = null
    private var batteryBadge: TextView? = null
    private var blockedCountTv: TextView? = null

    private var islandYSlider: SliderRowView? = null
    private var islandXSlider: SliderRowView? = null
    private var idleWSlider: SliderRowView? = null
    private var idleHSlider: SliderRowView? = null
    private var compWSlider: SliderRowView? = null
    private var compHSlider: SliderRowView? = null
    private var expMarginSlider: SliderRowView? = null
    private var cornerSlider: SliderRowView? = null
    private var presetSelector: SegmentedRowView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = 0xFF090B12.toInt()
        window.navigationBarColor = 0xFF090B12.toInt()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF090B12.toInt())
            isFillViewport = true
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(18f), dp(16f), dp(40f))
        }

        // 1. Hero Header Card
        content.addView(buildHeroCard())

        // 2. Interactive 8-Button Live Preview Playground
        content.addView(buildSectionTitle("LIVE DYNAMIC MOTION PLAYGROUND"))
        content.addView(buildPreviewBarCard())

        // 3. Setup & Permissions Card (Accessibility, Notification Access, Overlay, Battery)
        content.addView(buildSectionTitle("PERMISSIONS & ONE UI SETUP"))
        content.addView(buildSetupCard())

        // 4. Cutout & Geometry Calibration (Galaxy A52s)
        content.addView(buildSectionTitle("CUTOUT & PILL GEOMETRY (GALAXY A52S)"))
        content.addView(buildGeometryCard())

        // 5. Dynamic Motion Spring Physics & Liquid Effects
        content.addView(buildSectionTitle("SPRING PHYSICS & LIQUID METABALLS"))
        content.addView(buildPhysicsCard())

        // 6. All 14 Dynamic Motion Plugins
        content.addView(buildSectionTitle("ISLAND PLUGINS (14 MODULES)"))
        content.addView(buildPluginsCard())

        // 7. Display Rules & Per-App Blocklist
        content.addView(buildSectionTitle("SMART BEHAVIOR & APP BLOCKLIST"))
        content.addView(buildBehaviorAndAppsCard())

        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionBadges()
        refreshBlockedCount()
        notifyPrefsChanged()
    }

    private fun buildHeroCard(): View {
        val heroBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1B1F38.toInt(), 0xFF101324.toInt(), 0xFF0B0D18.toInt())
        ).apply {
            cornerRadius = dpF(24f)
            setStroke(dp(1f), 0x405E5CE6)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = heroBg
            setPadding(dp(20f), dp(22f), dp(20f), dp(22f))
        }

        // Mini Dual-Bubble Preview Graphic
        val pillRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val mainPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedBg(Color.BLACK, dpF(20f), dp(1.5f), 0x885E5CE6.toInt())
            setPadding(dp(12f), 0, dp(12f), 0)
            layoutParams = LinearLayout.LayoutParams(dp(146f), dp(36f))
        }
        val lens = View(this).apply {
            background = roundedBg(0xFF3B66FF.toInt(), dpF(7f))
            layoutParams = LinearLayout.LayoutParams(dp(13f), dp(13f))
        }
        val pillTxt = TextView(this).apply {
            text = "Dynamic v5"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val eq = EqualizerView(this, barCount = 4).apply {
            barColor = 0xFF30D158.toInt()
            isPlaying = true
            layoutParams = LinearLayout.LayoutParams(dp(20f), dp(14f))
        }
        mainPill.addView(lens)
        mainPill.addView(pillTxt)
        mainPill.addView(eq)
        pillRow.addView(mainPill)

        // Detached secondary metaball bubble next to main pill
        val sideBubble = FrameLayout(this).apply {
            background = roundedBg(Color.BLACK, dpF(18f), dp(1.5f), 0x88FF9F0A.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(36f), dp(36f)).apply {
                leftMargin = dp(8f)
            }
            val ic = ControlIconView(this@MainActivity, ControlIconView.KIND_TIMER).apply {
                iconColor = 0xFFFF9F0A.toInt()
                layoutParams = FrameLayout.LayoutParams(dp(18f), dp(18f), Gravity.CENTER)
            }
            addView(ic)
        }
        pillRow.addView(sideBubble)
        box.addView(pillRow)

        val title = TextView(this).apply {
            text = "Island • Dynamic Motion"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 23f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14f) }
        }
        box.addView(title)

        val sub = TextView(this).apply {
            text = "Dual-Window Liquid Metaball Engine • Galaxy A52s Edition"
            setTextColor(0xFF9EA2B8.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(3f) }
        }
        box.addView(sub)

        return box
    }

    private fun buildPreviewBarCard(): View {
        val card = createCardContainer()
        val padBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
        }

        val hint = TextView(this).apply {
            text = "Tap any button to test real animations at the top of your screen (swipe left/right for more):"
            setTextColor(0xFFB4B6C6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        padBox.addView(hint)

        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10f) }
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val previews = listOf(
            Triple("Metaball Split", "metaball", 0xFF5E5CE6.toInt()),
            Triple("Music Card", "music", 0xFF30D158.toInt()),
            Triple("Flashlight Beam", "flashlight", 0xFFFF9F0A.toInt()),
            Triple("Message + Reply", "notif", 0xFF5856D6.toInt()),
            Triple("Maps Nav", "nav", 0xFF28A745.toInt()),
            Triple("Uber Tracker", "uber", 0xFF32ADE6.toInt()),
            Triple("Incoming Call", "call", 0xFFFF453A.toInt()),
            Triple("FaceID Unlock", "lock", 0xFF64D2FF.toInt()),
            Triple("Battery HUD", "battery", 0xFF34C759.toInt())
        )

        previews.forEachIndexed { idx, (label, code, color) ->
            val btn = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                background = roundedBg(color, dpF(12f))
                setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) leftMargin = dp(8f) }
                setOnClickListener { sendPreviewBroadcast(code) }
            }
            row.addView(btn)
        }

        hsv.addView(row)
        padBox.addView(hsv)

        val tip = TextView(this).apply {
            text = "Pro Tip: Swipe DOWN on the idle pill to open your Notification Dock, or LONG-PRESS the idle pill for Quick Actions!"
            setTextColor(0xFF888A9C.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10f) }
        }
        padBox.addView(tip)

        card.addView(padBox)
        return card
    }

    private fun buildSetupCard(): View {
        val card = createCardContainer()

        // 1. Accessibility Service (Recommended like Dynamic Motion for zero-crop status bar & lockscreen overlay)
        val (rowAcc, badgeAcc) = buildPermissionRow(
            title = "1. Accessibility Overlay (Recommended)",
            subtitle = "Used by Dynamic Motion so the pill sits cleanly over the status bar & lock screen without clipping"
        ) {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Throwable) {}
        }
        accessBadge = badgeAcc
        card.addView(rowAcc)
        card.addView(buildDivider())

        // 2. Notification Access
        val (rowNotif, badgeNotif) = buildPermissionRow(
            title = "2. Notification Access (Required)",
            subtitle = "Required to detect messages, music, calls, timers, navigation, and Uber updates"
        ) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Throwable) {}
        }
        notifBadge = badgeNotif
        card.addView(rowNotif)
        card.addView(buildDivider())

        // 3. Display Over Other Apps (Fallback if Accessibility is off)
        val (rowOv, badgeOv) = buildPermissionRow(
            title = "3. Display Over Other Apps",
            subtitle = "Fallback overlay permission so Island works even without Accessibility"
        ) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
        }
        overlayBadge = badgeOv
        card.addView(rowOv)
        card.addView(buildDivider())

        // 4. Unrestricted Battery
        val (rowBat, badgeBat) = buildPermissionRow(
            title = "4. Unrestricted Battery",
            subtitle = "Keeps Samsung One UI from pausing Island in the background"
        ) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Throwable) {
                openAppInfoScreen()
            }
        }
        batteryBadge = badgeBat
        card.addView(rowBat)
        card.addView(buildDivider())

        // Restricted settings helper box
        val helpBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(14f))
        }
        val helpText = TextView(this).apply {
            text = "Android 13 / 14 (Galaxy A52s) Restricted Settings Fix:
If Accessibility or Notification Access is greyed out, tap 'Open App Info' below -> tap the 3 dots (⋮) at top-right -> tap 'Allow restricted settings'."
            setTextColor(0xFF9898A6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        helpBox.addView(helpText)

        val appInfoBtn = TextView(this).apply {
            text = "Open App Info (Allow Restricted Settings)"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF282A38.toInt(), dpF(12f), dp(1f), 0x445E5CE6)
            setPadding(dp(14f), dp(11f), dp(14f), dp(11f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10f) }
            setOnClickListener { openAppInfoScreen() }
        }
        helpBox.addView(appInfoBtn)
        card.addView(helpBox)

        return card
    }

    private fun buildGeometryCard(): View {
        val card = createCardContainer()

        card.addView(
            buildToggleRow(
                title = "Enable Island Overlay",
                subtitle = "Master switch for the Dynamic Island",
                initial = Prefs.isEnabled(this)
            ) {
                Prefs.setEnabled(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Hide When Idle",
                subtitle = "Hide the black pill when nothing is active (turn OFF to keep an always-on pill around the camera hole)",
                initial = Prefs.isHideWhenIdle(this)
            ) {
                Prefs.setHideWhenIdle(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        val ySlider = SliderRowView(
            context = this,
            title = "Vertical Position (Distance from Top Edge)",
            subtitle = "5 dp aligns with the Galaxy A52s camera punch-hole (0 dp touches top screen edge)",
            minVal = 0,
            maxVal = 80,
            initialVal = Prefs.getIslandY(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setIslandY(this, v)
            notifyPrefsChanged()
        }
        islandYSlider = ySlider
        card.addView(ySlider)
        card.addView(buildDivider())

        val xSlider = SliderRowView(
            context = this,
            title = "Horizontal Position (Left / Right)",
            subtitle = "0 dp is dead-center",
            minVal = -80,
            maxVal = 80,
            initialVal = Prefs.getIslandX(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setIslandX(this, v)
            notifyPrefsChanged()
        }
        islandXSlider = xSlider
        card.addView(xSlider)
        card.addView(buildDivider())

        val iwSlider = SliderRowView(
            context = this,
            title = "Idle Pill Width",
            subtitle = "Width of the resting pill around your camera hole",
            minVal = 60,
            maxVal = 180,
            initialVal = Prefs.getIdleWidthDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setIdleWidthDp(this, v)
            notifyPrefsChanged()
        }
        idleWSlider = iwSlider
        card.addView(iwSlider)
        card.addView(buildDivider())

        val ihSlider = SliderRowView(
            context = this,
            title = "Idle Pill Height",
            subtitle = "Height of the resting pill (33 dp matches Dynamic Motion)",
            minVal = 24,
            maxVal = 52,
            initialVal = Prefs.getIdleHeightDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setIdleHeightDp(this, v)
            notifyPrefsChanged()
        }
        idleHSlider = ihSlider
        card.addView(ihSlider)
        card.addView(buildDivider())

        val cwSlider = SliderRowView(
            context = this,
            title = "Compact Active Width",
            subtitle = "Width when showing compact music, timer, or navigation",
            minVal = 120,
            maxVal = 260,
            initialVal = Prefs.getCompactWidthDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setCompactWidthDp(this, v)
            notifyPrefsChanged()
        }
        compWSlider = cwSlider
        card.addView(cwSlider)
        card.addView(buildDivider())

        val chSlider = SliderRowView(
            context = this,
            title = "Compact Active Height",
            subtitle = "Height when showing compact activities",
            minVal = 28,
            maxVal = 54,
            initialVal = Prefs.getCompactHeightDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setCompactHeightDp(this, v)
            notifyPrefsChanged()
        }
        compHSlider = chSlider
        card.addView(chSlider)
        card.addView(buildDivider())

        val emSlider = SliderRowView(
            context = this,
            title = "Expanded Card Side Margin",
            subtitle = "Distance from left/right screen edges when expanded (15 dp default)",
            minVal = 8,
            maxVal = 36,
            initialVal = Prefs.getExpandedMarginDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setExpandedMarginDp(this, v)
            notifyPrefsChanged()
        }
        expMarginSlider = emSlider
        card.addView(emSlider)
        card.addView(buildDivider())

        val crSlider = SliderRowView(
            context = this,
            title = "Pill Corner Roundness",
            subtitle = "Corner radius in dp",
            minVal = 14,
            maxVal = 50,
            initialVal = Prefs.getCornerRadiusDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setCornerRadiusDp(this, v)
            notifyPrefsChanged()
        }
        cornerSlider = crSlider
        card.addView(crSlider)
        card.addView(buildDivider())

        val presetBox = FrameLayout(this).apply {
            setPadding(dp(16f), dp(12f), dp(16f), dp(14f))
        }
        val presetBtn = TextView(this).apply {
            text = "Reset Geometry to Galaxy A52s & Dynamic Motion Defaults"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF5E5CE6.toInt(), dpF(12f))
            setPadding(dp(14f), dp(11f), dp(14f), dp(11f))
            setOnClickListener {
                Prefs.applyGalaxyA52sDefaults(this@MainActivity)
                islandYSlider?.setValue(Prefs.getIslandY(this@MainActivity))
                islandXSlider?.setValue(Prefs.getIslandX(this@MainActivity))
                idleWSlider?.setValue(Prefs.getIdleWidthDp(this@MainActivity))
                idleHSlider?.setValue(Prefs.getIdleHeightDp(this@MainActivity))
                compWSlider?.setValue(Prefs.getCompactWidthDp(this@MainActivity))
                compHSlider?.setValue(Prefs.getCompactHeightDp(this@MainActivity))
                expMarginSlider?.setValue(Prefs.getExpandedMarginDp(this@MainActivity))
                cornerSlider?.setValue(Prefs.getCornerRadiusDp(this@MainActivity))
                presetSelector?.setSelectedIndex(Prefs.getAnimPreset(this@MainActivity))
                notifyPrefsChanged()
                sendPreviewBroadcast("metaball")
                Toast.makeText(this@MainActivity, "Galaxy A52s defaults restored!", Toast.LENGTH_SHORT).show()
            }
        }
        presetBox.addView(presetBtn)
        card.addView(presetBox)

        return card
    }

    private fun buildPhysicsCard(): View {
        val card = createCardContainer()

        val pRow = SegmentedRowView(
            context = this,
            title = "Asymmetric Spring Physics Preset",
            options = listOf("Dynamic Motion", "Liquid Bouncy", "Snappy Pro", "Smooth"),
            initialIndex = Prefs.getAnimPreset(this)
        ) { idx ->
            Prefs.setAnimPreset(this, idx)
            notifyPrefsChanged()
            sendPreviewBroadcast("music")
        }
        presetSelector = pRow
        card.addView(pRow)
        card.addView(buildDivider())

        card.addView(
            SegmentedRowView(
                context = this,
                title = "Accent & Rim Color Palette",
                options = listOf("Auto", "Indigo", "Green", "Coral", "Cyan", "White"),
                initialIndex = Prefs.getAccentMode(this)
            ) { idx ->
                Prefs.setAccentMode(this, idx)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Detached Secondary Metaball Bubble",
                subtitle = "Split off a liquid secondary bubble on the right when Music + Timer/Torch run together",
                initial = Prefs.isDetachedBubble(this)
            ) {
                Prefs.setDetachedBubble(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Liquid Jelly Stretch & Squish",
                subtitle = "Elastic velocity-driven squash & stretch when the pill expands or collapses",
                initial = Prefs.isJellyPhysics(this)
            ) {
                Prefs.setJellyPhysics(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Velocity Motion Blur (RenderEffect)",
                subtitle = "Apply real-time GPU motion blur during high-speed spring transitions",
                initial = Prefs.isBlurEnabled(this)
            ) {
                Prefs.setBlurEnabled(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Ambient Background Glow",
                subtitle = "Soft radial album/app color aura behind the expanded Island",
                initial = Prefs.isMediaGlowEnabled(this)
            ) {
                Prefs.setMediaGlowEnabled(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Neon Rim Stroke",
                subtitle = "Color-matched subtle border around the pill and detached bubble",
                initial = Prefs.isStrokeEnabled(this)
            ) {
                Prefs.setStrokeEnabled(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Tactile Haptic Feedback",
                subtitle = "Crisp vibration tick on expand, collapse, and button presses",
                initial = Prefs.isHaptics(this)
            ) {
                Prefs.setHaptics(this, it)
                notifyPrefsChanged()
            }
        )

        return card
    }

    private fun buildPluginsCard(): View {
        val card = createCardContainer()

        val plugins = listOf(
            Triple("Notifications & Inline Reply", "Compact pill + expanded card with direct keyboard reply & Swipe-Down Dock", Pair(Prefs.isPluginNotif(this)) { v: Boolean -> Prefs.setPluginNotif(this, v) }),
            Triple("Music & Media Session", "Album art, 5-bar harmonic equalizer, draggable seek bar & controls", Pair(Prefs.isPluginMedia(this)) { v: Boolean -> Prefs.setPluginMedia(this, v) }),
            Triple("Phone & VoIP Calls", "Incoming call card with Answer & Decline buttons", Pair(Prefs.isPluginCall(this)) { v: Boolean -> Prefs.setPluginCall(this, v) }),
            Triple("Clock Timers & Stopwatch", "Live countdown timer in pill or detached secondary metaball bubble", Pair(Prefs.isPluginClock(this)) { v: Boolean -> Prefs.setPluginClock(this, v) }),
            Triple("Interactive Flashlight Beam", "Drag horizontally/vertically to adjust beam visual & toggle torch", Pair(Prefs.isPluginFlashlight(this)) { v: Boolean -> Prefs.setPluginFlashlight(this, v) }),
            Triple("Google Maps Navigation", "Live turn-by-turn street direction, distance & ETA card", Pair(Prefs.isPluginNavigation(this)) { v: Boolean -> Prefs.setPluginNavigation(this, v) }),
            Triple("Uber / Delivery Live Tracker", "Live vehicle arrival progress bar & license plate badge", Pair(Prefs.isPluginUber(this)) { v: Boolean -> Prefs.setPluginUber(this, v) }),
            Triple("Lock Screen FaceID Morph", "Animated padlock that unlocks into a green checkmark when you unlock your phone", Pair(Prefs.isPluginLockScreen(this)) { v: Boolean -> Prefs.setPluginLockScreen(this, v) }),
            Triple("Charging & Battery Pill", "iOS-style battery graphic + percentage when plugging in charger", Pair(Prefs.isPluginBattery(this)) { v: Boolean -> Prefs.setPluginBattery(this, v) }),
            Triple("Bluetooth & Headphones HUD", "Connection pill when Galaxy Buds, speakers, or headphones connect", Pair(Prefs.isPluginBluetooth(this)) { v: Boolean -> Prefs.setPluginBluetooth(this, v) }),
            Triple("Ringer & Do Not Disturb HUD", "Visual confirmation when switching Ring / Vibrate / Silent / DND", Pair(Prefs.isPluginDnd(this)) { v: Boolean -> Prefs.setPluginDnd(this, v) }),
            Triple("Mobile Hotspot HUD", "Show active Wi-Fi tethering indicator", Pair(Prefs.isPluginHotspot(this)) { v: Boolean -> Prefs.setPluginHotspot(this, v) }),
            Triple("Screen Recording Controller", "Live REC indicator with one-tap Stop button", Pair(Prefs.isPluginScreenRecord(this)) { v: Boolean -> Prefs.setPluginScreenRecord(this, v) }),
            Triple("Quick-Action Launcher", "Tap or long-press the idle pill to open Torch, Music, Dock & Settings", Pair(Prefs.isPluginCustomLauncher(this)) { v: Boolean -> Prefs.setPluginCustomLauncher(this, v) })
        )

        plugins.forEachIndexed { idx, (title, sub, pair) ->
            if (idx > 0) card.addView(buildDivider())
            card.addView(
                buildToggleRow(title, sub, pair.first) { checked ->
                    pair.second(checked)
                    notifyPrefsChanged()
                }
            )
        }

        return card
    }

    private fun buildBehaviorAndAppsCard(): View {
        val card = createCardContainer()

        card.addView(
            SliderRowView(
                context = this,
                title = "Notification Popup Duration",
                subtitle = "Seconds before a notification automatically collapses",
                minVal = 2,
                maxVal = 15,
                initialVal = Prefs.getNotifDurationSec(this),
                unitSuffix = " s"
            ) { v ->
                Prefs.setNotifDurationSec(this, v)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Auto-Expand Incoming Notifications",
                subtitle = "Open notifications directly into the full card instead of the compact pill first",
                initial = Prefs.isAutoExpandNotif(this)
            ) {
                Prefs.setAutoExpandNotif(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Suppress If App Is Already Open",
                subtitle = "Skip popup if you are already using that exact app in the foreground",
                initial = Prefs.isSuppressWhenAppOpen(this)
            ) {
                Prefs.setSuppressWhenAppOpen(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Hide in Landscape Mode",
                subtitle = "Automatically hide when watching full-screen videos or playing games",
                initial = Prefs.isHideInLandscape(this)
            ) {
                Prefs.setHideInLandscape(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        val appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            isClickable = true
            setOnClickListener { showAppBlocklistDialog() }
        }

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t1 = TextView(this).apply {
            text = "Per-App Notification Blocklist"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val t2 = TextView(this).apply {
            text = "Select apps that should never trigger the Island"
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        textCol.addView(t1)
        textCol.addView(t2)
        appRow.addView(textCol)

        val badge = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF2C2E3E.toInt(), dpF(10f))
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        }
        blockedCountTv = badge
        appRow.addView(badge)
        card.addView(appRow)

        refreshBlockedCount()
        return card
    }

    private fun showAppBlocklistDialog() {
        val pm = packageManager
        val allApps = try {
            pm.getInstalledApplications(0)
                .filter {
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                            pm.getLaunchIntentForPackage(it.packageName) != null
                }
                .filter { it.packageName != packageName }
                .map { info ->
                    val label = try {
                        pm.getApplicationLabel(info).toString()
                    } catch (_: Throwable) {
                        info.packageName
                    }
                    Pair(label, info.packageName)
                }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        } catch (_: Throwable) {
            emptyList()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF151620.toInt())
            setPadding(dp(16f), dp(16f), dp(16f), dp(8f))
        }

        val searchInput = EditText(this).apply {
            hint = "Search installed apps..."
            setHintTextColor(0xFF787884.toInt())
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = roundedBg(0xFF232533.toInt(), dpF(12f))
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            isSingleLine = true
        }
        root.addView(searchInput)

        val listScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(360f)
            ).apply { topMargin = dp(10f) }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        listScroll.addView(listContainer)
        root.addView(listScroll)

        fun populateApps(query: String) {
            listContainer.removeAllViews()
            val q = query.trim().lowercase()
            val filtered = if (q.isEmpty()) allApps else allApps.filter {
                it.first.lowercase().contains(q) || it.second.lowercase().contains(q)
            }
            filtered.take(80).forEach { (label, pkg) ->
                val itemRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(6f), dp(10f), dp(6f), dp(10f))
                }
                val iconIv = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(34f), dp(34f)).apply {
                        rightMargin = dp(12f)
                    }
                    try { setImageDrawable(pm.getApplicationIcon(pkg)) } catch (_: Throwable) {}
                }
                val nameCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val n1 = TextView(this).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                    maxLines = 1
                }
                val n2 = TextView(this).apply {
                    text = pkg
                    setTextColor(0xFF80808C.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    maxLines = 1
                }
                nameCol.addView(n1)
                nameCol.addView(n2)

                val toggle = ToggleView(this).apply {
                    activeColor = 0xFFFF453A.toInt()
                    setChecked(Prefs.isAppBlocked(this@MainActivity, pkg), animate = false)
                    onChanged = {
                        Prefs.toggleAppBlocked(this@MainActivity, pkg)
                        refreshBlockedCount()
                        notifyPrefsChanged()
                    }
                }
                itemRow.addView(iconIv)
                itemRow.addView(nameCol)
                itemRow.addView(toggle)
                listContainer.addView(itemRow)
            }
        }

        populateApps("")
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                populateApps(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Block Apps from Island (Red = Blocked)")
            .setView(root)
            .setPositiveButton("Done") { d, _ -> d.dismiss() }
            .show()
    }

    private fun buildSectionTitle(label: String): View {
        return TextView(this).apply {
            text = label
            setTextColor(0xFF7C7F94.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = 0.08f
            setPadding(dp(6f), dp(20f), dp(6f), dp(8f))
        }
    }

    private fun createCardContainer(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(0xFF141622.toInt(), dpF(18f), dp(1f), 0x1AFFFFFF)
        }
    }

    private fun buildDivider(): View {
        return View(this).apply {
            setBackgroundColor(0x16FFFFFF)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                1
            ).apply {
                leftMargin = dp(16f)
                rightMargin = dp(16f)
            }
        }
    }

    private fun buildToggleRow(
        title: String,
        subtitle: String,
        initial: Boolean,
        onToggle: (Boolean) -> Unit
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(13f), dp(16f), dp(13f))
        }

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(12f)
            }
        }

        val t1 = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val t2 = TextView(this).apply {
            text = subtitle
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        textCol.addView(t1)
        textCol.addView(t2)
        row.addView(textCol)

        val toggle = ToggleView(this).apply {
            setChecked(initial, animate = false)
            onChanged = onToggle
        }
        row.addView(toggle)

        row.setOnClickListener {
            val next = !toggle.isChecked
            toggle.setChecked(next, animate = true)
            onToggle(next)
        }
        return row
    }

    private fun buildPermissionRow(
        title: String,
        subtitle: String,
        onClick: () -> Unit
    ): Pair<View, TextView> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            isClickable = true
            setOnClickListener { onClick() }
        }

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(10f)
            }
        }

        val t1 = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val t2 = TextView(this).apply {
            text = subtitle
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        textCol.addView(t1)
        textCol.addView(t2)
        row.addView(textCol)

        val badge = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        }
        row.addView(badge)
        return Pair(row, badge)
    }

    private fun refreshPermissionBadges() {
        val hasAcc = isAccessibilityServiceEnabled()
        styleBadge(accessBadge, hasAcc, if (hasAcc) "ON" else "ENABLE")

        val hasNotif = isNotificationServiceEnabled()
        styleBadge(notifBadge, hasNotif, if (hasNotif) "ON" else "ENABLE")

        val hasOverlay = Settings.canDrawOverlays(this)
        styleBadge(overlayBadge, hasOverlay, if (hasOverlay) "ON" else "ENABLE")

        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val hasBattery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        styleBadge(batteryBadge, hasBattery, if (hasBattery) "ON" else "FIX")
    }

    private fun styleBadge(tv: TextView?, ok: Boolean, label: String) {
        tv ?: return
        tv.text = label
        if (ok) {
            tv.setTextColor(0xFF30D158.toInt())
            tv.background = roundedBg(0x2430D158, dpF(10f), dp(1f), 0x6630D158)
        } else {
            tv.setTextColor(Color.WHITE)
            tv.background = roundedBg(0xFF5E5CE6.toInt(), dpF(10f))
        }
    }

    private fun refreshBlockedCount() {
        val count = Prefs.getBlockedApps(this).size
        blockedCountTv?.text = if (count == 0) "0 Blocked" else "$count Blocked"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        if (IslandAccessibilityService.getInstance() != null) return true
        val flat = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return flat.contains(packageName, ignoreCase = true)
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val myComp = ComponentName(this, IslandListenerService::class.java).flattenToString()
        return flat.split(":").any { it.equals(myComp, ignoreCase = true) }
    }

    private fun openAppInfoScreen() {
        try {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (_: Throwable) {}
    }

    private fun notifyPrefsChanged() {
        val intent = Intent(Prefs.ACTION_PREFS_CHANGED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun sendPreviewBroadcast(kind: String) {
        val canDraw = isAccessibilityServiceEnabled() || Settings.canDrawOverlays(this)
        if (!canDraw) {
            Toast.makeText(
                this,
                "Please enable '1. Accessibility Overlay' or '3. Display Over Other Apps' first!",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (!isNotificationServiceEnabled()) {
            Toast.makeText(
                this,
                "Please enable '2. Notification Access' first so the Island engine starts!",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val intent = Intent(Prefs.ACTION_PREVIEW).apply {
            setPackage(packageName)
            putExtra(Prefs.EXTRA_PREVIEW_TYPE, kind)
        }
        sendBroadcast(intent)
    }
}
