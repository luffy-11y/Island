package com.example.island

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE_NAME = "island_prefs"

    const val ACTION_PREFS_CHANGED = "com.example.island.ACTION_PREFS_CHANGED"
    const val ACTION_PREVIEW = "com.example.island.ACTION_PREVIEW"
    const val EXTRA_PREVIEW_TYPE = "preview_type"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    // Master & Idle Behavior
    fun isEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("enabled", true)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("enabled", v).apply()

    fun isHideWhenIdle(ctx: Context): Boolean = sp(ctx).getBoolean("hide_when_idle", false)
    fun setHideWhenIdle(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_when_idle", v).apply()

    fun isShowAsNotch(ctx: Context): Boolean = sp(ctx).getBoolean("show_as_notch", false)
    fun setShowAsNotch(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("show_as_notch", v).apply()

    // Cutout & Geometry (Dynamic Motion coordinate system: positive Y from top of screen)
    // Galaxy A52s camera punch-hole sits ~5 dp from the top edge, width 96 dp, height 33 dp
    fun getIslandY(ctx: Context): Int = sp(ctx).getInt("island_y", 5)
    fun setIslandY(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_y", v.coerceIn(0, 80)).apply()

    fun getIslandX(ctx: Context): Int = sp(ctx).getInt("island_x", 0)
    fun setIslandX(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_x", v.coerceIn(-80, 80)).apply()

    fun getIdleWidthDp(ctx: Context): Int = sp(ctx).getInt("island_width", 96)
    fun setIdleWidthDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_width", v.coerceIn(60, 180)).apply()

    fun getIdleHeightDp(ctx: Context): Int = sp(ctx).getInt("island_height", 33)
    fun setIdleHeightDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_height", v.coerceIn(24, 52)).apply()

    fun getCompactWidthDp(ctx: Context): Int = sp(ctx).getInt("island_compact_width", 168)
    fun setCompactWidthDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_compact_width", v.coerceIn(120, 260)).apply()

    fun getCompactHeightDp(ctx: Context): Int = sp(ctx).getInt("island_compact_height", 36)
    fun setCompactHeightDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_compact_height", v.coerceIn(28, 54)).apply()

    fun getExpandedMarginDp(ctx: Context): Int = sp(ctx).getInt("island_expanded_margin", 15)
    fun setExpandedMarginDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_expanded_margin", v.coerceIn(8, 36)).apply()

    fun getCornerRadiusDp(ctx: Context): Int = sp(ctx).getInt("island_corner_radius", 35)
    fun setCornerRadiusDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_corner_radius", v.coerceIn(14, 50)).apply()

    fun getExpandedCornerRadiusDp(ctx: Context): Int = sp(ctx).getInt("island_corner_radius_expanded", 36)
    fun setExpandedCornerRadiusDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("island_corner_radius_expanded", v.coerceIn(18, 54)).apply()

    // Dynamic Motion Asymmetric Spring Physics & Motion Blur
    // Presets: 0 = Dynamic Motion (Default), 1 = Liquid Bouncy, 2 = Snappy Pro, 3 = Ultra Smooth
    fun getAnimPreset(ctx: Context): Int = sp(ctx).getInt("anim_preset", 0)
    fun setAnimPreset(ctx: Context, v: Int) {
        val p = v.coerceIn(0, 3)
        val ed = sp(ctx).edit().putInt("anim_preset", p)
        when (p) {
            0 -> { // Dynamic Motion exact calibrated values
                ed.putFloat("anim_expand_width_damping", 0.76f)
                ed.putFloat("anim_expand_height_damping", 0.72f)
                ed.putFloat("anim_expand_width_stiffness", 209f)
                ed.putFloat("anim_expand_height_stiffness", 208f)
                ed.putFloat("anim_collapse_width_damping", 0.59f)
                ed.putFloat("anim_collapse_height_damping", 0.59f)
                ed.putFloat("anim_collapse_width_stiffness", 105f)
                ed.putFloat("anim_collapse_height_stiffness", 115f)
                ed.putInt("anim_expand_height_delay_ms", 38)
            }
            1 -> { // Liquid Bouncy
                ed.putFloat("anim_expand_width_damping", 0.56f)
                ed.putFloat("anim_expand_height_damping", 0.58f)
                ed.putFloat("anim_expand_width_stiffness", 230f)
                ed.putFloat("anim_expand_height_stiffness", 220f)
                ed.putFloat("anim_collapse_width_damping", 0.52f)
                ed.putFloat("anim_collapse_height_damping", 0.54f)
                ed.putFloat("anim_collapse_width_stiffness", 125f)
                ed.putFloat("anim_collapse_height_stiffness", 135f)
                ed.putInt("anim_expand_height_delay_ms", 42)
            }
            2 -> { // Snappy Pro
                ed.putFloat("anim_expand_width_damping", 0.84f)
                ed.putFloat("anim_expand_height_damping", 0.84f)
                ed.putFloat("anim_expand_width_stiffness", 380f)
                ed.putFloat("anim_expand_height_stiffness", 390f)
                ed.putFloat("anim_collapse_width_damping", 0.78f)
                ed.putFloat("anim_collapse_height_damping", 0.80f)
                ed.putFloat("anim_collapse_width_stiffness", 290f)
                ed.putFloat("anim_collapse_height_stiffness", 310f)
                ed.putInt("anim_expand_height_delay_ms", 18)
            }
            3 -> { // Ultra Smooth
                ed.putFloat("anim_expand_width_damping", 0.90f)
                ed.putFloat("anim_expand_height_damping", 0.90f)
                ed.putFloat("anim_expand_width_stiffness", 170f)
                ed.putFloat("anim_expand_height_stiffness", 170f)
                ed.putFloat("anim_collapse_width_damping", 0.82f)
                ed.putFloat("anim_collapse_height_damping", 0.82f)
                ed.putFloat("anim_collapse_width_stiffness", 140f)
                ed.putFloat("anim_collapse_height_stiffness", 145f)
                ed.putInt("anim_expand_height_delay_ms", 25)
            }
        }
        ed.apply()
    }

    fun getExpandWidthDamping(ctx: Context): Float = sp(ctx).getFloat("anim_expand_width_damping", 0.76f)
    fun getExpandHeightDamping(ctx: Context): Float = sp(ctx).getFloat("anim_expand_height_damping", 0.72f)
    fun getExpandWidthStiffness(ctx: Context): Float = sp(ctx).getFloat("anim_expand_width_stiffness", 209f)
    fun getExpandHeightStiffness(ctx: Context): Float = sp(ctx).getFloat("anim_expand_height_stiffness", 208f)
    fun getExpandHeightDelayMs(ctx: Context): Long = sp(ctx).getInt("anim_expand_height_delay_ms", 38).toLong()

    fun getCollapseWidthDamping(ctx: Context): Float = sp(ctx).getFloat("anim_collapse_width_damping", 0.59f)
    fun getCollapseHeightDamping(ctx: Context): Float = sp(ctx).getFloat("anim_collapse_height_damping", 0.59f)
    fun getCollapseWidthStiffness(ctx: Context): Float = sp(ctx).getFloat("anim_collapse_width_stiffness", 105f)
    fun getCollapseHeightStiffness(ctx: Context): Float = sp(ctx).getFloat("anim_collapse_height_stiffness", 115f)

    fun isBlurEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("blur_enabled", true)
    fun setBlurEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("blur_enabled", v).apply()

    fun isJellyPhysics(ctx: Context): Boolean = sp(ctx).getBoolean("jelly_physics", true)
    fun setJellyPhysics(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("jelly_physics", v).apply()

    fun isDetachedBubble(ctx: Context): Boolean = sp(ctx).getBoolean("bubble_ios_behavior", true)
    fun setDetachedBubble(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("bubble_ios_behavior", v).apply()

    fun isStrokeEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("island_stroke_enabled", true)
    fun setStrokeEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("island_stroke_enabled", v).apply()

    fun isMediaGlowEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("media_glow_enabled", true)
    fun setMediaGlowEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("media_glow_enabled", v).apply()

    fun isHaptics(ctx: Context): Boolean = sp(ctx).getBoolean("haptics", true)
    fun setHaptics(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("haptics", v).apply()

    // 14 Dynamic Motion Plugins
    fun isPluginNotif(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_notification_enabled", true)
    fun setPluginNotif(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_notification_enabled", v).apply()

    fun isPluginMedia(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_media_enabled", true)
    fun setPluginMedia(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_media_enabled", v).apply()

    fun isPluginCall(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_call_enabled", true)
    fun setPluginCall(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_call_enabled", v).apply()

    fun isPluginClock(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_clock_enabled", true)
    fun setPluginClock(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_clock_enabled", v).apply()

    fun isPluginNavigation(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_navigation_enabled", true)
    fun setPluginNavigation(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_navigation_enabled", v).apply()

    fun isPluginUber(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_uber_enabled", true)
    fun setPluginUber(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_uber_enabled", v).apply()

    fun isPluginFlashlight(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_flashlight_enabled", true)
    fun setPluginFlashlight(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_flashlight_enabled", v).apply()

    fun isPluginLockScreen(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_lock_screen_enabled", true)
    fun setPluginLockScreen(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_lock_screen_enabled", v).apply()

    fun isPluginBattery(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_battery_enabled", true)
    fun setPluginBattery(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_battery_enabled", v).apply()

    fun isPluginBluetooth(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_bluetooth_enabled", true)
    fun setPluginBluetooth(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_bluetooth_enabled", v).apply()

    fun isPluginDnd(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_dnd_enabled", true)
    fun setPluginDnd(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_dnd_enabled", v).apply()

    fun isPluginHotspot(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_hotspot_enabled", true)
    fun setPluginHotspot(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_hotspot_enabled", v).apply()

    fun isPluginScreenRecord(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_screen_record_enabled", true)
    fun setPluginScreenRecord(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_screen_record_enabled", v).apply()

    fun isPluginCustomLauncher(ctx: Context): Boolean = sp(ctx).getBoolean("plugin_custom_enabled", true)
    fun setPluginCustomLauncher(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("plugin_custom_enabled", v).apply()

    // Display & Behavior Options
    fun getNotifDurationSec(ctx: Context): Int = sp(ctx).getInt("notification_duration_sec", 5)
    fun setNotifDurationSec(ctx: Context, v: Int) = sp(ctx).edit().putInt("notification_duration_sec", v.coerceIn(2, 15)).apply()

    fun isAutoExpandNotif(ctx: Context): Boolean = sp(ctx).getBoolean("auto_expand_notif", false)
    fun setAutoExpandNotif(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("auto_expand_notif", v).apply()

    fun isHideInLandscape(ctx: Context): Boolean = sp(ctx).getBoolean("hide_in_landscape", true)
    fun setHideInLandscape(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_in_landscape", v).apply()

    fun isSuppressWhenAppOpen(ctx: Context): Boolean = sp(ctx).getBoolean("suppress_when_app_open", true)
    fun setSuppressWhenAppOpen(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("suppress_when_app_open", v).apply()

    fun getAccentMode(ctx: Context): Int = sp(ctx).getInt("accent_mode", 0)
    fun setAccentMode(ctx: Context, v: Int) = sp(ctx).edit().putInt("accent_mode", v.coerceIn(0, 5)).apply()

    // Per-App Blocklist
    fun getBlockedApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("blocked_apps", emptySet()) ?: emptySet()

    fun isAppBlocked(ctx: Context, pkg: String): Boolean =
        getBlockedApps(ctx).contains(pkg)

    fun toggleAppBlocked(ctx: Context, pkg: String): Boolean {
        val current = getBlockedApps(ctx).toMutableSet()
        val nowBlocked = if (current.contains(pkg)) {
            current.remove(pkg)
            false
        } else {
            current.add(pkg)
            true
        }
        sp(ctx).edit().putStringSet("blocked_apps", current).apply()
        return nowBlocked
    }

    fun resolveAccentColor(ctx: Context, dynamicColor: Int): Int {
        return when (getAccentMode(ctx)) {
            0 -> dynamicColor
            1 -> 0xFF5E5CE6.toInt() // iOS Indigo
            2 -> 0xFF30D158.toInt() // Neon Green
            3 -> 0xFFFF6B6B.toInt() // Coral
            4 -> 0xFF32ADE6.toInt() // Cyan
            5 -> 0xFFFFFFFF.toInt() // White
            else -> dynamicColor
        }
    }

    fun applyGalaxyA52sDefaults(ctx: Context) {
        sp(ctx).edit()
            .putInt("island_y", 5)
            .putInt("island_x", 0)
            .putInt("island_width", 96)
            .putInt("island_height", 33)
            .putInt("island_compact_width", 168)
            .putInt("island_compact_height", 36)
            .putInt("island_expanded_margin", 15)
            .putInt("island_corner_radius", 35)
            .putInt("island_corner_radius_expanded", 36)
            .putBoolean("bubble_ios_behavior", true)
            .putBoolean("jelly_physics", true)
            .putBoolean("blur_enabled", true)
            .putBoolean("island_stroke_enabled", true)
            .putBoolean("media_glow_enabled", true)
            .apply()
        setAnimPreset(ctx, 0)
    }
}
