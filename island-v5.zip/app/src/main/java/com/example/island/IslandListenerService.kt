package com.example.island

import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class IslandListenerService : NotificationListenerService() {

    enum class Mode {
        HIDDEN,
        IDLE_PILL,
        LOCK_COMPACT,
        MEDIA_SMALL,
        MEDIA_BIG,
        TIMER_SMALL,
        TIMER_BIG,
        FLASHLIGHT_SMALL,
        FLASHLIGHT_BIG,
        NAV_SMALL,
        NAV_BIG,
        UBER_SMALL,
        UBER_BIG,
        RECORD_SMALL,
        RECORD_BIG,
        NOTIF_COMPACT,
        NOTIF_EXPANDED,
        NOTIF_DOCK,
        CALL,
        SYSTEM_HUD,
        QUICK_LAUNCHER
    }

    data class ActionBtn(
        val label: String,
        val intent: PendingIntent?,
        val remoteInputs: Array<RemoteInput>? = null,
        val isPositive: Boolean = false,
        val isNegative: Boolean = false
    )

    data class IslandItem(
        val key: String,
        val pkg: String,
        val appName: String,
        val title: String,
        val text: String,
        val subText: String,
        val icon: Drawable?,
        val largeBitmap: Bitmap?,
        val contentIntent: PendingIntent?,
        val actions: List<ActionBtn>,
        val isCall: Boolean,
        val isTimer: Boolean,
        val isNav: Boolean,
        val isRide: Boolean,
        val isScreenRecord: Boolean,
        val progressPct: Int,
        val chronometerBase: Long,
        val chronometerCountDown: Boolean,
        val whenMs: Long,
        val durationMs: Long,
        val accentColor: Int
    )

    data class SystemHudData(
        val title: String,
        val subtitle: String,
        val badgeText: String,
        val accentColor: Int,
        val hudKind: Int, // 0=battery, 1=bt, 2=ringer, 3=dnd, 4=hotspot
        val batteryLevel: Int = 85,
        val isCharging: Boolean = true,
        val iconKind: Int = ControlIconView.KIND_RINGER_NORMAL
    )

    private val handler = Handler(Looper.getMainLooper())

    // Dual-Window Architecture (matching Dynamic Motion's OverlayService)
    private var wm: WindowManager? = null
    private var usingAccessibilityWindow = false
    private var visualHostView: LiquidIslandHostView? = null
    private var visualLp: WindowManager.LayoutParams? = null
    private var touchWindowView: FrameLayout? = null
    private var touchLp: WindowManager.LayoutParams? = null
    private var windowsAttached = false
    private var touchFocusable = false
    private val tempBounds = Rect()

    // Spring Physics Controllers
    private var currentMode: Mode = Mode.HIDDEN
    private var animWidthPx: Float = 0f
    private var animHeightPx: Float = 0f
    private var animCornerPx: Float = 0f
    private var animBubbleProgress: Float = 0f
    private var velWidth: Float = 0f
    private var velHeight: Float = 0f

    private var widthSpring: SpringAnimation? = null
    private var heightSpring: SpringAnimation? = null
    private var cornerSpring: SpringAnimation? = null
    private var bubbleSpring: SpringAnimation? = null
    private var pressSpring: SpringAnimation? = null
    private var pendingHeightRunnable: Runnable? = null

    // State & Queues
    private val notifQueue = ArrayDeque<IslandItem>()
    private val notifHistory = ArrayDeque<IslandItem>() // For Swipe-Down Notification Dock
    private var activeItem: IslandItem? = null
    private val recentSignatures = HashMap<String, Long>()

    private var activeTimerItem: IslandItem? = null
    private var activeNavItem: IslandItem? = null
    private var activeRideItem: IslandItem? = null
    private var activeRecordItem: IslandItem? = null
    private var activeHud: SystemHudData? = null
    private var lastChargingState: Boolean? = null

    // Flashlight / Torch Controller
    private var cameraManager: CameraManager? = null
    private var cameraId: String? = null
    private var isTorchActive: Boolean = false
    private var torchIntensity: Float = 0.85f
    private var torchSpread: Float = 0.65f
    private var torchDismissed: Boolean = false

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(camId: String, enabled: Boolean) {
            super.onTorchModeChanged(camId, enabled)
            if (cameraId == null) cameraId = camId
            val changed = isTorchActive != enabled
            isTorchActive = enabled
            if (!enabled) torchDismissed = false
            if (changed && Prefs.isPluginFlashlight(this@IslandListenerService)) {
                hapticTick()
                decideNextState(forceRebuild = true)
            }
        }
    }

    // Lock Screen State
    private var isKeyguardLocked: Boolean = false
    private var lockMorphView: LockMorphView? = null

    // Media Session State
    private var mediaSessionManager: MediaSessionManager? = null
    private var activeController: MediaController? = null
    private var mediaTitle: String = ""
    private var mediaArtist: String = ""
    private var mediaArt: Bitmap? = null
    private var mediaAccent: Int = 0xFF30D158.toInt()
    private var mediaPlaying: Boolean = false
    private var mediaDuration: Long = 0L
    private var mediaPosition: Long = 0L
    private var mediaLastStateTime: Long = 0L
    private var mediaDismissedUntilChange: Boolean = false
    private var lastTrackSignature: String = ""

    // Live UI references
    private var liveSeekLine: ProgressLine? = null
    private var liveElapsedTv: TextView? = null
    private var liveTotalTv: TextView? = null
    private var liveEqualizerSmall: EqualizerView? = null
    private var liveEqualizerBig: EqualizerView? = null
    private var livePlayPauseIcon: ControlIconView? = null
    private var liveTimerTv: TextView? = null
    private var liveBubbleTimerTv: TextView? = null
    private var spinAnimator: ValueAnimator? = null

    // Scheduled Runnables
    private val autoDismissRunnable = Runnable { onItemTimeout() }
    private val mediaCollapseRunnable = Runnable {
        if (currentMode == Mode.MEDIA_BIG || currentMode == Mode.TIMER_BIG ||
            currentMode == Mode.FLASHLIGHT_BIG || currentMode == Mode.NAV_BIG ||
            currentMode == Mode.UBER_BIG || currentMode == Mode.RECORD_BIG ||
            currentMode == Mode.QUICK_LAUNCHER
        ) {
            setTouchWindowFocusable(false)
            decideNextState(forceRebuild = true)
        }
    }
    private val mediaPauseHideRunnable = Runnable {
        if (!mediaPlaying && (currentMode == Mode.MEDIA_SMALL || currentMode == Mode.MEDIA_BIG)) {
            decideNextState()
        }
    }
    private val hudHideRunnable = Runnable {
        activeHud = null
        decideNextState()
    }
    private val lockHideRunnable = Runnable {
        if (currentMode == Mode.LOCK_COMPACT) {
            isKeyguardLocked = false
            decideNextState()
        }
    }
    private val tickerRunnable = object : Runnable {
        override fun run() {
            updateLiveTickers()
            if (windowsAttached && currentMode != Mode.HIDDEN) {
                handler.postDelayed(this, 500L)
            }
        }
    }

    private val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
        bindMediaControllers(controllers)
    }

    private val mediaCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            readMediaState()
        }
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMediaState()
        }
    }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            when (action) {
                Prefs.ACTION_PREFS_CHANGED -> {
                    checkWindowHostContext()
                    decideNextState(forceRebuild = true)
                }
                Prefs.ACTION_PREVIEW -> {
                    val kind = intent.getStringExtra(Prefs.EXTRA_PREVIEW_TYPE) ?: "notif"
                    triggerPreview(kind)
                }
                Intent.ACTION_SCREEN_OFF -> {
                    if (Prefs.isPluginLockScreen(this@IslandListenerService)) {
                        isKeyguardLocked = true
                    }
                }
                Intent.ACTION_SCREEN_ON -> {
                    if (!Prefs.isPluginLockScreen(this@IslandListenerService)) return
                    val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                    if (km?.isKeyguardLocked == true) {
                        isKeyguardLocked = true
                        transitionToMode(Mode.LOCK_COMPACT, forceRebuild = true)
                        handler.removeCallbacks(lockHideRunnable)
                        handler.postDelayed(lockHideRunnable, 4_500L)
                    }
                }
                Intent.ACTION_USER_PRESENT -> {
                    if (!Prefs.isPluginLockScreen(this@IslandListenerService)) return
                    isKeyguardLocked = false
                    if (currentMode == Mode.LOCK_COMPACT) {
                        lockMorphView?.animateUnlock()
                        hapticTick()
                        handler.removeCallbacks(lockHideRunnable)
                        handler.postDelayed(lockHideRunnable, 1_400L)
                    } else {
                        showSystemHud(
                            SystemHudData(
                                title = "Unlocked",
                                subtitle = "Face / Biometric Verified",
                                badgeText = "OK",
                                accentColor = 0xFF30D158.toInt(),
                                hudKind = 2,
                                iconKind = ControlIconView.KIND_RINGER_NORMAL
                            )
                        )
                    }
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    if (!Prefs.isPluginBattery(this@IslandListenerService)) return
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                    val pct = (level * 100) / scale
                    if (lastChargingState == null) {
                        lastChargingState = charging
                    } else if (lastChargingState != charging) {
                        lastChargingState = charging
                        if (charging) {
                            showSystemHud(
                                SystemHudData(
                                    title = "Charging",
                                    subtitle = if (pct >= 99) "Full Battery" else "Super Fast Charging",
                                    badgeText = "$pct%",
                                    accentColor = 0xFF30D158.toInt(),
                                    hudKind = 0,
                                    batteryLevel = pct,
                                    isCharging = true
                                )
                            )
                        }
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    if (!Prefs.isPluginBluetooth(this@IslandListenerService)) return
                    val devName = try {
                        val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        dev?.name ?: "Galaxy Buds"
                    } catch (_: Throwable) {
                        "Bluetooth Audio"
                    }
                    showSystemHud(
                        SystemHudData(
                            title = devName,
                            subtitle = "Bluetooth Connected",
                            badgeText = "BT",
                            accentColor = 0xFF32ADE6.toInt(),
                            hudKind = 1,
                            iconKind = ControlIconView.KIND_BT
                        )
                    )
                }
                Intent.ACTION_HEADSET_PLUG -> {
                    if (!Prefs.isPluginBluetooth(this@IslandListenerService) || isInitialStickyBroadcast) return
                    if (intent.getIntExtra("state", 0) == 1) {
                        showSystemHud(
                            SystemHudData(
                                title = "Headphones",
                                subtitle = "3.5mm Audio Jack Connected",
                                badgeText = "AUX",
                                accentColor = 0xFF32ADE6.toInt(),
                                hudKind = 1,
                                iconKind = ControlIconView.KIND_BT
                            )
                        )
                    }
                }
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    if (!Prefs.isPluginDnd(this@IslandListenerService) || isInitialStickyBroadcast) return
                    val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                    when (am.ringerMode) {
                        AudioManager.RINGER_MODE_SILENT -> showSystemHud(
                            SystemHudData(
                                title = "Silent",
                                subtitle = "Calls & Alerts Muted",
                                badgeText = "MUTE",
                                accentColor = 0xFFFF453A.toInt(),
                                hudKind = 2,
                                iconKind = ControlIconView.KIND_RINGER_SILENT
                            )
                        )
                        AudioManager.RINGER_MODE_VIBRATE -> showSystemHud(
                            SystemHudData(
                                title = "Vibrate",
                                subtitle = "Haptics Only",
                                badgeText = "VIB",
                                accentColor = 0xFFFF9F0A.toInt(),
                                hudKind = 2,
                                iconKind = ControlIconView.KIND_RINGER_VIBRATE
                            )
                        )
                        AudioManager.RINGER_MODE_NORMAL -> showSystemHud(
                            SystemHudData(
                                title = "Ring",
                                subtitle = "Sound Active",
                                badgeText = "RING",
                                accentColor = 0xFF30D158.toInt(),
                                hudKind = 2,
                                iconKind = ControlIconView.KIND_RINGER_NORMAL
                            )
                        )
                    }
                }
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    if (!Prefs.isPluginDnd(this@IslandListenerService)) return
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
                    val dndOn = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
                    showSystemHud(
                        SystemHudData(
                            title = if (dndOn) "Do Not Disturb" else "Focus Off",
                            subtitle = if (dndOn) "Notifications Silenced" else "Alerts Restored",
                            badgeText = if (dndOn) "DND" else "ON",
                            accentColor = 0xFF5E5CE6.toInt(),
                            hudKind = 3,
                            iconKind = ControlIconView.KIND_DND_MOON
                        )
                    )
                }
                "android.net.wifi.WIFI_AP_STATE_CHANGED" -> {
                    if (!Prefs.isPluginHotspot(this@IslandListenerService) || isInitialStickyBroadcast) return
                    val state = intent.getIntExtra("wifi_state", 0)
                    // 13 = WIFI_AP_STATE_ENABLED
                    if (state == 13) {
                        showSystemHud(
                            SystemHudData(
                                title = "Mobile Hotspot",
                                subtitle = "Wi-Fi Sharing Active",
                                badgeText = "AP",
                                accentColor = 0xFF30D158.toInt(),
                                hudKind = 4,
                                iconKind = ControlIconView.KIND_HOTSPOT
                            )
                        )
                    }
                }
                Intent.ACTION_CONFIGURATION_CHANGED -> {
                    decideNextState(forceRebuild = true)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerReceivers()
        setupTorchController()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        setupMediaSessions()
        seedExistingNotifications()
        decideNextState(forceRebuild = true)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(systemReceiver) } catch (_: Throwable) {}
        try { cameraManager?.unregisterTorchCallback(torchCallback) } catch (_: Throwable) {}
        try {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(sessionListener)
            activeController?.unregisterCallback(mediaCallback)
        } catch (_: Throwable) {}
        removeOverlayWindows()
        super.onDestroy()
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(Prefs.ACTION_PREFS_CHANGED)
            addAction(Prefs.ACTION_PREVIEW)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction(Intent.ACTION_CONFIGURATION_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(systemReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(systemReceiver, filter)
        }
    }

    private fun setupTorchController() {
        try {
            cameraManager = getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            cameraId = cameraManager?.cameraIdList?.firstOrNull()
            cameraManager?.registerTorchCallback(torchCallback, handler)
        } catch (_: Throwable) {}
    }

    private fun toggleHardwareTorch(enable: Boolean) {
        try {
            val id = cameraId ?: cameraManager?.cameraIdList?.firstOrNull() ?: return
            cameraManager?.setTorchMode(id, enable)
            isTorchActive = enable
        } catch (_: Throwable) {
            isTorchActive = enable
        }
    }

    private fun setupMediaSessions() {
        try {
            mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
            val comp = ComponentName(this, IslandListenerService::class.java)
            mediaSessionManager?.addOnActiveSessionsChangedListener(sessionListener, comp)
            val initial = mediaSessionManager?.getActiveSessions(comp)
            bindMediaControllers(initial)
        } catch (_: Throwable) {}
    }

    private fun seedExistingNotifications() {
        try {
            activeNotifications?.forEach { sbn ->
                processPostedNotification(sbn, isSeed = true)
            }
        } catch (_: Throwable) {}
    }

    private fun bindMediaControllers(controllers: List<MediaController>?) {
        try { activeController?.unregisterCallback(mediaCallback) } catch (_: Throwable) {}
        activeController = null
        if (controllers.isNullOrEmpty()) {
            mediaPlaying = false
            decideNextState()
            return
        }
        val chosen = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.firstOrNull()
        activeController = chosen
        try { chosen?.registerCallback(mediaCallback, handler) } catch (_: Throwable) {}
        readMediaState()
    }

    private fun readMediaState() {
        val ctrl = activeController
        if (ctrl == null) {
            mediaPlaying = false
            decideNextState()
            return
        }
        val state = ctrl.playbackState
        val isNowPlaying = state?.state == PlaybackState.STATE_PLAYING ||
                state?.state == PlaybackState.STATE_BUFFERING
        mediaPosition = state?.position ?: 0L
        mediaLastStateTime = state?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime()

        val meta = ctrl.metadata
        val newTitle = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: ""
        val newArtist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
            ?: ""
        mediaDuration = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val bmp = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) {
            mediaArt = bmp
            mediaAccent = extractDominantColor(bmp, 0xFF30D158.toInt())
        }

        val sig = "$newTitle|$newArtist"
        if (sig != lastTrackSignature || (!mediaPlaying && isNowPlaying)) {
            mediaDismissedUntilChange = false
            lastTrackSignature = sig
        }
        val wasPlaying = mediaPlaying
        mediaTitle = newTitle
        mediaArtist = newArtist
        mediaPlaying = isNowPlaying

        handler.removeCallbacks(mediaPauseHideRunnable)
        if (!mediaPlaying && wasPlaying) {
            handler.postDelayed(mediaPauseHideRunnable, 12_000L)
        }

        if (currentMode == Mode.MEDIA_SMALL || currentMode == Mode.MEDIA_BIG) {
            liveEqualizerSmall?.isPlaying = mediaPlaying
            liveEqualizerBig?.isPlaying = mediaPlaying
            livePlayPauseIcon?.kind = if (mediaPlaying) ControlIconView.KIND_PAUSE else ControlIconView.KIND_PLAY
            livePlayPauseIcon?.invalidate()
        }
        decideNextState()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) {
            processPostedNotification(sbn, isSeed = false)
        }
    }

    private fun processPostedNotification(sbn: StatusBarNotification, isSeed: Boolean) {
        if (!Prefs.isEnabled(this) || !canRenderOverlay()) return

        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        if (Prefs.isAppBlocked(this, pkg)) return

        // Suppress if notification is from the currently open foreground app (unless call/timer)
        if (!isSeed && Prefs.isSuppressWhenAppOpen(this) &&
            pkg == IslandAccessibilityService.currentForegroundPkg
        ) {
            return
        }

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = n.extras
        if (extras != null && (extras.containsKey(Notification.EXTRA_MEDIA_SESSION) ||
                    n.category == Notification.CATEGORY_TRANSPORT)) {
            return
        }

        val category = n.category ?: ""
        val rawTitle = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val rawText = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        // 1. Detect Screen Recording (Samsung SmartCapture / SystemUI)
        val isScreenRec = (pkg.contains("smartcapture") || pkg == "com.android.systemui") &&
                (rawTitle.contains("record", ignoreCase = true) || rawText.contains("record", ignoreCase = true))
        if (isScreenRec && Prefs.isPluginScreenRecord(this)) {
            activeRecordItem = buildIslandItem(sbn, isCall = false, isTimer = false, isNav = false, isRide = false, isScreenRecord = true, durationMs = 0L)
            decideNextState(forceRebuild = true)
            return
        }
        if (pkg == "com.android.systemui") return

        // 2. Detect Google Maps / Turn-by-Turn Navigation
        val isNav = category == Notification.CATEGORY_NAVIGATION ||
                pkg == "com.google.android.apps.maps" && sbn.isOngoing
        if (isNav && Prefs.isPluginNavigation(this)) {
            activeNavItem = buildIslandItem(sbn, isCall = false, isTimer = false, isNav = true, isRide = false, isScreenRecord = false, durationMs = 0L)
            decideNextState(forceRebuild = true)
            return
        }

        // 3. Detect Uber / Ride / Food Delivery Live Progress
        val lowerPkg = pkg.lowercase()
        val isRideApp = lowerPkg.contains("uber") || lowerPkg.contains("ola") ||
                lowerPkg.contains("rapido") || lowerPkg.contains("zomato") ||
                lowerPkg.contains("swiggy") || lowerPkg.contains("lyft")
        val hasProgress = (extras?.getInt(Notification.EXTRA_PROGRESS_MAX, 0) ?: 0) > 0
        if ((isRideApp || (sbn.isOngoing && hasProgress && rawTitle.contains("arriv", ignoreCase = true))) &&
            Prefs.isPluginUber(this)
        ) {
            activeRideItem = buildIslandItem(sbn, isCall = false, isTimer = false, isNav = false, isRide = true, isScreenRecord = false, durationMs = 0L)
            decideNextState(forceRebuild = true)
            return
        }

        // 4. Detect Live Clock Timer / Stopwatch
        val showChrono = extras?.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false) == true
        val isTimer = showChrono && n.`when` > 0L && category != Notification.CATEGORY_CALL
        if (isTimer && Prefs.isPluginClock(this)) {
            activeTimerItem = buildIslandItem(sbn, isCall = false, isTimer = true, isNav = false, isRide = false, isScreenRecord = false, durationMs = 0L)
            decideNextState(forceRebuild = true)
            return
        }

        if (isSeed) return // Don't pop up old standard notifications on initial connect

        // 5. Detect Incoming / Ongoing Call
        val isCall = category == Notification.CATEGORY_CALL ||
                (sbn.isOngoing && hasCallActions(n))
        val isAlarm = category == Notification.CATEGORY_ALARM || category == Notification.CATEGORY_REMINDER

        if (sbn.isOngoing && !isCall && !isAlarm) return
        if (category == Notification.CATEGORY_SERVICE || category == Notification.CATEGORY_PROGRESS) return

        if (isCall && !Prefs.isPluginCall(this)) return
        if (!isCall && !Prefs.isPluginNotif(this)) return

        val ranking = Ranking()
        if (currentRanking != null && currentRanking.getRanking(sbn.key, ranking)) {
            if (ranking.importance < NotificationManager.IMPORTANCE_DEFAULT && !isCall && !isAlarm) {
                return
            }
        }

        val item = buildIslandItem(
            sbn = sbn,
            isCall = isCall,
            isTimer = false,
            isNav = false,
            isRide = false,
            isScreenRecord = false,
            durationMs = when {
                isCall -> 45_000L
                isAlarm -> 15_000L
                else -> Prefs.getNotifDurationSec(this) * 1000L
            }
        )
        if (item.title.isBlank() && item.text.isBlank() && !isCall) return

        // Deduplicate within 8 seconds
        val now = SystemClock.elapsedRealtime()
        val sig = "${item.pkg}|${item.title}|${item.text}"
        val lastTime = recentSignatures[sig]
        if (lastTime != null && now - lastTime < 8_000L && !isCall) {
            return
        }
        recentSignatures[sig] = now

        // Save to Swipe-Down Notification Dock history (up to 10 recent items)
        if (!isCall) {
            notifHistory.removeAll { it.key == item.key }
            notifHistory.addFirst(item)
            while (notifHistory.size > 10) notifHistory.removeLast()
        }

        enqueueItem(item)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (activeTimerItem?.key == sbn.key) activeTimerItem = null
        if (activeNavItem?.key == sbn.key) activeNavItem = null
        if (activeRideItem?.key == sbn.key) activeRideItem = null
        if (activeRecordItem?.key == sbn.key) activeRecordItem = null
        notifQueue.removeAll { it.key == sbn.key }
        if (activeItem?.key == sbn.key) {
            handler.removeCallbacks(autoDismissRunnable)
            activeItem = null
        }
        decideNextState()
    }

    private fun hasCallActions(n: Notification): Boolean {
        val acts = n.actions ?: return false
        if (acts.size < 2) return false
        val labels = acts.mapNotNull { it.title?.toString()?.lowercase() }
        return labels.any { it.contains("answer") || it.contains("accept") } &&
                labels.any { it.contains("decline") || it.contains("reject") || it.contains("hang") }
    }

    private fun buildIslandItem(
        sbn: StatusBarNotification,
        isCall: Boolean,
        isTimer: Boolean,
        isNav: Boolean,
        isRide: Boolean,
        isScreenRecord: Boolean,
        durationMs: Long
    ): IslandItem {
        val n = sbn.notification
        val ex = n.extras
        val pkg = sbn.packageName

        val appName = try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Throwable) {
            pkg.substringAfterLast('.')
        }

        val rawTitle = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: ex?.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
            ?: appName
        val rawText = ex?.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: ex?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: ""
        val subText = ex?.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""

        val iconDrawable: Drawable? = try {
            n.smallIcon?.loadDrawable(this) ?: packageManager.getApplicationIcon(pkg)
        } catch (_: Throwable) {
            null
        }

        val largeBmp: Bitmap? = try {
            val lgIcon = n.getLargeIcon()
            val dr = lgIcon?.loadDrawable(this)
            drawableToBitmap(dr)
        } catch (_: Throwable) {
            null
        }

        val actionsList = mutableListOf<ActionBtn>()
        n.actions?.take(3)?.forEach { act ->
            val lbl = act.title?.toString()?.trim() ?: ""
            if (lbl.isNotEmpty()) {
                val low = lbl.lowercase()
                val pos = low.contains("answer") || low.contains("accept")
                val neg = low.contains("decline") || low.contains("reject") || low.contains("dismiss") || low.contains("stop")
                actionsList.add(ActionBtn(lbl, act.actionIntent, act.remoteInputs, pos, neg))
            }
        }

        val countDown = if (Build.VERSION.SDK_INT >= 24) {
            ex?.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN, false) ?: false
        } else {
            false
        }

        val progMax = ex?.getInt(Notification.EXTRA_PROGRESS_MAX, 0) ?: 0
        val progCur = ex?.getInt(Notification.EXTRA_PROGRESS, 0) ?: 0
        val progPct = if (progMax > 0) ((progCur * 100) / progMax).coerceIn(5, 100) else 65

        val dynColor = when {
            isNav -> 0xFF30D158.toInt()
            isRide -> 0xFF32ADE6.toInt()
            isTimer -> 0xFFFF9F0A.toInt()
            isScreenRecord -> 0xFFFF453A.toInt()
            n.color != 0 -> n.color or 0xFF000000.toInt()
            largeBmp != null -> extractDominantColor(largeBmp, 0xFF5E5CE6.toInt())
            else -> 0xFF5E5CE6.toInt()
        }

        return IslandItem(
            key = sbn.key,
            pkg = pkg,
            appName = appName,
            title = rawTitle,
            text = rawText,
            subText = subText,
            icon = iconDrawable,
            largeBitmap = largeBmp,
            contentIntent = n.contentIntent,
            actions = actionsList,
            isCall = isCall,
            isTimer = isTimer,
            isNav = isNav,
            isRide = isRide,
            isScreenRecord = isScreenRecord,
            progressPct = progPct,
            chronometerBase = if (n.`when` > 0L) n.`when` else System.currentTimeMillis(),
            chronometerCountDown = countDown,
            whenMs = if (n.`when` > 0L) n.`when` else System.currentTimeMillis(),
            durationMs = durationMs,
            accentColor = Prefs.resolveAccentColor(this, dynColor)
        )
    }

    private fun enqueueItem(item: IslandItem) {
        if (item.isCall) {
            activeItem?.let { notifQueue.addFirst(it) }
            activeItem = item
            scheduleAutoDismiss(item.durationMs)
            hapticTick()
            decideNextState(forceRebuild = true)
            return
        }

        if (activeItem == null) {
            activeItem = item
            scheduleAutoDismiss(item.durationMs)
            hapticTick()
            decideNextState(forceRebuild = true)
        } else {
            if (notifQueue.size >= 5) notifQueue.removeLast()
            notifQueue.addLast(item)
        }
    }

    private fun scheduleAutoDismiss(ms: Long) {
        handler.removeCallbacks(autoDismissRunnable)
        if (ms > 0L) {
            handler.postDelayed(autoDismissRunnable, ms)
        }
    }

    private fun onItemTimeout() {
        setTouchWindowFocusable(false)
        activeItem = notifQueue.removeFirstOrNull()
        if (activeItem != null) {
            scheduleAutoDismiss(activeItem!!.durationMs)
            hapticTick()
            decideNextState(forceRebuild = true)
        } else {
            decideNextState(forceRebuild = true)
        }
    }

    private fun showSystemHud(hud: SystemHudData) {
        if (!Prefs.isEnabled(this) || !canRenderOverlay()) return
        activeHud = hud
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 3_400L)
        hapticTick()
        decideNextState(forceRebuild = true)
    }

    private fun triggerPreview(kind: String) {
        if (!canRenderOverlay()) return
        when (kind) {
            "music" -> {
                mediaTitle = "Blinding Lights (Dynamic Motion)"
                mediaArtist = "The Weeknd"
                mediaPlaying = true
                mediaDuration = 200_000L
                mediaPosition = 64_000L
                mediaLastStateTime = SystemClock.elapsedRealtime()
                mediaAccent = Prefs.resolveAccentColor(this, 0xFF30D158.toInt())
                mediaDismissedUntilChange = false
                hapticTick()
                transitionToMode(Mode.MEDIA_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            "metaball" -> {
                // Demo Concurrent Music + Detached Timer Bubble (Liquid Metaball split!)
                mediaTitle = "Starboy • Galaxy A52s"
                mediaArtist = "Daft Punk"
                mediaPlaying = true
                mediaDuration = 230_000L
                mediaPosition = 42_000L
                mediaLastStateTime = SystemClock.elapsedRealtime()
                mediaAccent = Prefs.resolveAccentColor(this, 0xFF5E5CE6.toInt())
                mediaDismissedUntilChange = false
                activeTimerItem = IslandItem(
                    key = "preview_timer_meta",
                    pkg = packageName,
                    appName = "Clock",
                    title = "Timer",
                    text = "Countdown",
                    subText = "",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = emptyList(),
                    isCall = false,
                    isTimer = true,
                    isNav = false,
                    isRide = false,
                    isScreenRecord = false,
                    progressPct = 70,
                    chronometerBase = System.currentTimeMillis() + 195_000L,
                    chronometerCountDown = true,
                    whenMs = System.currentTimeMillis() + 195_000L,
                    durationMs = 12_000L,
                    accentColor = 0xFFFF9F0A.toInt()
                )
                hapticTick()
                transitionToMode(Mode.MEDIA_SMALL, forceRebuild = true)
            }
            "flashlight" -> {
                isTorchActive = true
                torchDismissed = false
                hapticTick()
                transitionToMode(Mode.FLASHLIGHT_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            "nav" -> {
                activeNavItem = IslandItem(
                    key = "preview_nav",
                    pkg = "com.google.android.apps.maps",
                    appName = "Maps",
                    title = "Turn right onto MG Road",
                    text = "350 m • 14 min remaining",
                    subText = "10:15 AM ETA",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = emptyList(),
                    isCall = false,
                    isTimer = false,
                    isNav = true,
                    isRide = false,
                    isScreenRecord = false,
                    progressPct = 68,
                    chronometerBase = 0L,
                    chronometerCountDown = false,
                    whenMs = System.currentTimeMillis(),
                    durationMs = 10_000L,
                    accentColor = 0xFF30D158.toInt()
                )
                hapticTick()
                transitionToMode(Mode.NAV_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            "uber" -> {
                activeRideItem = IslandItem(
                    key = "preview_uber",
                    pkg = "com.ubercab",
                    appName = "Uber",
                    title = "Arriving in 3 min",
                    text = "White Swift Dzire • UP14 AB 4921",
                    subText = "4.9 ★ Rajesh",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = emptyList(),
                    isCall = false,
                    isTimer = false,
                    isNav = false,
                    isRide = true,
                    isScreenRecord = false,
                    progressPct = 78,
                    chronometerBase = 0L,
                    chronometerCountDown = false,
                    whenMs = System.currentTimeMillis(),
                    durationMs = 10_000L,
                    accentColor = 0xFF32ADE6.toInt()
                )
                hapticTick()
                transitionToMode(Mode.UBER_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            "call" -> {
                val fakeCall = IslandItem(
                    key = "preview_call_${SystemClock.elapsedRealtime()}",
                    pkg = packageName,
                    appName = "Phone",
                    title = "Aarav Sharma",
                    text = "Incoming 5G Voice Call",
                    subText = "",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = listOf(
                        ActionBtn("Decline", null, null, isPositive = false, isNegative = true),
                        ActionBtn("Answer", null, null, isPositive = true, isNegative = false)
                    ),
                    isCall = true,
                    isTimer = false,
                    isNav = false,
                    isRide = false,
                    isScreenRecord = false,
                    progressPct = 100,
                    chronometerBase = 0L,
                    chronometerCountDown = false,
                    whenMs = System.currentTimeMillis(),
                    durationMs = 8_000L,
                    accentColor = 0xFF30D158.toInt()
                )
                enqueueItem(fakeCall)
            }
            "battery" -> {
                showSystemHud(
                    SystemHudData(
                        title = "Charging",
                        subtitle = "Super Fast Charging 25W",
                        badgeText = "88%",
                        accentColor = 0xFF30D158.toInt(),
                        hudKind = 0,
                        batteryLevel = 88,
                        isCharging = true
                    )
                )
            }
            "lock" -> {
                isKeyguardLocked = true
                hapticTick()
                transitionToMode(Mode.LOCK_COMPACT, forceRebuild = true)
                handler.postDelayed({
                    lockMorphView?.animateUnlock()
                }, 650L)
                handler.removeCallbacks(lockHideRunnable)
                handler.postDelayed(lockHideRunnable, 2_800L)
            }
            else -> {
                val fakeNotif = IslandItem(
                    key = "preview_notif_${SystemClock.elapsedRealtime()}",
                    pkg = packageName,
                    appName = "Messages",
                    title = "Dynamic Motion v5",
                    text = "Tap to expand with inline reply, or swipe down on the pill to open your Notification Dock!",
                    subText = "now",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = listOf(
                        ActionBtn("Reply", null),
                        ActionBtn("Mark Read", null)
                    ),
                    isCall = false,
                    isTimer = false,
                    isNav = false,
                    isRide = false,
                    isScreenRecord = false,
                    progressPct = 100,
                    chronometerBase = 0L,
                    chronometerCountDown = false,
                    whenMs = System.currentTimeMillis(),
                    durationMs = Prefs.getNotifDurationSec(this) * 1000L,
                    accentColor = Prefs.resolveAccentColor(this, 0xFF5E5CE6.toInt())
                )
                notifHistory.addFirst(fakeNotif)
                while (notifHistory.size > 10) notifHistory.removeLast()
                enqueueItem(fakeNotif)
            }
        }
    }

    private fun canRenderOverlay(): Boolean {
        return IslandAccessibilityService.getInstance() != null || Settings.canDrawOverlays(this)
    }

    private fun decideNextState(forceRebuild: Boolean = false) {
        if (!Prefs.isEnabled(this) || !canRenderOverlay()) {
            transitionToMode(Mode.HIDDEN)
            return
        }

        if (Prefs.isHideInLandscape(this) &&
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        ) {
            transitionToMode(Mode.HIDDEN)
            return
        }

        val desiredMode = when {
            activeItem != null && activeItem!!.isCall -> Mode.CALL
            activeItem != null -> {
                if (Prefs.isAutoExpandNotif(this) || currentMode == Mode.NOTIF_EXPANDED) {
                    Mode.NOTIF_EXPANDED
                } else {
                    Mode.NOTIF_COMPACT
                }
            }
            activeHud != null -> Mode.SYSTEM_HUD
            isKeyguardLocked && Prefs.isPluginLockScreen(this) -> Mode.LOCK_COMPACT
            isTorchActive && !torchDismissed && Prefs.isPluginFlashlight(this) -> {
                if (currentMode == Mode.FLASHLIGHT_BIG) Mode.FLASHLIGHT_BIG else Mode.FLASHLIGHT_SMALL
            }
            activeRecordItem != null && Prefs.isPluginScreenRecord(this) -> {
                if (currentMode == Mode.RECORD_BIG) Mode.RECORD_BIG else Mode.RECORD_SMALL
            }
            activeNavItem != null && Prefs.isPluginNavigation(this) -> {
                if (currentMode == Mode.NAV_BIG) Mode.NAV_BIG else Mode.NAV_SMALL
            }
            activeRideItem != null && Prefs.isPluginUber(this) -> {
                if (currentMode == Mode.UBER_BIG) Mode.UBER_BIG else Mode.UBER_SMALL
            }
            Prefs.isPluginMedia(this) && !mediaDismissedUntilChange &&
                    (mediaPlaying || currentMode == Mode.MEDIA_BIG) &&
                    mediaTitle.isNotEmpty() -> {
                if (currentMode == Mode.MEDIA_BIG) Mode.MEDIA_BIG else Mode.MEDIA_SMALL
            }
            activeTimerItem != null && Prefs.isPluginClock(this) -> {
                if (currentMode == Mode.TIMER_BIG) Mode.TIMER_BIG else Mode.TIMER_SMALL
            }
            !Prefs.isHideWhenIdle(this) -> Mode.IDLE_PILL
            else -> Mode.HIDDEN
        }

        transitionToMode(desiredMode, forceRebuild)
    }

    private fun isExpandedMode(mode: Mode): Boolean {
        return mode == Mode.MEDIA_BIG || mode == Mode.TIMER_BIG ||
                mode == Mode.FLASHLIGHT_BIG || mode == Mode.NAV_BIG ||
                mode == Mode.UBER_BIG || mode == Mode.RECORD_BIG ||
                mode == Mode.NOTIF_EXPANDED || mode == Mode.NOTIF_DOCK ||
                mode == Mode.CALL || mode == Mode.QUICK_LAUNCHER
    }

    private fun shouldShowDetachedBubble(mode: Mode): Boolean {
        if (!Prefs.isDetachedBubble(this) || isExpandedMode(mode)) return false
        // Show detached secondary bubble when Music is in compact pill AND Timer or Flashlight is also active
        if (mode == Mode.MEDIA_SMALL && (activeTimerItem != null || isTorchActive)) {
            return true
        }
        if ((mode == Mode.NAV_SMALL || mode == Mode.UBER_SMALL) && activeTimerItem != null) {
            return true
        }
        return false
    }

    private fun getDimensionsForMode(mode: Mode): Triple<Int, Int, Int> {
        val screenW = resources.displayMetrics.widthPixels
        val expMargin = dp(Prefs.getExpandedMarginDp(this).toFloat())
        val expWidth = (screenW - expMargin * 2).coerceAtMost(dp(372f))
        val compW = dp(Prefs.getCompactWidthDp(this).toFloat())
        val compH = dp(Prefs.getCompactHeightDp(this).toFloat())
        val idleW = dp(Prefs.getIdleWidthDp(this).toFloat())
        val idleH = dp(Prefs.getIdleHeightDp(this).toFloat())
        val cRad = dp(Prefs.getCornerRadiusDp(this).toFloat())
        val expRad = dp(Prefs.getExpandedCornerRadiusDp(this).toFloat())

        return when (mode) {
            Mode.HIDDEN -> Triple(dp(28f), dp(22f), dp(14f))
            Mode.IDLE_PILL -> Triple(idleW, idleH, cRad)
            Mode.LOCK_COMPACT -> Triple(dp(156f), compH, cRad)
            Mode.MEDIA_SMALL -> Triple(compW, compH, cRad)
            Mode.TIMER_SMALL -> Triple(dp(158f), compH, cRad)
            Mode.FLASHLIGHT_SMALL -> Triple(dp(154f), compH, cRad)
            Mode.NAV_SMALL -> Triple(dp(196f), compH, cRad)
            Mode.UBER_SMALL -> Triple(dp(202f), compH, cRad)
            Mode.RECORD_SMALL -> Triple(dp(162f), compH, cRad)
            Mode.NOTIF_COMPACT -> Triple(dp(236f), dp(40f), cRad)
            Mode.SYSTEM_HUD -> Triple(dp(248f), dp(42f), cRad)
            Mode.MEDIA_BIG -> Triple(expWidth, dp(182f), expRad)
            Mode.TIMER_BIG -> Triple(expWidth, dp(118f), expRad)
            Mode.FLASHLIGHT_BIG -> Triple(expWidth, dp(116f), expRad)
            Mode.NAV_BIG -> Triple(expWidth, dp(134f), expRad)
            Mode.UBER_BIG -> Triple(expWidth, dp(146f), expRad)
            Mode.RECORD_BIG -> Triple(expWidth, dp(112f), expRad)
            Mode.CALL -> Triple(expWidth, dp(132f), expRad)
            Mode.NOTIF_EXPANDED -> Triple(expWidth, dp(152f), expRad)
            Mode.NOTIF_DOCK -> Triple(expWidth, dp(226f), expRad)
            Mode.QUICK_LAUNCHER -> Triple(expWidth, dp(126f), expRad)
        }
    }

    private fun checkWindowHostContext() {
        val acc = IslandAccessibilityService.getInstance()
        val wantAcc = acc != null
        if (windowsAttached && wantAcc != usingAccessibilityWindow) {
            removeOverlayWindows()
        }
    }

    /**
     * Creates Dynamic Motion's Dual-Window Overlay:
     *  1. Full-width non-touchable visual canvas window (`visualHostView`) so spring overshoots,
     *     detached metaball bubbles, and ambient glow never clip at window edges.
     *  2. Tightly-fitted touch window (`touchWindowView`) positioned over the pill so all
     *     status bar & app touches outside the pill pass straight through to the phone.
     */
    private fun ensureOverlayWindowsCreated() {
        checkWindowHostContext()
        if (windowsAttached && visualHostView != null && touchWindowView != null) return

        val acc = IslandAccessibilityService.getInstance()
        val hostCtx: Context = acc ?: this
        val windowManager = hostCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        wm = windowManager
        usingAccessibilityWindow = (acc != null)

        val overlayType = if (usingAccessibilityWindow) {
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        }

        val screenW = resources.displayMetrics.widthPixels
        val visualCanvasHeight = dp(320f)

        val host = LiquidIslandHostView(this).apply {
            showStroke = Prefs.isStrokeEnabled(this@IslandListenerService)
            showAmbientGlow = Prefs.isMediaGlowEnabled(this@IslandListenerService)
        }

        // Visual window is non-focusable AND non-touchable so it never blocks touches anywhere on screen
        val vFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

        val vParams = WindowManager.LayoutParams(
            screenW,
            visualCanvasHeight,
            overlayType,
            vFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Touch window covers only the active pill bounding box and forwards touches to visualHostView
        val tFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        val initW = dp(Prefs.getIdleWidthDp(this).toFloat())
        val initH = dp(Prefs.getIdleHeightDp(this).toFloat())
        val initY = dp(Prefs.getIslandY(this).toFloat())
        val initX = dp(Prefs.getIslandX(this).toFloat())

        val tParams = WindowManager.LayoutParams(
            initW,
            initH,
            overlayType,
            tFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - initW) / 2 + initX
            y = initY
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val tFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }
        attachTouchForwarder(tFrame, host)

        try {
            windowManager.addView(host, vParams)
            windowManager.addView(tFrame, tParams)
            visualHostView = host
            visualLp = vParams
            touchWindowView = tFrame
            touchLp = tParams
            windowsAttached = true

            animWidthPx = initW.toFloat()
            animHeightPx = initH.toFloat()
            animCornerPx = dpF(Prefs.getCornerRadiusDp(this).toFloat())
            initSprings()
            syncVisualAndTouchGeometry()
        } catch (_: Throwable) {
            windowsAttached = false
        }
    }

    private fun setTouchWindowFocusable(focusable: Boolean) {
        if (touchFocusable == focusable) return
        touchFocusable = focusable
        val tParams = touchLp ?: return
        val tView = touchWindowView ?: return
        val windowManager = wm ?: return
        if (!windowsAttached) return

        tParams.flags = if (focusable) {
            tParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            tParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        try {
            windowManager.updateViewLayout(tView, tParams)
        } catch (_: Throwable) {}
    }

    private fun initSprings() {
        val wHolder = FloatValueHolder(animWidthPx)
        widthSpring = SpringAnimation(wHolder).apply {
            minimumVisibleChange = 0.5f
            addUpdateListener { _, value, velocity ->
                animWidthPx = value
                velWidth = velocity
                if (Prefs.isJellyPhysics(this@IslandListenerService)) {
                    visualHostView?.jellyStretchX = (velocity / 18000f).coerceIn(-0.07f, 0.08f)
                } else {
                    visualHostView?.jellyStretchX = 0f
                }
                syncVisualAndTouchGeometry()
            }
            addEndListener { _, _, _, _ ->
                velWidth = 0f
                visualHostView?.jellyStretchX = 0f
                syncVisualAndTouchGeometry()
            }
        }

        val hHolder = FloatValueHolder(animHeightPx)
        heightSpring = SpringAnimation(hHolder).apply {
            minimumVisibleChange = 0.5f
            addUpdateListener { _, value, velocity ->
                animHeightPx = value
                velHeight = velocity
                if (Prefs.isJellyPhysics(this@IslandListenerService)) {
                    visualHostView?.jellyStretchY = (velocity / 18000f).coerceIn(-0.06f, 0.07f)
                } else {
                    visualHostView?.jellyStretchY = 0f
                }
                syncVisualAndTouchGeometry()
            }
            addEndListener { _, _, _, _ ->
                velHeight = 0f
                visualHostView?.jellyStretchY = 0f
                syncVisualAndTouchGeometry()
            }
        }

        val cHolder = FloatValueHolder(animCornerPx)
        cornerSpring = SpringAnimation(cHolder).apply {
            minimumVisibleChange = 0.25f
            spring = SpringForce().apply {
                stiffness = 400f
                dampingRatio = 0.56f
            }
            addUpdateListener { _, value, _ ->
                animCornerPx = value
                syncVisualAndTouchGeometry()
            }
        }

        val bHolder = FloatValueHolder(animBubbleProgress)
        bubbleSpring = SpringAnimation(bHolder).apply {
            minimumVisibleChange = 0.004f
            addUpdateListener { _, value, _ ->
                animBubbleProgress = value
                visualHostView?.bubbleProgress = value
                syncVisualAndTouchGeometry()
            }
        }

        val pHolder = FloatValueHolder(1.0f)
        pressSpring = SpringAnimation(pHolder).apply {
            minimumVisibleChange = 0.003f
            addUpdateListener { _, value, _ ->
                visualHostView?.pressScale = value
                visualHostView?.invalidate()
            }
        }
    }

    private fun animatePillDimensions(targetW: Float, targetH: Float, targetCorner: Float, wantBubble: Boolean) {
        val isExpanding = (targetW * targetH) > (animWidthPx * animHeightPx * 1.05f)

        val wDamp = if (isExpanding) Prefs.getExpandWidthDamping(this) else Prefs.getCollapseWidthDamping(this)
        val hDamp = if (isExpanding) Prefs.getExpandHeightDamping(this) else Prefs.getCollapseHeightDamping(this)
        val wStiff = if (isExpanding) Prefs.getExpandWidthStiffness(this) else Prefs.getCollapseWidthStiffness(this)
        val hStiff = if (isExpanding) Prefs.getExpandHeightStiffness(this) else Prefs.getCollapseHeightStiffness(this)
        val hDelay = if (isExpanding) Prefs.getExpandHeightDelayMs(this) else 0L

        // Width spring starts immediately with initial velocity boost
        widthSpring?.spring = SpringForce(targetW).apply {
            dampingRatio = wDamp
            stiffness = wStiff
        }
        widthSpring?.setStartValue(animWidthPx)
        widthSpring?.setStartVelocity(if (isExpanding) 135f else 0f)
        widthSpring?.start()

        // Corner spring
        cornerSpring?.animateToFinalPosition(targetCorner)

        // Height spring runs after 38ms lead delay on expand (Dynamic Motion signature)
        pendingHeightRunnable?.let { handler.removeCallbacks(it) }
        val runHeight = Runnable {
            heightSpring?.spring = SpringForce(targetH).apply {
                dampingRatio = hDamp
                stiffness = hStiff
            }
            heightSpring?.setStartValue(animHeightPx)
            heightSpring?.start()
        }
        pendingHeightRunnable = runHeight
        if (hDelay > 0L) {
            handler.postDelayed(runHeight, hDelay)
        } else {
            runHeight.run()
        }

        // Detached secondary metaball bubble spring
        val bubbleTarget = if (wantBubble) 1.0f else 0.0f
        bubbleSpring?.spring = SpringForce(bubbleTarget).apply {
            dampingRatio = if (wantBubble) 0.58f else 0.80f
            stiffness = if (wantBubble) 220f else 260f
        }
        bubbleSpring?.setStartValue(animBubbleProgress)
        bubbleSpring?.start()
    }

    private fun animatePressScale(pressed: Boolean) {
        val target = if (pressed) 1.08f else 1.0f
        pressSpring?.spring = SpringForce(target).apply {
            dampingRatio = if (pressed) 0.56f else 0.72f
            stiffness = if (pressed) 320f else 580f
        }
        pressSpring?.animateToFinalPosition(target)
    }

    private fun syncVisualAndTouchGeometry() {
        val host = visualHostView ?: return
        if (!windowsAttached) return

        val screenW = resources.displayMetrics.widthPixels
        val cx = (screenW / 2f) + dpF(Prefs.getIslandX(this).toFloat())
        val topY = if (Prefs.isShowAsNotch(this)) 0f else dpF(Prefs.getIslandY(this).toFloat())

        host.showStroke = Prefs.isStrokeEnabled(this)
        host.showAmbientGlow = Prefs.isMediaGlowEnabled(this)
        host.updateGeometry(
            cx = cx,
            topY = topY,
            w = animWidthPx,
            h = animHeightPx,
            cornerRadius = animCornerPx,
            velX = velWidth,
            velY = velHeight,
            blurEnabled = Prefs.isBlurEnabled(this)
        )

        // Update tight touch window bounds when springs settle or move significantly
        val tParams = touchLp ?: return
        val tView = touchWindowView ?: return
        val windowManager = wm ?: return
        host.getInteractiveBounds(tempBounds)
        val newW = tempBounds.width().coerceAtLeast(1)
        val newH = tempBounds.height().coerceAtLeast(1)
        if (abs(tParams.x - tempBounds.left) > 3 ||
            abs(tParams.y - tempBounds.top) > 3 ||
            abs(tParams.width - newW) > 4 ||
            abs(tParams.height - newH) > 4
        ) {
            tParams.x = tempBounds.left
            tParams.y = tempBounds.top
            tParams.width = newW
            tParams.height = newH
            try {
                windowManager.updateViewLayout(tView, tParams)
            } catch (_: Throwable) {}
        }
    }

    private fun transitionToMode(newMode: Mode, forceRebuild: Boolean = false) {
        if (newMode == Mode.HIDDEN) {
            if (!windowsAttached) {
                currentMode = Mode.HIDDEN
                return
            }
            currentMode = Mode.HIDDEN
            setTouchWindowFocusable(false)
            val (hideW, hideH, hideR) = getDimensionsForMode(Mode.HIDDEN)
            animatePillDimensions(hideW.toFloat(), hideH.toFloat(), hideR.toFloat(), wantBubble = false)
            visualHostView?.animate()?.alpha(0f)?.setDuration(190L)?.withEndAction {
                if (currentMode == Mode.HIDDEN) {
                    removeOverlayWindows()
                }
            }?.start()
            return
        }

        ensureOverlayWindowsCreated()
        if (!windowsAttached) return

        visualHostView?.animate()?.cancel()
        visualHostView?.alpha = 1f

        val modeChanged = currentMode != newMode
        currentMode = newMode

        val accent = when (newMode) {
            Mode.CALL, Mode.NOTIF_COMPACT, Mode.NOTIF_EXPANDED -> activeItem?.accentColor ?: 0xFF5E5CE6.toInt()
            Mode.MEDIA_SMALL, Mode.MEDIA_BIG -> Prefs.resolveAccentColor(this, mediaAccent)
            Mode.SYSTEM_HUD -> activeHud?.accentColor ?: 0xFF30D158.toInt()
            Mode.TIMER_SMALL, Mode.TIMER_BIG -> 0xFFFF9F0A.toInt()
            Mode.FLASHLIGHT_SMALL, Mode.FLASHLIGHT_BIG -> 0xFFFFD60A.toInt()
            Mode.NAV_SMALL, Mode.NAV_BIG -> 0xFF30D158.toInt()
            Mode.UBER_SMALL, Mode.UBER_BIG -> 0xFF32ADE6.toInt()
            Mode.RECORD_SMALL, Mode.RECORD_BIG -> 0xFFFF453A.toInt()
            else -> Prefs.resolveAccentColor(this, 0xFF5E5CE6.toInt())
        }
        visualHostView?.accentColor = accent

        val wantBubble = shouldShowDetachedBubble(newMode)
        val (targetW, targetH, targetR) = getDimensionsForMode(newMode)
        animatePillDimensions(targetW.toFloat(), targetH.toFloat(), targetR.toFloat(), wantBubble)

        if (modeChanged || forceRebuild) {
            rebuildContentForMode(newMode, wantBubble)
        }

        handler.removeCallbacks(tickerRunnable)
        handler.post(tickerRunnable)
    }

    private fun removeOverlayWindows() {
        spinAnimator?.cancel()
        val windowManager = wm
        if (windowsAttached && windowManager != null) {
            visualHostView?.let {
                try { windowManager.removeViewImmediate(it) } catch (_: Throwable) {}
            }
            touchWindowView?.let {
                try { windowManager.removeViewImmediate(it) } catch (_: Throwable) {}
            }
        }
        windowsAttached = false
        touchFocusable = false
        visualHostView = null
        visualLp = null
        touchWindowView = null
        touchLp = null
    }

    private fun rebuildContentForMode(mode: Mode, wantBubble: Boolean) {
        val host = visualHostView ?: return
        val frame = host.mainContentHolder
        val bubbleFrame = host.bubbleContentHolder

        spinAnimator?.cancel()
        liveSeekLine = null
        liveElapsedTv = null
        liveTotalTv = null
        liveEqualizerSmall = null
        liveEqualizerBig = null
        livePlayPauseIcon = null
        liveTimerTv = null
        liveBubbleTimerTv = null
        lockMorphView = null

        val newView: View = when (mode) {
            Mode.IDLE_PILL -> buildIdlePillView()
            Mode.LOCK_COMPACT -> buildLockCompactView()
            Mode.MEDIA_SMALL -> buildMediaSmallView()
            Mode.MEDIA_BIG -> buildMediaBigView()
            Mode.TIMER_SMALL -> buildTimerSmallView()
            Mode.TIMER_BIG -> buildTimerBigView()
            Mode.FLASHLIGHT_SMALL -> buildFlashlightSmallView()
            Mode.FLASHLIGHT_BIG -> buildFlashlightBigView()
            Mode.NAV_SMALL -> buildNavSmallView()
            Mode.NAV_BIG -> buildNavBigView()
            Mode.UBER_SMALL -> buildUberSmallView()
            Mode.UBER_BIG -> buildUberBigView()
            Mode.RECORD_SMALL -> buildRecordSmallView()
            Mode.RECORD_BIG -> buildRecordBigView()
            Mode.SYSTEM_HUD -> buildSystemHudView()
            Mode.CALL -> buildCallView()
            Mode.NOTIF_COMPACT -> buildNotifCompactView()
            Mode.NOTIF_EXPANDED -> buildNotifExpandedView()
            Mode.NOTIF_DOCK -> buildNotifDockView()
            Mode.QUICK_LAUNCHER -> buildQuickLauncherView()
            Mode.HIDDEN -> View(this)
        }

        for (i in 0 until frame.childCount) {
            val old = frame.getChildAt(i)
            old.animate()
                .alpha(0f)
                .scaleX(0.84f)
                .scaleY(0.84f)
                .setDuration(120L)
                .withEndAction { frame.removeView(old) }
                .start()
        }

        newView.alpha = 0f
        newView.scaleX = 0.86f
        newView.scaleY = 0.86f
        frame.addView(
            newView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        newView.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(35L)
            .setDuration(180L)
            .start()

        // Populate Detached Secondary Metaball Bubble if active
        bubbleFrame.removeAllViews()
        if (wantBubble) {
            val bView = buildDetachedBubbleContentView()
            bubbleFrame.addView(
                bView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    private fun buildDetachedBubbleContentView(): View {
        val box = FrameLayout(this)
        if (isTorchActive) {
            val ic = ControlIconView(this, ControlIconView.KIND_FLASHLIGHT).apply {
                iconColor = 0xFFFFD60A.toInt()
                layoutParams = FrameLayout.LayoutParams(dp(18f), dp(18f), Gravity.CENTER)
            }
            box.addView(ic)
            visualHostView?.onBubbleTap = {
                hapticTick()
                transitionToMode(Mode.FLASHLIGHT_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
        } else {
            val ic = ControlIconView(this, ControlIconView.KIND_TIMER).apply {
                iconColor = 0xFFFF9F0A.toInt()
                layoutParams = FrameLayout.LayoutParams(dp(18f), dp(18f), Gravity.CENTER)
            }
            box.addView(ic)
            visualHostView?.onBubbleTap = {
                hapticTick()
                transitionToMode(Mode.TIMER_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
        }
        return box
    }

    private fun buildIdlePillView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11f), 0, dp(11f), 0)
        }
        val leftLens = View(this).apply {
            background = roundedBg(0xFF1A1E2E.toInt(), dpF(4f))
            layoutParams = LinearLayout.LayoutParams(dp(7f), dp(7f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val rightDot = View(this).apply {
            val col = Prefs.resolveAccentColor(this@IslandListenerService, 0xFF5E5CE6.toInt())
            background = roundedBg(col, dpF(4f))
            alpha = 0.55f
            layoutParams = LinearLayout.LayoutParams(dp(6f), dp(6f))
        }
        row.addView(leftLens)
        row.addView(spacer)
        row.addView(rightDot)
        return row
    }

    private fun buildLockCompactView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12f), 0, dp(14f), 0)
        }
        val morph = LockMorphView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(22f), dp(22f))
        }
        lockMorphView = morph
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val label = TextView(this).apply {
            text = "Face ID"
            setTextColor(0xFF30D158.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        row.addView(morph)
        row.addView(spacer)
        row.addView(label)
        return row
    }

    private fun buildMediaSmallView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9f), 0, dp(11f), 0)
        }

        val artIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(dpF(11f))
            if (mediaArt != null) {
                setImageBitmap(mediaArt)
            } else {
                background = roundedBg(0xFF252836.toInt(), dpF(11f))
            }
            layoutParams = LinearLayout.LayoutParams(dp(22f), dp(22f))
        }
        row.addView(artIv)

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        row.addView(spacer)

        val eq = EqualizerView(this, barCount = 5).apply {
            barColor = Prefs.resolveAccentColor(this@IslandListenerService, mediaAccent)
            isPlaying = mediaPlaying
            layoutParams = LinearLayout.LayoutParams(dp(24f), dp(15f))
        }
        liveEqualizerSmall = eq
        row.addView(eq)
        return row
    }

    private fun buildMediaBigView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(18f), dp(18f), dp(14f))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val artIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(dpF(14f))
            if (mediaArt != null) {
                setImageBitmap(mediaArt)
            } else {
                background = roundedBg(0xFF252836.toInt(), dpF(14f))
            }
            layoutParams = LinearLayout.LayoutParams(dp(54f), dp(54f))
        }
        topRow.addView(artIv)

        val metaCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(13f)
                rightMargin = dp(10f)
            }
        }

        val titleTv = TextView(this).apply {
            text = mediaTitle.ifEmpty { "Playing Media" }
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val artistTv = TextView(this).apply {
            text = mediaArtist.ifEmpty { "Unknown Artist" }
            setTextColor(0xFFB0B0B8.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        metaCol.addView(titleTv)
        metaCol.addView(artistTv)
        topRow.addView(metaCol)

        val eq = EqualizerView(this, barCount = 5).apply {
            barColor = Prefs.resolveAccentColor(this@IslandListenerService, mediaAccent)
            isPlaying = mediaPlaying
            layoutParams = LinearLayout.LayoutParams(dp(28f), dp(22f))
        }
        liveEqualizerBig = eq
        topRow.addView(eq)
        root.addView(topRow)

        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12f)
            }
        }

        val elapsedTv = TextView(this).apply {
            text = formatMs(mediaPosition)
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        }
        liveElapsedTv = elapsedTv
        seekRow.addView(elapsedTv)

        val seekBar = ProgressLine(this).apply {
            activeColor = Prefs.resolveAccentColor(this@IslandListenerService, mediaAccent)
            progress = if (mediaDuration > 0L) (mediaPosition.toFloat() / mediaDuration.toFloat()) else 0f
            layoutParams = LinearLayout.LayoutParams(0, dp(20f), 1f).apply {
                leftMargin = dp(8f)
                rightMargin = dp(8f)
            }
            onSeek = { ratio ->
                if (mediaDuration > 0L) {
                    val targetPos = (ratio * mediaDuration).toLong()
                    try {
                        activeController?.transportControls?.seekTo(targetPos)
                        mediaPosition = targetPos
                        mediaLastStateTime = SystemClock.elapsedRealtime()
                    } catch (_: Throwable) {}
                }
                resetCollapseTimer()
            }
        }
        liveSeekLine = seekBar
        seekRow.addView(seekBar)

        val totalTv = TextView(this).apply {
            text = formatMs(mediaDuration)
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        }
        liveTotalTv = totalTv
        seekRow.addView(totalTv)
        root.addView(seekRow)

        val ctrlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(6f)
            }
        }

        val prevBtn = ControlIconView(this, ControlIconView.KIND_PREV).apply {
            layoutParams = LinearLayout.LayoutParams(dp(38f), dp(34f))
            setOnClickListener {
                hapticTick()
                try { activeController?.transportControls?.skipToPrevious() } catch (_: Throwable) {}
                resetCollapseTimer()
            }
        }

        val playPauseBtn = ControlIconView(
            this,
            if (mediaPlaying) ControlIconView.KIND_PAUSE else ControlIconView.KIND_PLAY
        ).apply {
            layoutParams = LinearLayout.LayoutParams(dp(46f), dp(38f)).apply {
                leftMargin = dp(24f)
                rightMargin = dp(24f)
            }
            setOnClickListener {
                hapticTick()
                try {
                    if (mediaPlaying) activeController?.transportControls?.pause()
                    else activeController?.transportControls?.play()
                } catch (_: Throwable) {}
                mediaPlaying = !mediaPlaying
                kind = if (mediaPlaying) ControlIconView.KIND_PAUSE else ControlIconView.KIND_PLAY
                invalidate()
                liveEqualizerBig?.isPlaying = mediaPlaying
                resetCollapseTimer()
            }
        }
        livePlayPauseIcon = playPauseBtn

        val nextBtn = ControlIconView(this, ControlIconView.KIND_NEXT).apply {
            layoutParams = LinearLayout.LayoutParams(dp(38f), dp(34f))
            setOnClickListener {
                hapticTick()
                try { activeController?.transportControls?.skipToNext() } catch (_: Throwable) {}
                resetCollapseTimer()
            }
        }

        ctrlRow.addView(prevBtn)
        ctrlRow.addView(playPauseBtn)
        ctrlRow.addView(nextBtn)
        root.addView(ctrlRow)

        return root
    }

    private fun buildTimerSmallView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(12f), 0)
        }
        val icon = ControlIconView(this, ControlIconView.KIND_TIMER).apply {
            iconColor = 0xFFFF9F0A.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(20f), dp(20f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val timeTv = TextView(this).apply {
            text = computeTimerString()
            setTextColor(0xFFFF9F0A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        liveTimerTv = timeTv
        row.addView(icon)
        row.addView(spacer)
        row.addView(timeTv)
        return row
    }

    private fun buildTimerBigView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20f), dp(16f), dp(20f), dp(16f))
        }
        val leftCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val lbl = TextView(this).apply {
            text = activeTimerItem?.title ?: "Live Timer"
            setTextColor(0xFFFF9F0A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val bigTime = TextView(this).apply {
            text = computeTimerString()
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
        }
        liveTimerTv = bigTime
        leftCol.addView(lbl)
        leftCol.addView(bigTime)
        row.addView(leftCol)

        val closeBtn = FrameLayout(this).apply {
            background = roundedBg(0xFF2C2C36.toInt(), dpF(21f))
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f))
            val ic = ControlIconView(this@IslandListenerService, ControlIconView.KIND_CLOSE).apply {
                layoutParams = FrameLayout.LayoutParams(dp(20f), dp(20f), Gravity.CENTER)
            }
            addView(ic)
            setOnClickListener {
                hapticTick()
                activeTimerItem = null
                decideNextState(forceRebuild = true)
            }
        }
        row.addView(closeBtn)
        return row
    }

    private fun buildFlashlightSmallView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11f), 0, dp(13f), 0)
        }
        val ic = ControlIconView(this, ControlIconView.KIND_FLASHLIGHT).apply {
            iconColor = 0xFFFFD60A.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(19f), dp(19f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val pctTv = TextView(this).apply {
            text = "ON"
            setTextColor(0xFFFFD60A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        row.addView(ic)
        row.addView(spacer)
        row.addView(pctTv)
        return row
    }

    private fun buildFlashlightBigView(): View {
        return FlashlightBeamView(this).apply {
            isTorchOn = isTorchActive
            intensity = torchIntensity
            beamSpread = torchSpread
            onIntensityChanged = { newInt, newSpread ->
                torchIntensity = newInt
                torchSpread = newSpread
                resetCollapseTimer()
            }
            onToggleTorch = { on ->
                hapticTick()
                toggleHardwareTorch(on)
                if (!on) {
                    handler.postDelayed({ decideNextState() }, 450L)
                } else {
                    resetCollapseTimer()
                }
            }
        }
    }

    private fun buildNavSmallView(): View {
        val nav = activeNavItem
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11f), 0, dp(12f), 0)
        }
        val ic = ControlIconView(this, ControlIconView.KIND_NAV_ARROW).apply {
            iconColor = 0xFF30D158.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(19f), dp(19f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val distTv = TextView(this).apply {
            text = nav?.text?.substringBefore("•")?.trim()?.ifEmpty { "350 m" } ?: "350 m"
            setTextColor(0xFF30D158.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
        }
        row.addView(ic)
        row.addView(spacer)
        row.addView(distTv)
        return row
    }

    private fun buildNavBigView(): View {
        val nav = activeNavItem
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(16f), dp(18f), dp(14f))
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val badge = FrameLayout(this).apply {
            background = roundedBg(0x2830D158, dpF(14f))
            layoutParams = LinearLayout.LayoutParams(dp(44f), dp(44f))
            val ic = ControlIconView(this@IslandListenerService, ControlIconView.KIND_NAV_ARROW).apply {
                iconColor = 0xFF30D158.toInt()
                layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER)
            }
            addView(ic)
        }
        topRow.addView(badge)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12f)
            }
        }
        val t1 = TextView(this).apply {
            text = nav?.title ?: "Turn right onto MG Road"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val t2 = TextView(this).apply {
            text = nav?.text ?: "350 m • 14 min remaining"
            setTextColor(0xFF30D158.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 1
        }
        col.addView(t1)
        col.addView(t2)
        topRow.addView(col)
        root.addView(topRow)

        val botRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12f) }
        }
        val etaTv = TextView(this).apply {
            text = nav?.subText?.ifEmpty { "Live GPS Guidance" } ?: "Live GPS Guidance"
            setTextColor(0xFF9898A4.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val endBtn = TextView(this).apply {
            text = "Dismiss"
            setTextColor(0xFFFF453A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0x28FF453A, dpF(12f))
            setPadding(dp(14f), dp(6f), dp(14f), dp(6f))
            setOnClickListener {
                hapticTick()
                activeNavItem = null
                decideNextState(forceRebuild = true)
            }
        }
        botRow.addView(etaTv)
        botRow.addView(endBtn)
        root.addView(botRow)
        return root
    }

    private fun buildUberSmallView(): View {
        val ride = activeRideItem
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11f), 0, dp(12f), 0)
        }
        val ic = ControlIconView(this, ControlIconView.KIND_CAR).apply {
            iconColor = 0xFF32ADE6.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(20f), dp(20f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val eta = TextView(this).apply {
            text = ride?.title?.ifEmpty { "3 min" } ?: "3 min"
            setTextColor(0xFF32ADE6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
        }
        row.addView(ic)
        row.addView(spacer)
        row.addView(eta)
        return row
    }

    private fun buildUberBigView(): View {
        val ride = activeRideItem
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(16f), dp(18f), dp(14f))
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t1 = TextView(this).apply {
            text = ride?.title ?: "Arriving in 3 min"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
        }
        val t2 = TextView(this).apply {
            text = ride?.text ?: "White Swift Dzire • UP14 AB 4921"
            setTextColor(0xFFB8B8C4.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            maxLines = 1
        }
        col.addView(t1)
        col.addView(t2)
        topRow.addView(col)

        val plateBadge = TextView(this).apply {
            text = ride?.subText?.ifEmpty { "LIVE" } ?: "LIVE"
            setTextColor(0xFF32ADE6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0x2632ADE6, dpF(10f))
            setPadding(dp(10f), dp(5f), dp(10f), dp(5f))
        }
        topRow.addView(plateBadge)
        root.addView(topRow)

        val prog = ProgressLine(this).apply {
            activeColor = 0xFF32ADE6.toInt()
            progress = (ride?.progressPct ?: 75) / 100f
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(18f)).apply {
                topMargin = dp(12f)
            }
        }
        root.addView(prog)

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4f) }
        }
        val s1 = TextView(this).apply {
            text = "Confirmed"
            setTextColor(0xFF888894.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val s2 = TextView(this).apply {
            text = "On the way"
            setTextColor(0xFF32ADE6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val s3 = TextView(this).apply {
            text = "Arriving"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        statusRow.addView(s1)
        statusRow.addView(s2)
        statusRow.addView(s3)
        root.addView(statusRow)
        return root
    }

    private fun buildRecordSmallView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11f), 0, dp(12f), 0)
        }
        val ic = ControlIconView(this, ControlIconView.KIND_RECORD_DOT).apply {
            iconColor = 0xFFFF453A.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(18f), dp(18f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val recTv = TextView(this).apply {
            text = "REC"
            setTextColor(0xFFFF453A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        row.addView(ic)
        row.addView(spacer)
        row.addView(recTv)
        return row
    }

    private fun buildRecordBigView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18f), dp(14f), dp(18f), dp(14f))
        }
        val ic = ControlIconView(this, ControlIconView.KIND_RECORD_DOT).apply {
            iconColor = 0xFFFF453A.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(28f), dp(28f))
        }
        row.addView(ic)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12f)
            }
        }
        val t1 = TextView(this).apply {
            text = "Screen Recording"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val t2 = TextView(this).apply {
            text = "Capturing display & audio"
            setTextColor(0xFFFF453A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        col.addView(t1)
        col.addView(t2)
        row.addView(col)

        val stopBtn = TextView(this).apply {
            text = "Stop"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFFFF453A.toInt(), dpF(14f))
            setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
            setOnClickListener {
                hapticTick()
                try { activeRecordItem?.actions?.firstOrNull()?.intent?.send() } catch (_: Throwable) {}
                activeRecordItem = null
                decideNextState(forceRebuild = true)
            }
        }
        row.addView(stopBtn)
        return row
    }

    private fun buildSystemHudView(): View {
        val hud = activeHud ?: SystemHudData("Charging", "Super Fast", "88%", 0xFF30D158.toInt(), 0, 88, true)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13f), 0, dp(14f), 0)
        }

        val leftWidget: View = if (hud.hudKind == 0) {
            BatteryGraphicView(this).apply {
                levelPct = hud.batteryLevel
                isCharging = hud.isCharging
                layoutParams = LinearLayout.LayoutParams(dp(32f), dp(20f))
            }
        } else {
            ControlIconView(this, hud.iconKind).apply {
                iconColor = hud.accentColor
                layoutParams = LinearLayout.LayoutParams(dp(22f), dp(22f))
            }
        }
        row.addView(leftWidget)

        val titleTv = TextView(this).apply {
            text = hud.title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(10f)
                rightMargin = dp(8f)
            }
        }
        row.addView(titleTv)

        val badgeTv = TextView(this).apply {
            text = hud.badgeText
            setTextColor(hud.accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        row.addView(badgeTv)
        return row
    }

    private fun buildCallView(): View {
        val item = activeItem ?: return View(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(16f), dp(16f), dp(14f))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val avatar = buildAvatarView(item, sizeDp = 44f)
        topRow.addView(avatar)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12f)
                rightMargin = dp(8f)
            }
        }
        val nameTv = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val subTv = TextView(this).apply {
            text = item.text.ifEmpty { item.appName }
            setTextColor(0xFF30D158.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        textCol.addView(nameTv)
        textCol.addView(subTv)
        topRow.addView(textCol)

        val declineAct = item.actions.firstOrNull { it.isNegative } ?: item.actions.firstOrNull()
        val answerAct = item.actions.firstOrNull { it.isPositive } ?: item.actions.getOrNull(1)

        val declineBtn = FrameLayout(this).apply {
            background = roundedBg(0xFFFF453A.toInt(), dpF(21f))
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f)).apply {
                rightMargin = dp(10f)
            }
            val ic = ControlIconView(this@IslandListenerService, ControlIconView.KIND_PHONE_DECLINE).apply {
                layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER)
            }
            addView(ic)
            setOnClickListener {
                hapticTick()
                try { declineAct?.intent?.send() } catch (_: Throwable) {}
                dismissActiveItem()
            }
        }

        val answerBtn = FrameLayout(this).apply {
            background = roundedBg(0xFF30D158.toInt(), dpF(21f))
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f))
            val ic = ControlIconView(this@IslandListenerService, ControlIconView.KIND_PHONE_ACCEPT).apply {
                layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER)
            }
            addView(ic)
            setOnClickListener {
                hapticTick()
                try { answerAct?.intent?.send() } catch (_: Throwable) {}
                dismissActiveItem()
            }
        }

        topRow.addView(declineBtn)
        topRow.addView(answerBtn)
        root.addView(topRow)
        return root
    }

    /**
     * Dynamic Motion's Compact Notification Pill (shows app avatar left, sender/message snippet right,
     * and expands on tap or auto-expand).
     */
    private fun buildNotifCompactView(): View {
        val item = activeItem ?: return View(this)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(14f), 0)
        }
        val avatar = buildAvatarView(item, sizeDp = 24f)
        row.addView(avatar)

        val titleTv = TextView(this).apply {
            text = "${item.title}: ${item.text}".trimEnd(':', ' ')
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(10f)
            }
        }
        row.addView(titleTv)
        return row
    }

    /**
     * Dynamic Motion's Expanded Notification Card with Inline RemoteInput Reply box!
     */
    private fun buildNotifExpandedView(): View {
        val item = activeItem ?: return View(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
        }

        val mainRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val iconView = buildAvatarView(item, sizeDp = 42f)
        mainRow.addView(iconView)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12f)
            }
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleTv = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val appBadgeTv = TextView(this).apply {
            text = item.appName
            setTextColor(item.accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = dp(6f)
            }
        }
        headerRow.addView(titleTv)
        headerRow.addView(appBadgeTv)
        textCol.addView(headerRow)

        if (item.text.isNotEmpty()) {
            val bodyTv = TextView(this).apply {
                text = item.text
                setTextColor(0xFFD0D0DA.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(2f) }
            }
            textCol.addView(bodyTv)
        }

        mainRow.addView(textCol)
        root.addView(mainRow)

        // Action pills + Inline Reply support
        val replyBoxContainer = FrameLayout(this)
        val actRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10f) }
        }

        val actionsToShow = if (item.actions.isNotEmpty()) {
            item.actions.take(3)
        } else {
            listOf(ActionBtn("Open", item.contentIntent), ActionBtn("Dismiss", null))
        }

        actionsToShow.forEach { act ->
            val pill = TextView(this).apply {
                text = act.label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                background = roundedBg(0xFF262836.toInt(), dpF(14f), dp(1f), 0x33FFFFFF)
                setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(8f) }
                setOnClickListener {
                    hapticTick()
                    val hasRemote = !act.remoteInputs.isNullOrEmpty() || act.label.equals("Reply", ignoreCase = true)
                    if (hasRemote) {
                        showInlineReplyRow(replyBoxContainer, actRow, item, act)
                    } else {
                        try { act.intent?.send() } catch (_: Throwable) {}
                        dismissActiveItem()
                    }
                }
            }
            actRow.addView(pill)
        }
        root.addView(actRow)
        root.addView(replyBoxContainer)

        return root
    }

    private fun showInlineReplyRow(
        container: FrameLayout,
        actRow: View,
        item: IslandItem,
        act: ActionBtn
    ) {
        handler.removeCallbacks(autoDismissRunnable)
        actRow.visibility = View.GONE
        setTouchWindowFocusable(true)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8f) }
        }

        val input = EditText(this).apply {
            hint = "Reply to ${item.title}..."
            setHintTextColor(0xFF808292.toInt())
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = roundedBg(0xFF222432.toInt(), dpF(14f), dp(1f), 0x445E5CE6)
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val sendBtn = TextView(this).apply {
            text = "Send"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF5E5CE6.toInt(), dpF(14f))
            setPadding(dp(14f), dp(7f), dp(14f), dp(7f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = dp(8f) }
            setOnClickListener {
                val msg = input.text?.toString()?.trim() ?: ""
                if (msg.isNotEmpty() && act.intent != null && !act.remoteInputs.isNullOrEmpty()) {
                    try {
                        val fillIn = Intent()
                        val bundle = Bundle()
                        for (ri in act.remoteInputs) {
                            bundle.putCharSequence(ri.resultKey, msg)
                        }
                        RemoteInput.addResultsToIntent(act.remoteInputs, fillIn, bundle)
                        act.intent.send(this@IslandListenerService, 0, fillIn)
                    } catch (_: Throwable) {}
                } else {
                    Toast.makeText(this@IslandListenerService, "Reply sent!", Toast.LENGTH_SHORT).show()
                }
                setTouchWindowFocusable(false)
                dismissActiveItem()
            }
        }

        row.addView(input)
        row.addView(sendBtn)
        container.removeAllViews()
        container.addView(row)
        input.requestFocus()
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        } catch (_: Throwable) {}
    }

    /**
     * Dynamic Motion's Swipe-Down Notification Dock (inspired by l9/x.java & l9/z.java).
     * Displays recent notification cards inside the expanded Island when swiped down.
     */
    private fun buildNotifDockView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val hTitle = TextView(this).apply {
            text = "Notification Dock (${notifHistory.size})"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val clearBtn = TextView(this).apply {
            text = "Close"
            setTextColor(0xFF5E5CE6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setOnClickListener {
                hapticTick()
                decideNextState(forceRebuild = true)
            }
        }
        headerRow.addView(hTitle)
        headerRow.addView(clearBtn)
        root.addView(headerRow)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { topMargin = dp(8f) }
        }
        val listCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        if (notifHistory.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No recent notifications yet. Tap 'Message' in the app preview bar to test!"
                setTextColor(0xFF888894.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, dp(18f), 0, dp(18f))
            }
            listCol.addView(emptyTv)
        } else {
            notifHistory.take(5).forEach { item ->
                val itemRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = roundedBg(0xFF1A1C28.toInt(), dpF(12f))
                    setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(6f) }
                    setOnClickListener {
                        hapticTick()
                        try { item.contentIntent?.send() } catch (_: Throwable) {}
                        decideNextState(forceRebuild = true)
                    }
                }
                val av = buildAvatarView(item, sizeDp = 28f)
                itemRow.addView(av)
                val col = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        leftMargin = dp(10f)
                    }
                }
                val t1 = TextView(this).apply {
                    text = "${item.title} • ${item.appName}"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    maxLines = 1
                }
                val t2 = TextView(this).apply {
                    text = item.text
                    setTextColor(0xFFA8A8B4.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    maxLines = 1
                }
                col.addView(t1)
                col.addView(t2)
                itemRow.addView(col)
                listCol.addView(itemRow)
            }
        }
        scroll.addView(listCol)
        root.addView(scroll)
        return root
    }

    /**
     * Dynamic Motion's Custom Plugin Quick-Action Launcher (inspired by b9/o.java & b9/d0.java).
     * Opens when long-pressing the idle pill so the user has instant toggles for Flashlight,
     * Ringer Mode, Media Demo, Notification Dock, and Island Settings!
     */
    private fun buildQuickLauncherView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        }

        val titleTv = TextView(this).apply {
            text = "Island Quick Actions"
            setTextColor(0xFFA0A2B4.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(titleTv)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10f) }
        }

        fun addTile(label: String, iconKind: Int, color: Int, onClick: () -> Unit) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    hapticTick()
                    onClick()
                }
            }
            val circle = FrameLayout(this).apply {
                background = roundedBg(color, dpF(21f))
                layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f))
                val ic = ControlIconView(this@IslandListenerService, iconKind).apply {
                    layoutParams = FrameLayout.LayoutParams(dp(20f), dp(20f), Gravity.CENTER)
                }
                addView(ic)
            }
            val tv = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4f) }
            }
            col.addView(circle)
            col.addView(tv)
            btnRow.addView(col)
        }

        addTile("Torch", ControlIconView.KIND_FLASHLIGHT, if (isTorchActive) 0xFFFF9F0A.toInt() else 0xFF282A38.toInt()) {
            toggleHardwareTorch(!isTorchActive)
            transitionToMode(Mode.FLASHLIGHT_BIG, forceRebuild = true)
            resetCollapseTimer()
        }
        addTile("Music", ControlIconView.KIND_PLAY, 0xFF30D158.toInt()) {
            triggerPreview("music")
        }
        addTile("Dock", ControlIconView.KIND_RINGER_NORMAL, 0xFF5E5CE6.toInt()) {
            transitionToMode(Mode.NOTIF_DOCK, forceRebuild = true)
            resetCollapseTimer()
        }
        addTile("Settings", ControlIconView.KIND_TIMER, 0xFF32ADE6.toInt()) {
            try {
                val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (_: Throwable) {}
            decideNextState(forceRebuild = true)
        }

        root.addView(btnRow)
        return root
    }

    private fun buildAvatarView(item: IslandItem, sizeDp: Float): View {
        val sz = dp(sizeDp)
        return ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(dpF(sizeDp / 2f))
            background = roundedBg(0xFF232530.toInt(), dpF(sizeDp / 2f))
            if (item.largeBitmap != null) {
                setImageBitmap(item.largeBitmap)
            } else if (item.icon != null) {
                val p = dp(sizeDp * 0.18f)
                setPadding(p, p, p, p)
                setImageDrawable(item.icon)
            } else {
                val p = dp(sizeDp * 0.18f)
                setPadding(p, p, p, p)
                try {
                    setImageDrawable(packageManager.getApplicationIcon(packageName))
                } catch (_: Throwable) {}
            }
            layoutParams = LinearLayout.LayoutParams(sz, sz)
        }
    }

    /**
     * Forwards touch events from the compact touch window (`touchWindowView`) to the
     * full-width visual canvas (`visualHostView`) with coordinate translation, press-scale
     * spring physics, outside-tap collapse, swipe-up dismiss, and swipe-down Notification Dock.
     */
    private fun attachTouchForwarder(touchView: View, host: LiquidIslandHostView) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var downTime = 0L
        var longPressed = false

        val longPressRunnable = Runnable {
            longPressed = true
            animatePressScale(false)
            hapticTick()
            handleLongPressGesture()
        }

        touchView.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                if (isExpandedMode(currentMode)) {
                    setTouchWindowFocusable(false)
                    decideNextState(forceRebuild = true)
                }
                return@setOnTouchListener false
            }

            // Forward translated touch event to visualHostView so interactive child buttons/sliders work
            val tParams = touchLp
            if (tParams != null) {
                val copy = MotionEvent.obtain(ev)
                copy.offsetLocation(tParams.x.toFloat(), tParams.y.toFloat())
                try {
                    host.dispatchTouchEvent(copy)
                } catch (_: Throwable) {
                } finally {
                    copy.recycle()
                }
            }

            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    downTime = SystemClock.elapsedRealtime()
                    longPressed = false
                    animatePressScale(true)
                    handler.postDelayed(longPressRunnable, 460L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        handler.removeCallbacks(longPressRunnable)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPressRunnable)
                    animatePressScale(false)
                    if (!longPressed) {
                        val dx = ev.rawX - downRawX
                        val dy = ev.rawY - downRawY
                        if (dy < -dp(22f) && abs(dy) > abs(dx)) {
                            // Swipe UP -> Collapse or Dismiss
                            hapticTick()
                            handleSwipeUpDismiss()
                        } else if (dy > dp(26f) && abs(dy) > abs(dx) && !isExpandedMode(currentMode)) {
                            // Swipe DOWN on compact pill -> Expand or open Notification Dock
                            hapticTick()
                            handleSwipeDownExpand()
                        } else if (abs(dx) < touchSlop && abs(dy) < touchSlop &&
                            SystemClock.elapsedRealtime() - downTime < 460L
                        ) {
                            // Check if user tapped the detached secondary metaball bubble
                            if (host.isTouchInsideBubble(ev.rawX, ev.rawY)) {
                                host.onBubbleTap?.invoke()
                            } else if (!isExpandedMode(currentMode)) {
                                handleCompactTapGesture()
                            }
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun handleCompactTapGesture() {
        hapticTick()
        when (currentMode) {
            Mode.IDLE_PILL -> {
                if (Prefs.isPluginCustomLauncher(this)) {
                    transitionToMode(Mode.QUICK_LAUNCHER, forceRebuild = true)
                    resetCollapseTimer()
                } else {
                    triggerPreview("notif")
                }
            }
            Mode.MEDIA_SMALL -> {
                transitionToMode(Mode.MEDIA_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.TIMER_SMALL -> {
                transitionToMode(Mode.TIMER_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.FLASHLIGHT_SMALL -> {
                transitionToMode(Mode.FLASHLIGHT_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.NAV_SMALL -> {
                transitionToMode(Mode.NAV_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.UBER_SMALL -> {
                transitionToMode(Mode.UBER_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.RECORD_SMALL -> {
                transitionToMode(Mode.RECORD_BIG, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.NOTIF_COMPACT -> {
                scheduleAutoDismiss(8_000L)
                transitionToMode(Mode.NOTIF_EXPANDED, forceRebuild = true)
            }
            Mode.SYSTEM_HUD -> {
                activeHud = null
                decideNextState(forceRebuild = true)
            }
            else -> {}
        }
    }

    private fun handleSwipeDownExpand() {
        when (currentMode) {
            Mode.IDLE_PILL -> {
                transitionToMode(Mode.NOTIF_DOCK, forceRebuild = true)
                resetCollapseTimer()
            }
            else -> handleCompactTapGesture()
        }
    }

    private fun handleLongPressGesture() {
        when (currentMode) {
            Mode.IDLE_PILL -> {
                transitionToMode(Mode.QUICK_LAUNCHER, forceRebuild = true)
                resetCollapseTimer()
            }
            Mode.MEDIA_SMALL -> transitionToMode(Mode.MEDIA_BIG, forceRebuild = true)
            Mode.MEDIA_BIG -> openMediaSessionApp()
            Mode.NOTIF_COMPACT -> transitionToMode(Mode.NOTIF_EXPANDED, forceRebuild = true)
            Mode.NOTIF_EXPANDED -> {
                try { activeItem?.contentIntent?.send() } catch (_: Throwable) {}
                dismissActiveItem()
            }
            else -> {
                if (isExpandedMode(currentMode)) {
                    setTouchWindowFocusable(false)
                    decideNextState(forceRebuild = true)
                }
            }
        }
    }

    private fun handleSwipeUpDismiss() {
        setTouchWindowFocusable(false)
        when (currentMode) {
            Mode.NOTIF_COMPACT, Mode.NOTIF_EXPANDED, Mode.CALL -> dismissActiveItem()
            Mode.MEDIA_BIG -> transitionToMode(Mode.MEDIA_SMALL, forceRebuild = true)
            Mode.MEDIA_SMALL -> {
                mediaDismissedUntilChange = true
                decideNextState(forceRebuild = true)
            }
            Mode.FLASHLIGHT_BIG -> transitionToMode(Mode.FLASHLIGHT_SMALL, forceRebuild = true)
            Mode.FLASHLIGHT_SMALL -> {
                torchDismissed = true
                decideNextState(forceRebuild = true)
            }
            Mode.TIMER_BIG -> transitionToMode(Mode.TIMER_SMALL, forceRebuild = true)
            Mode.TIMER_SMALL -> {
                activeTimerItem = null
                decideNextState(forceRebuild = true)
            }
            Mode.NAV_BIG -> transitionToMode(Mode.NAV_SMALL, forceRebuild = true)
            Mode.UBER_BIG -> transitionToMode(Mode.UBER_SMALL, forceRebuild = true)
            Mode.RECORD_BIG -> transitionToMode(Mode.RECORD_SMALL, forceRebuild = true)
            Mode.NOTIF_DOCK, Mode.QUICK_LAUNCHER -> decideNextState(forceRebuild = true)
            Mode.SYSTEM_HUD -> {
                activeHud = null
                decideNextState(forceRebuild = true)
            }
            else -> {}
        }
    }

    private fun dismissActiveItem() {
        setTouchWindowFocusable(false)
        handler.removeCallbacks(autoDismissRunnable)
        activeItem = notifQueue.removeFirstOrNull()
        if (activeItem != null) {
            scheduleAutoDismiss(activeItem!!.durationMs)
            decideNextState(forceRebuild = true)
        } else {
            decideNextState(forceRebuild = true)
        }
    }

    private fun openMediaSessionApp() {
        try {
            val sa = activeController?.sessionActivity
            if (sa != null) {
                sa.send()
                return
            }
            val pkg = activeController?.packageName
            if (!pkg.isNullOrEmpty()) {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun resetCollapseTimer() {
        handler.removeCallbacks(mediaCollapseRunnable)
        handler.postDelayed(mediaCollapseRunnable, 8_500L)
    }

    private fun updateLiveTickers() {
        if (currentMode == Mode.MEDIA_BIG && mediaDuration > 0L) {
            val pos = if (mediaPlaying) {
                val delta = SystemClock.elapsedRealtime() - mediaLastStateTime
                (mediaPosition + max(0L, delta)).coerceAtMost(mediaDuration)
            } else {
                mediaPosition
            }
            liveSeekLine?.progress = pos.toFloat() / mediaDuration.toFloat()
            liveElapsedTv?.text = formatMs(pos)
            liveTotalTv?.text = formatMs(mediaDuration)
        }
        if (currentMode == Mode.TIMER_SMALL || currentMode == Mode.TIMER_BIG) {
            liveTimerTv?.text = computeTimerString()
        }
    }

    private fun computeTimerString(): String {
        val t = activeTimerItem ?: return "02:45"
        val now = System.currentTimeMillis()
        val diff = if (t.chronometerCountDown || t.whenMs > now) {
            max(0L, t.whenMs - now)
        } else {
            max(0L, now - t.whenMs)
        }
        return formatMs(diff)
    }

    private fun formatMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val m = totalSec / 60L
        val s = totalSec % 60L
        return String.format("%d:%02d", m, s)
    }

    private fun hapticTick() {
        if (!Prefs.isHaptics(this)) return
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 29) {
                vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            } else if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createOneShot(14L, 90))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(14L)
            }
        } catch (_: Throwable) {}
    }

    private fun drawableToBitmap(drawable: Drawable?): Bitmap? {
        if (drawable == null) return null
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val w = drawable.intrinsicWidth.coerceAtLeast(64)
        val h = drawable.intrinsicHeight.coerceAtLeast(64)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, w, h)
        drawable.draw(canvas)
        return bmp
    }
}
