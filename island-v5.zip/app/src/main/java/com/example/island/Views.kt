package com.example.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

fun Context.dp(v: Float): Int =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

fun Context.dpF(v: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            val w = view.width
            val h = view.height
            if (w > 0 && h > 0) {
                outline.setRoundRect(0, 0, w, h, radiusPx)
            }
        }
    }
    clipToOutline = true
}

fun roundedBg(fillColor: Int, radiusPx: Float, strokeWidthPx: Int = 0, strokeColor: Int = 0): GradientDrawable {
    return GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx
        setColor(fillColor)
        if (strokeWidthPx > 0) {
            setStroke(strokeWidthPx, strokeColor)
        }
    }
}

fun extractDominantColor(bmp: Bitmap?, fallback: Int = 0xFF5E5CE6.toInt()): Int {
    if (bmp == null || bmp.isRecycled) return fallback
    return try {
        val scaled = Bitmap.createScaledBitmap(bmp, 16, 16, false)
        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        var count = 0L
        for (x in 0 until scaled.width) {
            for (y in 0 until scaled.height) {
                val c = scaled.getPixel(x, y)
                if (Color.alpha(c) < 128) continue
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val weight = if (maxCh - minCh > 26 && maxCh in 40..248) 5 else 1
                rSum += r * weight
                gSum += g * weight
                bSum += b * weight
                count += weight
            }
        }
        if (count == 0L) return fallback
        val hsv = FloatArray(3)
        Color.RGBToHSV((rSum / count).toInt(), (gSum / count).toInt(), (bSum / count).toInt(), hsv)
        hsv[1] = hsv[1].coerceIn(0.55f, 0.95f)
        hsv[2] = hsv[2].coerceIn(0.80f, 1.0f)
        Color.HSVToColor(hsv)
    } catch (_: Throwable) {
        fallback
    }
}

/**
 * Dynamic Motion-inspired Full-Width Liquid Metaball Canvas Host.
 *
 * Unlike a standard small window that clips spring overshoots, this view sits inside a
 * full-width transparent top overlay container and draws:
 *  1. Ambient Media / Plugin Glow behind the pill
 *  2. Main Dynamic Island Squircle Pill (with jelly stretch & press-scale)
 *  3. Liquid Metaball Detached Secondary Bubble on the right + organic cubic Bezier neck
 *     when two activities run concurrently (e.g. Music + Live Timer / Flashlight)
 *  4. Animated Neon Rim Stroke clipped cleanly to the pill path
 *  5. Velocity-based RenderEffect Motion Blur on Android 12+ (Galaxy A52s)
 */
class LiquidIslandHostView(context: Context) : FrameLayout(context) {

    val mainContentHolder = FrameLayout(context).apply {
        clipChildren = false
        clipToPadding = false
    }

    val bubbleContentHolder = FrameLayout(context).apply {
        clipChildren = true
        clipToPadding = false
        visibility = View.GONE
    }

    private val blackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.BLACK
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val rimStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(1.6f)
    }

    private val pillPath = Path()
    private val bubblePath = Path()
    private val neckPath = Path()
    private val pillRect = RectF()
    private val bubbleRect = RectF()

    // Animated Geometry State (in pixels)
    var pillCenterX: Float = 0f
    var pillTopY: Float = context.dpF(5f)
    var pillWidth: Float = context.dpF(96f)
    var pillHeight: Float = context.dpF(33f)
    var pillCornerRadius: Float = context.dpF(18f)

    // Detached Secondary Bubble State (0f = absorbed, 1f = fully emerged to the right)
    var bubbleProgress: Float = 0f
    var bubbleSizePx: Float = context.dpF(34f)
    var bubbleGapPx: Float = context.dpF(9f)
    var onBubbleTap: (() -> Unit)? = null

    // Jelly & Press Physics
    var pressScale: Float = 1.0f
    var jellyStretchX: Float = 0f
    var jellyStretchY: Float = 0f
    var shakeOffsetX: Float = 0f

    // Visual Styling
    var showStroke: Boolean = true
    var showAmbientGlow: Boolean = true
    var accentColor: Int = 0xFF5E5CE6.toInt()
    private var currentBlurPx: Float = 0f

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false
        addView(mainContentHolder, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        addView(bubbleContentHolder, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
    }

    fun updateGeometry(
        cx: Float,
        topY: Float,
        w: Float,
        h: Float,
        cornerRadius: Float,
        velX: Float = 0f,
        velY: Float = 0f,
        blurEnabled: Boolean = true
    ) {
        pillCenterX = cx
        pillTopY = topY
        pillWidth = w.coerceAtLeast(context.dpF(24f))
        pillHeight = h.coerceAtLeast(context.dpF(20f))
        pillCornerRadius = min(cornerRadius, min(pillWidth, pillHeight) / 2f)

        // Position mainContentHolder exactly over the pill rect
        val left = (cx - pillWidth / 2f + shakeOffsetX).toInt()
        val top = topY.toInt()
        val lp = mainContentHolder.layoutParams as LayoutParams
        val targetW = pillWidth.toInt()
        val targetH = pillHeight.toInt()
        if (lp.width != targetW || lp.height != targetH || lp.leftMargin != left || lp.topMargin != top) {
            lp.width = targetW
            lp.height = targetH
            lp.leftMargin = left
            lp.topMargin = top
            mainContentHolder.layoutParams = lp
        }
        mainContentHolder.roundClip(pillCornerRadius)

        // Position detached secondary bubble if active
        if (bubbleProgress > 0.02f) {
            bubbleContentHolder.visibility = View.VISIBLE
            val bSize = (bubbleSizePx * (0.65f + 0.35f * bubbleProgress)).toInt()
            val pillRight = cx + pillWidth / 2f
            val bCenterX = pillRight + (bubbleGapPx + bubbleSizePx / 2f) * bubbleProgress
            val bCenterY = topY + pillHeight / 2f
            val bLp = bubbleContentHolder.layoutParams as LayoutParams
            val bLeft = (bCenterX - bSize / 2f).toInt()
            val bTop = (bCenterY - bSize / 2f).toInt()
            if (bLp.width != bSize || bLp.height != bSize || bLp.leftMargin != bLeft || bLp.topMargin != bTop) {
                bLp.width = bSize
                bLp.height = bSize
                bLp.leftMargin = bLeft
                bLp.topMargin = bTop
                bubbleContentHolder.layoutParams = bLp
            }
            bubbleContentHolder.alpha = bubbleProgress.coerceIn(0f, 1f)
            bubbleContentHolder.roundClip(bSize / 2f)
        } else {
            bubbleContentHolder.visibility = View.GONE
        }

        // Dynamic Motion velocity-based RenderEffect blur (Android 12+ / API 31+)
        if (Build.VERSION.SDK_INT >= 31) {
            val speed = sqrt(velX * velX + velY * velY)
            val normSpeed = (speed / 2200f).coerceIn(0f, 1f)
            val desiredBlur = if (blurEnabled && normSpeed > 0.12f) {
                (normSpeed * context.dpF(3.2f)).coerceAtMost(context.dpF(4.5f))
            } else {
                0f
            }
            if (abs(desiredBlur - currentBlurPx) > 0.4f) {
                currentBlurPx = desiredBlur
                try {
                    mainContentHolder.setRenderEffect(
                        if (desiredBlur > 0.5f) {
                            RenderEffect.createBlurEffect(desiredBlur, desiredBlur, Shader.TileMode.CLAMP)
                        } else null
                    )
                } catch (_: Throwable) {}
            }
        }

        invalidate()
    }

    fun getInteractiveBounds(outRect: android.graphics.Rect) {
        val left = (pillCenterX - pillWidth / 2f - context.dpF(8f)).toInt()
        val extraRight = if (bubbleProgress > 0.05f) {
            (bubbleGapPx + bubbleSizePx + context.dpF(10f)).toInt()
        } else {
            context.dpF(8f).toInt()
        }
        val right = (pillCenterX + pillWidth / 2f + extraRight).toInt()
        val top = (pillTopY - context.dpF(6f)).toInt().coerceAtLeast(0)
        val bottom = (pillTopY + pillHeight + context.dpF(10f)).toInt()
        outRect.set(left, top, right, bottom)
    }

    fun isTouchInsideBubble(x: Float, y: Float): Boolean {
        if (bubbleProgress < 0.5f) return false
        val pillRight = pillCenterX + pillWidth / 2f
        val bCenterX = pillRight + (bubbleGapPx + bubbleSizePx / 2f) * bubbleProgress
        val bCenterY = pillTopY + pillHeight / 2f
        val dx = x - bCenterX
        val dy = y - bCenterY
        val r = bubbleSizePx * 0.65f
        return (dx * dx + dy * dy) <= r * r
    }

    override fun dispatchDraw(canvas: Canvas) {
        val cx = pillCenterX + shakeOffsetX
        val cy = pillTopY + pillHeight / 2f
        val scaleX = pressScale * (1f + jellyStretchX)
        val scaleY = pressScale * (1f + jellyStretchY)

        val drawW = pillWidth * scaleX
        val drawH = pillHeight * scaleY
        val left = cx - drawW / 2f
        val top = cy - drawH / 2f
        val right = cx + drawW / 2f
        val bottom = cy + drawH / 2f
        val r = min(pillCornerRadius * pressScale, min(drawW, drawH) / 2f)

        // 1. Ambient Glow when expanded or playing media
        if (showAmbientGlow && drawH > context.dpF(52f)) {
            val glowAlpha = ((drawH - context.dpF(52f)) / context.dpF(90f)).coerceIn(0f, 1f)
            val aInt = (glowAlpha * 72).toInt()
            if (aInt > 4) {
                val glowCol = (accentColor and 0x00FFFFFF) or (aInt shl 24)
                glowPaint.shader = RadialGradient(
                    cx, cy, max(drawW, drawH) * 0.72f,
                    intArrayOf(glowCol, 0x00000000),
                    floatArrayOf(0.2f, 1.0f),
                    Shader.TileMode.CLAMP
                )
                val pad = context.dpF(18f)
                canvas.drawRoundRect(
                    left - pad, top - pad / 2f, right + pad, bottom + pad,
                    r + pad, r + pad, glowPaint
                )
            }
        }

        // 2. Main Pill Path
        pillPath.reset()
        pillRect.set(left, top, right, bottom)
        pillPath.addRoundRect(pillRect, r, r, Path.Direction.CW)
        canvas.drawPath(pillPath, blackFillPaint)

        // 3. Detached Secondary Bubble + Liquid Metaball Neck (Dynamic Motion signature effect)
        if (bubbleProgress > 0.01f) {
            val bRadius = (bubbleSizePx * (0.6f + 0.4f * bubbleProgress)) / 2f
            val bCx = right + (bubbleGapPx + bubbleSizePx / 2f) * bubbleProgress
            val bCy = cy

            bubblePath.reset()
            bubbleRect.set(bCx - bRadius, bCy - bRadius, bCx + bRadius, bCy + bRadius)
            bubblePath.addOval(bubbleRect, Path.Direction.CW)
            canvas.drawPath(bubblePath, blackFillPaint)

            // Draw organic liquid metaball neck while bubble is emerging/splitting (0.05..0.88)
            val edgeGap = (bCx - bRadius) - right
            val maxNeckGap = context.dpF(13f)
            if (edgeGap < maxNeckGap) {
                val neckFactor = (1f - (edgeGap / maxNeckGap)).coerceIn(0f, 1f)
                val neckHalfH = bRadius * 0.78f * neckFactor
                if (neckHalfH > 1.2f) {
                    val x0 = right - r * 0.35f
                    val x1 = bCx - bRadius * 0.65f
                    val midX = (x0 + x1) * 0.5f
                    val pinch = neckHalfH * 0.42f

                    neckPath.reset()
                    neckPath.moveTo(x0, bCy - neckHalfH)
                    neckPath.quadTo(midX, bCy - pinch, x1, bCy - neckHalfH * 0.85f)
                    neckPath.lineTo(x1, bCy + neckHalfH * 0.85f)
                    neckPath.quadTo(midX, bCy + pinch, x0, bCy + neckHalfH)
                    neckPath.close()
                    canvas.drawPath(neckPath, blackFillPaint)
                }
            }

            if (showStroke) {
                val bRimColor = (accentColor and 0x00FFFFFF) or (0x66 shl 24)
                rimStrokePaint.shader = null
                rimStrokePaint.color = bRimColor
                canvas.drawPath(bubblePath, rimStrokePaint)
            }
        }

        // 4. Draw Child Views (main content & bubble content)
        super.dispatchDraw(canvas)

        // 5. Neon Rim Highlight around the main pill
        if (showStroke) {
            val inset = rimStrokePaint.strokeWidth / 2f
            pillRect.set(left + inset, top + inset, right - inset, bottom - inset)
            val c1 = (accentColor and 0x00FFFFFF) or (0x80 shl 24)
            val c2 = 0x24FFFFFF
            rimStrokePaint.shader = LinearGradient(
                left, top, right, bottom,
                intArrayOf(c1, c2, c1),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(pillRect, r - inset, r - inset, rimStrokePaint)
        }
    }
}

/**
 * Multi-bar animated music visualizer matching Dynamic Motion's 5-bar harmonic equalizer.
 */
class EqualizerView(context: Context, private val barCount: Int = 5) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF30D158.toInt()
    }
    private val barRect = RectF()
    private var phase = 0f
    var isPlaying: Boolean = true
        set(value) {
            if (field != value) {
                field = value
                updateAnim()
                invalidate()
            }
        }
    var barColor: Int = 0xFF30D158.toInt()
        set(value) {
            field = value
            paint.color = value
            invalidate()
        }

    private val animator = ValueAnimator.ofFloat(0f, (Math.PI * 2.0).toFloat()).apply {
        duration = 880L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    private fun updateAnim() {
        if (isAttachedToWindow && isPlaying && visibility == VISIBLE) {
            if (!animator.isStarted) animator.start()
        } else {
            animator.cancel()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnim()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun setVisibility(visibility: Int) {
        super.setVisibility(visibility)
        updateAnim()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val gap = context.dpF(2.2f)
        val totalGap = gap * (barCount - 1)
        val barW = ((w - totalGap) / barCount).coerceAtLeast(context.dpF(2f))
        val radius = barW / 2f

        for (i in 0 until barCount) {
            val ratio = if (isPlaying) {
                val freq = 1.0f + (i % 3) * 0.45f
                val wave = (sin((phase * freq + i * 1.25f).toDouble()).toFloat() + 1f) * 0.5f
                val envelope = if (i == 0 || i == barCount - 1) 0.65f else 1.0f
                (0.22f + wave * 0.75f * envelope).coerceIn(0.20f, 1.0f)
            } else {
                0.20f
            }
            val barH = (h * ratio).coerceAtLeast(barW)
            val left = i * (barW + gap)
            val top = (h - barH) / 2f
            barRect.set(left, top, left + barW, top + barH)
            canvas.drawRoundRect(barRect, radius, radius, paint)
        }
    }
}

/**
 * Dynamic Motion-style Lock Screen FaceID / Biometric Morphing View (inspired by f9/r.java).
 * Animates a padlock that unlocks and morphs into a glowing green checkmark when unlocked.
 */
class LockMorphView(context: Context) : View(context) {
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(2.2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val rect = RectF()
    private val path = Path()

    var unlockProgress: Float = 0f
        private set
    var isUnlocked: Boolean = false
        private set

    fun animateUnlock() {
        isUnlocked = true
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 520L
            interpolator = PathInterpolator(0.34f, 1.56f, 0.64f, 1f)
            addUpdateListener {
                unlockProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun setLockedState() {
        isUnlocked = false
        unlockProgress = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val s = min(w, h) * 0.36f

        val col = if (isUnlocked && unlockProgress > 0.45f) 0xFF30D158.toInt() else Color.WHITE
        strokePaint.color = col
        fillPaint.color = col

        // Body of padlock
        val bodyW = s * 1.35f
        val bodyH = s * 1.05f
        val bodyTop = cy - bodyH * 0.15f
        rect.set(cx - bodyW / 2f, bodyTop, cx + bodyW / 2f, bodyTop + bodyH)
        canvas.drawRoundRect(rect, s * 0.28f, s * 0.28f, strokePaint)

        // Shackle arch (lifts up as unlockProgress goes 0 -> 1)
        val shackleW = s * 0.82f
        val lift = unlockProgress * s * 0.35f
        rect.set(
            cx - shackleW / 2f,
            bodyTop - s * 0.72f - lift,
            cx + shackleW / 2f,
            bodyTop + s * 0.1f - lift
        )
        canvas.drawArc(rect, 180f, if (isUnlocked) 135f else 180f, false, strokePaint)

        // Checkmark inside body when unlocked
        if (unlockProgress > 0.3f) {
            val p = ((unlockProgress - 0.3f) / 0.7f).coerceIn(0f, 1f)
            path.reset()
            val startX = cx - s * 0.28f
            val startY = bodyTop + bodyH * 0.52f
            val midX = cx - s * 0.05f
            val midY = bodyTop + bodyH * 0.72f
            val endX = cx + s * 0.32f
            val endY = bodyTop + bodyH * 0.32f
            path.moveTo(startX, startY)
            if (p < 0.5f) {
                val t = p * 2f
                path.lineTo(startX + (midX - startX) * t, startY + (midY - startY) * t)
            } else {
                val t = (p - 0.5f) * 2f
                path.lineTo(midX, midY)
                path.lineTo(midX + (endX - midX) * t, midY + (endY - midY) * t)
            }
            canvas.drawPath(path, strokePaint)
        } else {
            canvas.drawCircle(cx, bodyTop + bodyH * 0.5f, s * 0.14f, fillPaint)
        }
    }
}

/**
 * Dynamic Motion-inspired Interactive Flashlight Beam Canvas View (inspired by d9/e.java).
 * Allows dragging vertically/horizontally to adjust beam intensity & cone width, plus toggling torch.
 */
class FlashlightBeamView(context: Context) : View(context) {
    private val conePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val torchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF2C2E3E.toInt()
    }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(2.2f)
        color = 0xFFFFD60A.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = context.dpF(13f)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA0A2B2.toInt()
        textSize = context.dpF(11f)
    }
    private val beamPath = Path()
    private val rect = RectF()

    var isTorchOn: Boolean = true
        set(value) {
            field = value
            invalidate()
        }
    var intensity: Float = 0.8f // 0.1 .. 1.0
        set(value) {
            field = value.coerceIn(0.1f, 1.0f)
            invalidate()
        }
    var beamSpread: Float = 0.6f // 0.25 .. 1.0
        set(value) {
            field = value.coerceIn(0.25f, 1.0f)
            invalidate()
        }

    var onIntensityChanged: ((Float, Float) -> Unit)? = null
    var onToggleTorch: ((Boolean) -> Unit)? = null

    private var downX = 0f
    private var downY = 0f
    private var startInt = 0.8f
    private var startSpread = 0.6f
    private var dragged = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x
                downY = event.y
                startInt = intensity
                startSpread = beamSpread
                dragged = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (abs(dx) > context.dpF(6f) || abs(dy) > context.dpF(6f)) {
                    dragged = true
                }
                if (dragged && width > 0 && height > 0) {
                    intensity = (startInt + dx / (width * 0.65f)).coerceIn(0.15f, 1.0f)
                    beamSpread = (startSpread - dy / (height * 0.7f)).coerceIn(0.25f, 1.0f)
                    if (!isTorchOn) {
                        isTorchOn = true
                        onToggleTorch?.invoke(true)
                    }
                    onIntensityChanged?.invoke(intensity, beamSpread)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragged) {
                    isTorchOn = !isTorchOn
                    onToggleTorch?.invoke(isTorchOn)
                }
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val pad = context.dpF(18f)
        val cy = h * 0.52f
        val torchLeft = pad
        val torchW = context.dpF(42f)
        val torchH = context.dpF(24f)

        // Draw glowing light cone from flashlight head to the right
        if (isTorchOn) {
            val coneStartX = torchLeft + torchW
            val coneEndX = w - pad
            val startHalfH = torchH * 0.45f
            val endHalfH = (h * 0.44f) * beamSpread

            beamPath.reset()
            beamPath.moveTo(coneStartX, cy - startHalfH)
            beamPath.lineTo(coneEndX, cy - endHalfH)
            beamPath.lineTo(coneEndX, cy + endHalfH)
            beamPath.lineTo(coneStartX, cy + startHalfH)
            beamPath.close()

            val alphaStart = (intensity * 215).toInt().coerceIn(40, 230)
            val colStart = (0xFFFFE066.toInt() and 0x00FFFFFF) or (alphaStart shl 24)
            val colMid = (0xFFFFD60A.toInt() and 0x00FFFFFF) or ((alphaStart / 2) shl 24)
            conePaint.shader = LinearGradient(
                coneStartX, cy, coneEndX, cy,
                intArrayOf(colStart, colMid, 0x00FFD60A),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawPath(beamPath, conePaint)
        }

        // Draw flashlight body
        torchPaint.color = if (isTorchOn) 0xFF383A4E.toInt() else 0xFF222430.toInt()
        rect.set(torchLeft, cy - torchH / 2f, torchLeft + torchW, cy + torchH / 2f)
        canvas.drawRoundRect(rect, context.dpF(7f), context.dpF(7f), torchPaint)

        accentPaint.color = if (isTorchOn) 0xFFFFD60A.toInt() else 0xFF686A78.toInt()
        canvas.drawRoundRect(rect, context.dpF(7f), context.dpF(7f), accentPaint)

        // Status text
        val pct = (intensity * 100).toInt()
        val statusStr = if (isTorchOn) "Flashlight ON • $pct%" else "Flashlight OFF (Tap)"
        canvas.drawText(statusStr, torchLeft + torchW + context.dpF(14f), h * 0.34f, textPaint)
        canvas.drawText("Drag left/right for brightness, up/down for beam", torchLeft + torchW + context.dpF(14f), h * 0.76f, subPaint)
    }
}

/**
 * Dynamic Motion-style iOS Battery Pill View (inspired by x8/f.java).
 */
class BatteryGraphicView(context: Context) : View(context) {
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(1.8f)
        color = 0x99FFFFFF.toInt()
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF30D158.toInt()
    }
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val rect = RectF()
    private val boltPath = Path()

    var levelPct: Int = 85
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }
    var isCharging: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val capW = context.dpF(3f)
        val bodyW = w - capW - context.dpF(4f)
        val bodyH = h * 0.72f
        val top = (h - bodyH) / 2f
        val r = context.dpF(4.5f)

        val col = when {
            levelPct <= 20 && !isCharging -> 0xFFFF453A.toInt()
            isCharging -> 0xFF30D158.toInt()
            else -> Color.WHITE
        }
        fillPaint.color = col

        rect.set(1f, top, bodyW, top + bodyH)
        canvas.drawRoundRect(rect, r, r, borderPaint)

        val inset = context.dpF(2.8f)
        val maxFillW = (bodyW - inset * 2f).coerceAtLeast(1f)
        val fillW = maxFillW * (levelPct / 100f)
        rect.set(1f + inset, top + inset, 1f + inset + fillW, top + bodyH - inset)
        canvas.drawRoundRect(rect, r * 0.6f, r * 0.6f, fillPaint)

        // Cap nub on right
        val capH = bodyH * 0.42f
        rect.set(bodyW + context.dpF(1.5f), (h - capH) / 2f, bodyW + context.dpF(1.5f) + capW, (h + capH) / 2f)
        borderPaint.style = Paint.Style.FILL
        canvas.drawRoundRect(rect, capW / 2f, capW / 2f, borderPaint)
        borderPaint.style = Paint.Style.STROKE

        if (isCharging) {
            val cx = bodyW / 2f
            val cy = h / 2f
            val s = bodyH * 0.34f
            boltPath.reset()
            boltPath.moveTo(cx + s * 0.15f, cy - s)
            boltPath.lineTo(cx - s * 0.65f, cy + s * 0.1f)
            boltPath.lineTo(cx - s * 0.05f, cy + s * 0.1f)
            boltPath.lineTo(cx - s * 0.15f, cy + s)
            boltPath.lineTo(cx + s * 0.65f, cy - s * 0.1f)
            boltPath.lineTo(cx + s * 0.05f, cy - s * 0.1f)
            boltPath.close()
            canvas.drawPath(boltPath, boltPaint)
        }
    }
}

/**
 * Interactive draggable media seek bar with smooth progress line and thumb.
 */
class ProgressLine(context: Context) : View(context) {
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x38FFFFFF
    }
    private val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val rect = RectF()
    private var progressValue: Float = 0f
    var progress: Float
        get() = progressValue
        set(value) {
            if (!isDragging) {
                progressValue = value.coerceIn(0f, 1f)
                invalidate()
            }
        }
    var activeColor: Int = Color.WHITE
        set(value) {
            field = value
            fgPaint.color = value
            invalidate()
        }
    var onSeek: ((Float) -> Unit)? = null
    private var isDragging = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (onSeek == null || width <= 0) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                isDragging = true
                updateFromTouch(event.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                updateFromTouch(event.x)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                updateFromTouch(event.x)
                isDragging = false
                onSeek?.invoke(progressValue)
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun updateFromTouch(x: Float) {
        val pad = context.dpF(6f)
        val usable = (width - pad * 2f).coerceAtLeast(1f)
        progressValue = ((x - pad) / usable).coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val barH = if (isDragging) context.dpF(6.5f) else context.dpF(4.5f)
        val cy = h / 2f
        val pad = context.dpF(6f)
        val trackW = (w - pad * 2f).coerceAtLeast(1f)
        val r = barH / 2f

        rect.set(pad, cy - r, pad + trackW, cy + r)
        canvas.drawRoundRect(rect, r, r, bgPaint)

        val fillW = trackW * progressValue.coerceIn(0f, 1f)
        if (fillW > 0f) {
            rect.set(pad, cy - r, pad + fillW, cy + r)
            canvas.drawRoundRect(rect, r, r, fgPaint)
        }

        val thumbRadius = if (isDragging) context.dpF(6.5f) else context.dpF(4.5f)
        canvas.drawCircle(pad + fillW, cy, thumbRadius, fgPaint)
    }
}

/**
 * Hand-drawn vector icon view for all 14 Dynamic Motion plugins.
 */
class ControlIconView(context: Context, var kind: Int = KIND_PLAY) : View(context) {
    companion object {
        const val KIND_PREV = 0
        const val KIND_PLAY = 1
        const val KIND_PAUSE = 2
        const val KIND_NEXT = 3
        const val KIND_PHONE_ACCEPT = 4
        const val KIND_PHONE_DECLINE = 5
        const val KIND_TIMER = 6
        const val KIND_BT = 7
        const val KIND_RINGER_NORMAL = 8
        const val KIND_RINGER_VIBRATE = 9
        const val KIND_RINGER_SILENT = 10
        const val KIND_CLOSE = 11
        const val KIND_NAV_ARROW = 12
        const val KIND_CAR = 13
        const val KIND_FLASHLIGHT = 14
        const val KIND_HOTSPOT = 15
        const val KIND_DND_MOON = 16
        const val KIND_RECORD_DOT = 17
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(2.2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val path = Path()
    private val rect = RectF()

    var iconColor: Int = Color.WHITE
        set(value) {
            field = value
            fillPaint.color = value
            strokePaint.color = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val s = min(w, h) * 0.36f

        when (kind) {
            KIND_PLAY -> {
                path.reset()
                path.moveTo(cx - s * 0.55f, cy - s * 0.85f)
                path.lineTo(cx + s * 0.85f, cy)
                path.lineTo(cx - s * 0.55f, cy + s * 0.85f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_PAUSE -> {
                val bw = s * 0.42f
                val bh = s * 1.55f
                val gap = s * 0.32f
                rect.set(cx - gap - bw, cy - bh / 2f, cx - gap, cy + bh / 2f)
                canvas.drawRoundRect(rect, bw / 3f, bw / 3f, fillPaint)
                rect.set(cx + gap, cy - bh / 2f, cx + gap + bw, cy + bh / 2f)
                canvas.drawRoundRect(rect, bw / 3f, bw / 3f, fillPaint)
            }
            KIND_PREV -> {
                val barW = s * 0.25f
                rect.set(cx - s * 0.85f, cy - s * 0.75f, cx - s * 0.85f + barW, cy + s * 0.75f)
                canvas.drawRoundRect(rect, barW / 2f, barW / 2f, fillPaint)
                path.reset()
                path.moveTo(cx + s * 0.75f, cy - s * 0.75f)
                path.lineTo(cx - s * 0.5f, cy)
                path.lineTo(cx + s * 0.75f, cy + s * 0.75f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_NEXT -> {
                val barW = s * 0.25f
                rect.set(cx + s * 0.85f - barW, cy - s * 0.75f, cx + s * 0.85f, cy + s * 0.75f)
                canvas.drawRoundRect(rect, barW / 2f, barW / 2f, fillPaint)
                path.reset()
                path.moveTo(cx - s * 0.75f, cy - s * 0.75f)
                path.lineTo(cx + s * 0.5f, cy)
                path.lineTo(cx - s * 0.75f, cy + s * 0.75f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_PHONE_ACCEPT -> {
                strokePaint.strokeWidth = context.dpF(2.5f)
                rect.set(cx - s * 0.8f, cy - s * 0.8f, cx + s * 0.8f, cy + s * 0.8f)
                canvas.drawArc(rect, 130f, 110f, false, strokePaint)
                canvas.drawCircle(cx - s * 0.55f, cy + s * 0.45f, s * 0.24f, fillPaint)
                canvas.drawCircle(cx + s * 0.45f, cy - s * 0.55f, s * 0.24f, fillPaint)
            }
            KIND_PHONE_DECLINE -> {
                strokePaint.strokeWidth = context.dpF(2.5f)
                rect.set(cx - s * 0.85f, cy - s * 0.45f, cx + s * 0.85f, cy + s * 0.75f)
                canvas.drawArc(rect, 200f, 140f, false, strokePaint)
                canvas.drawCircle(cx - s * 0.68f, cy + s * 0.05f, s * 0.22f, fillPaint)
                canvas.drawCircle(cx + s * 0.68f, cy + s * 0.05f, s * 0.22f, fillPaint)
            }
            KIND_TIMER -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                canvas.drawCircle(cx, cy + s * 0.1f, s * 0.82f, strokePaint)
                canvas.drawLine(cx - s * 0.3f, cy - s * 0.92f, cx + s * 0.3f, cy - s * 0.92f, strokePaint)
                canvas.drawLine(cx, cy + s * 0.1f, cx, cy - s * 0.38f, strokePaint)
                canvas.drawLine(cx, cy + s * 0.1f, cx + s * 0.4f, cy + s * 0.25f, strokePaint)
            }
            KIND_BT -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                path.reset()
                path.moveTo(cx - s * 0.45f, cy - s * 0.45f)
                path.lineTo(cx + s * 0.45f, cy + s * 0.45f)
                path.lineTo(cx, cy + s * 0.9f)
                path.lineTo(cx, cy - s * 0.9f)
                path.lineTo(cx + s * 0.45f, cy - s * 0.45f)
                path.lineTo(cx - s * 0.45f, cy + s * 0.45f)
                canvas.drawPath(path, strokePaint)
            }
            KIND_RINGER_NORMAL -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                path.reset()
                path.moveTo(cx, cy - s * 0.85f)
                path.quadTo(cx + s * 0.68f, cy - s * 0.6f, cx + s * 0.72f, cy + s * 0.4f)
                path.lineTo(cx - s * 0.72f, cy + s * 0.4f)
                path.quadTo(cx - s * 0.68f, cy - s * 0.6f, cx, cy - s * 0.85f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawCircle(cx, cy + s * 0.72f, s * 0.2f, fillPaint)
            }
            KIND_RINGER_VIBRATE -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                rect.set(cx - s * 0.4f, cy - s * 0.65f, cx + s * 0.4f, cy + s * 0.65f)
                canvas.drawRoundRect(rect, s * 0.15f, s * 0.15f, strokePaint)
                canvas.drawLine(cx - s * 0.78f, cy - s * 0.4f, cx - s * 0.78f, cy + s * 0.4f, strokePaint)
                canvas.drawLine(cx + s * 0.78f, cy - s * 0.4f, cx + s * 0.78f, cy + s * 0.4f, strokePaint)
            }
            KIND_RINGER_SILENT -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                path.reset()
                path.moveTo(cx, cy - s * 0.85f)
                path.quadTo(cx + s * 0.68f, cy - s * 0.6f, cx + s * 0.72f, cy + s * 0.4f)
                path.lineTo(cx - s * 0.72f, cy + s * 0.4f)
                path.quadTo(cx - s * 0.68f, cy - s * 0.6f, cx, cy - s * 0.85f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - s * 0.85f, cy - s * 0.85f, cx + s * 0.85f, cy + s * 0.85f, strokePaint)
            }
            KIND_CLOSE -> {
                strokePaint.strokeWidth = context.dpF(2.2f)
                canvas.drawLine(cx - s * 0.55f, cy - s * 0.55f, cx + s * 0.55f, cy + s * 0.55f, strokePaint)
                canvas.drawLine(cx + s * 0.55f, cy - s * 0.55f, cx - s * 0.55f, cy + s * 0.55f, strokePaint)
            }
            KIND_NAV_ARROW -> {
                path.reset()
                path.moveTo(cx, cy - s * 0.9f)
                path.lineTo(cx + s * 0.75f, cy + s * 0.78f)
                path.lineTo(cx, cy + s * 0.35f)
                path.lineTo(cx - s * 0.75f, cy + s * 0.78f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_CAR -> {
                rect.set(cx - s * 0.85f, cy - s * 0.2f, cx + s * 0.85f, cy + s * 0.45f)
                canvas.drawRoundRect(rect, s * 0.25f, s * 0.25f, fillPaint)
                path.reset()
                path.moveTo(cx - s * 0.55f, cy - s * 0.2f)
                path.lineTo(cx - s * 0.35f, cy - s * 0.7f)
                path.lineTo(cx + s * 0.35f, cy - s * 0.7f)
                path.lineTo(cx + s * 0.55f, cy - s * 0.2f)
                path.close()
                canvas.drawPath(path, fillPaint)
                canvas.drawCircle(cx - s * 0.5f, cy + s * 0.55f, s * 0.22f, strokePaint)
                canvas.drawCircle(cx + s * 0.5f, cy + s * 0.55f, s * 0.22f, strokePaint)
            }
            KIND_FLASHLIGHT -> {
                rect.set(cx - s * 0.32f, cy - s * 0.2f, cx + s * 0.32f, cy + s * 0.85f)
                canvas.drawRoundRect(rect, s * 0.15f, s * 0.15f, fillPaint)
                path.reset()
                path.moveTo(cx - s * 0.55f, cy - s * 0.8f)
                path.lineTo(cx + s * 0.55f, cy - s * 0.8f)
                path.lineTo(cx + s * 0.32f, cy - s * 0.2f)
                path.lineTo(cx - s * 0.32f, cy - s * 0.2f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_HOTSPOT -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                canvas.drawCircle(cx, cy, s * 0.22f, fillPaint)
                rect.set(cx - s * 0.55f, cy - s * 0.55f, cx + s * 0.55f, cy + s * 0.55f)
                canvas.drawArc(rect, -135f, 90f, false, strokePaint)
                canvas.drawArc(rect, 45f, 90f, false, strokePaint)
                rect.set(cx - s * 0.9f, cy - s * 0.9f, cx + s * 0.9f, cy + s * 0.9f)
                canvas.drawArc(rect, -135f, 90f, false, strokePaint)
                canvas.drawArc(rect, 45f, 90f, false, strokePaint)
            }
            KIND_DND_MOON -> {
                path.reset()
                rect.set(cx - s * 0.75f, cy - s * 0.75f, cx + s * 0.75f, cy + s * 0.75f)
                canvas.drawArc(rect, 35f, 250f, true, fillPaint)
            }
            KIND_RECORD_DOT -> {
                strokePaint.strokeWidth = context.dpF(1.8f)
                canvas.drawCircle(cx, cy, s * 0.82f, strokePaint)
                canvas.drawCircle(cx, cy, s * 0.46f, fillPaint)
            }
        }
    }
}

/**
 * Animated iOS-style toggle switch.
 */
class ToggleView(context: Context) : View(context) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val rect = RectF()
    private var animPos = 0f
    private var animator: ValueAnimator? = null

    var isChecked: Boolean = false
        private set
    var activeColor: Int = 0xFF30D158.toInt()
    var onChanged: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener {
            setChecked(!isChecked, animate = true)
            onChanged?.invoke(isChecked)
        }
    }

    fun setChecked(checked: Boolean, animate: Boolean = false) {
        isChecked = checked
        val target = if (checked) 1f else 0f
        animator?.cancel()
        if (animate && isAttachedToWindow) {
            animator = ValueAnimator.ofFloat(animPos, target).apply {
                duration = 190L
                addUpdateListener {
                    animPos = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            animPos = target
            invalidate()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(context.dp(50f), context.dp(30f))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f

        val offColor = 0xFF39393D.toInt()
        trackPaint.color = blendColors(offColor, activeColor, animPos)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, trackPaint)

        val pad = context.dpF(2.5f)
        val thumbR = (h - pad * 2f) / 2f
        val startX = pad + thumbR
        val endX = w - pad - thumbR
        val cx = startX + (endX - startX) * animPos
        canvas.drawCircle(cx, h / 2f, thumbR, thumbPaint)
    }

    private fun blendColors(c1: Int, c2: Int, ratio: Float): Int {
        val inv = 1f - ratio
        val r = (Color.red(c1) * inv + Color.red(c2) * ratio).toInt()
        val g = (Color.green(c1) * inv + Color.green(c2) * ratio).toInt()
        val b = (Color.blue(c1) * inv + Color.blue(c2) * ratio).toInt()
        return Color.rgb(r, g, b)
    }
}

/**
 * Slider control row with "-" and "+" fine-tuning buttons for 1-dp precision.
 */
class SliderRowView(
    context: Context,
    title: String,
    subtitle: String,
    private val minVal: Int,
    private val maxVal: Int,
    initialVal: Int,
    private val unitSuffix: String,
    private val onValueChange: (Int) -> Unit
) : LinearLayout(context) {

    private val valueLabel: TextView
    private val seekBar: SeekBar
    private var currentValue: Int = initialVal.coerceIn(minVal, maxVal)
    private var suppressCallback = false

    init {
        orientation = VERTICAL
        setPadding(context.dp(16f), context.dp(12f), context.dp(16f), context.dp(12f))

        val topRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val textCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }

        val titleTv = TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        textCol.addView(titleTv)

        if (subtitle.isNotEmpty()) {
            val subTv = TextView(context).apply {
                text = subtitle
                setTextColor(0xFF9898A0.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            }
            textCol.addView(subTv)
        }
        topRow.addView(textCol)

        val minusBtn = TextView(context).apply {
            text = "−"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBg(0xFF2C2C34.toInt(), context.dpF(8f))
            layoutParams = LayoutParams(context.dp(32f), context.dp(32f)).apply {
                rightMargin = context.dp(8f)
            }
            setOnClickListener { setValue(currentValue - 1, notify = true) }
        }
        topRow.addView(minusBtn)

        valueLabel = TextView(context).apply {
            text = "$currentValue$unitSuffix"
            gravity = Gravity.CENTER
            setTextColor(0xFF5E5CE6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            minWidth = context.dp(54f)
        }
        topRow.addView(valueLabel)

        val plusBtn = TextView(context).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBg(0xFF2C2C34.toInt(), context.dpF(8f))
            layoutParams = LayoutParams(context.dp(32f), context.dp(32f)).apply {
                leftMargin = context.dp(8f)
            }
            setOnClickListener { setValue(currentValue + 1, notify = true) }
        }
        topRow.addView(plusBtn)

        addView(topRow)

        seekBar = SeekBar(context).apply {
            max = maxVal - minVal
            progress = currentValue - minVal
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = context.dp(6f)
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = (minVal + p).coerceIn(minVal, maxVal)
                    currentValue = v
                    valueLabel.text = "$v$unitSuffix"
                    if (!suppressCallback) {
                        onValueChange(v)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        addView(seekBar)
    }

    fun setValue(newVal: Int, notify: Boolean = false) {
        val clamped = newVal.coerceIn(minVal, maxVal)
        currentValue = clamped
        suppressCallback = !notify
        seekBar.progress = clamped - minVal
        valueLabel.text = "$clamped$unitSuffix"
        suppressCallback = false
        if (notify) onValueChange(clamped)
    }
}

/**
 * Segmented pill selector row.
 */
class SegmentedRowView(
    context: Context,
    title: String,
    options: List<String>,
    initialIndex: Int,
    private val onSelect: (Int) -> Unit
) : LinearLayout(context) {

    private val optionViews = mutableListOf<TextView>()
    private var selectedIdx = initialIndex.coerceIn(0, options.size - 1)

    init {
        orientation = VERTICAL
        setPadding(context.dp(16f), context.dp(12f), context.dp(16f), context.dp(12f))

        val titleTv = TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        addView(titleTv)

        val pillRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            background = roundedBg(0xFF23242C.toInt(), context.dpF(10f))
            val pad = context.dp(3f)
            setPadding(pad, pad, pad, pad)
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = context.dp(8f)
            }
        }

        options.forEachIndexed { idx, label ->
            val tv = TextView(context).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(context.dp(5f), context.dp(8f), context.dp(5f), context.dp(8f))
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setSelectedIndex(idx, notify = true)
                }
            }
            optionViews.add(tv)
            pillRow.addView(tv)
        }

        addView(pillRow)
        refreshStyles()
    }

    fun setSelectedIndex(idx: Int, notify: Boolean = false) {
        if (idx !in optionViews.indices) return
        selectedIdx = idx
        refreshStyles()
        if (notify) onSelect(idx)
    }

    private fun refreshStyles() {
        optionViews.forEachIndexed { idx, tv ->
            if (idx == selectedIdx) {
                tv.background = roundedBg(0xFF5E5CE6.toInt(), context.dpF(8f))
                tv.setTextColor(Color.WHITE)
            } else {
                tv.background = null
                tv.setTextColor(0xFF9898A0.toInt())
            }
        }
    }
}
