package com.example.island

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import java.lang.ref.WeakReference

/**
 * Dynamic Motion-style AccessibilityService host.
 *
 * When the user enables Island in Accessibility Settings, this service provides
 * TYPE_ACCESSIBILITY_OVERLAY (window type 2032), which renders smoothly over the
 * Samsung One UI status bar, camera cutout, and lock screen without clipping.
 * It also detects foreground package changes so notifications from the currently
 * open app can be optionally suppressed just like Dynamic Motion.
 */
class IslandAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instanceRef: WeakReference<IslandAccessibilityService>? = null

        @Volatile
        var currentForegroundPkg: String = ""
            private set

        fun getInstance(): IslandAccessibilityService? = instanceRef?.get()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        sendBroadcast(Intent(Prefs.ACTION_PREFS_CHANGED).setPackage(packageName))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            if (pkg != "com.android.systemui" && pkg != "android" && pkg != packageName) {
                currentForegroundPkg = pkg
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instanceRef = null
        sendBroadcast(Intent(Prefs.ACTION_PREFS_CHANGED).setPackage(packageName))
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instanceRef = null
        super.onDestroy()
    }
}
