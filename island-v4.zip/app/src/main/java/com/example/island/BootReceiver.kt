package com.example.island

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Starts the island again after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs.on(context, Prefs.ENABLED) && Settings.canDrawOverlays(context)) {
            IslandService.start(context)
        }
    }
}
