package com.example.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Keeps the island alive in the background and owns the engine. */
class IslandService : Service() {

    companion object {
        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, IslandService::class.java))
            } catch (e: Exception) {
                Diag.add("could not start island service: " + e)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            IslandBus.engine = IslandEngine(this)
            Diag.engineRunning = true
        } catch (e: Exception) {
            Diag.add("engine failed to start: " + e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        IslandBus.engine?.refresh()
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Island service", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, "island")
            .setContentTitle("Island is running")
            .setSmallIcon(R.drawable.ic_stat_island)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    override fun onDestroy() {
        IslandBus.engine?.shutdown()
        IslandBus.engine = null
        Diag.engineRunning = false
        super.onDestroy()
    }
}
