package com.example.island

import android.app.NotificationManager
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.NotificationListenerService.RankingMap
import android.service.notification.StatusBarNotification

/** Android tells this class about every notification and about music sessions. */
class IslandListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: IslandListener? = null
    }

    override fun onListenerConnected() {
        instance = this
        Diag.listenerConnected = true
        Diag.add("notification access connected")
        val e = IslandBus.engine
        if (e == null) IslandService.start(this) else e.onListenerConnected()
    }

    override fun onListenerDisconnected() {
        Diag.listenerConnected = false
        Diag.add("notification access disconnected")
        IslandBus.engine?.onListenerDisconnected()
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification, rankingMap: RankingMap) {
        var importance = NotificationManager.IMPORTANCE_DEFAULT
        try {
            val r = Ranking()
            if (rankingMap.getRanking(sbn.key, r)) importance = r.importance
        } catch (e: Exception) {
        }
        IslandBus.engine?.onPosted(sbn, importance)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        IslandBus.engine?.onRemoved(sbn)
    }
}
