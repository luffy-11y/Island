package com.example.island

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    const val ENABLED = "enabled"
    const val NOTIFS = "notifs"
    const val CALLS = "calls"
    const val TIMERS = "timers"
    const val MEDIA = "media"
    const val TRACKPEEK = "trackpeek"
    const val TORCH = "torch"
    const val CHARGING = "charging"
    const val LOWBATT = "lowbatt"
    const val HEADSET = "headset"
    const val RINGER = "ringer"
    const val DND = "dnd"
    const val AIRPLANE = "airplane"
    const val VOLUME = "volume"
    const val HIDE_TEXT = "hide_text"
    const val EQUALIZER = "equalizer"
    const val HAPTICS = "haptics"
    const val GLOW = "glow"
    const val SMOOTH = "smooth"

    const val SECONDS = "seconds"
    const val TOP_DP = "top_dp"
    const val WIDTH_DP = "width_dp"
    const val BLOCKED = "blocked"

    const val DEFAULT_TOP_DP = 36
    const val DEFAULT_SECONDS = 5
    const val DEFAULT_WIDTH_DP = 172

    fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("island_prefs", Context.MODE_PRIVATE)

    // Everything is ON by default, except these three.
    fun on(ctx: Context, key: String): Boolean =
        sp(ctx).getBoolean(key, key != HIDE_TEXT && key != VOLUME && key != SMOOTH)

    fun int(ctx: Context, key: String, def: Int): Int = sp(ctx).getInt(key, def)

    fun blocked(ctx: Context): Set<String> =
        sp(ctx).getStringSet(BLOCKED, emptySet()) ?: emptySet()

    fun setBlocked(ctx: Context, pkg: String, block: Boolean) {
        val s = HashSet<String>(blocked(ctx))
        if (block) s.add(pkg) else s.remove(pkg)
        sp(ctx).edit().putStringSet(BLOCKED, s).apply()
    }
}

/** A tiny in-memory log so the Debug tab can show what the island is doing. */
object Diag {
    private val lines = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Volatile
    var listenerConnected = false

    @Volatile
    var engineRunning = false

    fun add(msg: String) {
        synchronized(lines) {
            lines.add(0, fmt.format(Date()) + "  " + msg)
            while (lines.size > 60) lines.removeAt(lines.size - 1)
        }
    }

    fun all(): List<String> = synchronized(lines) { ArrayList(lines) }
}

/** Lets the notification listener and the app screen reach the running island. */
object IslandBus {
    @Volatile
    var engine: IslandEngine? = null
}
