package com.example.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Frosted glass: a see-through fill with a bright edge that fades from top-left to bottom-right. */
class GlassDrawable(
    private val radius: Float,
    private val strokePx: Float,
    private val strong: Boolean = false,
    private val tint: Int = 0
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokePx
    }
    private val rect = RectF()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val half = strokePx / 2f
        rect.set(
            bounds.left + half, bounds.top + half,
            bounds.right - half, bounds.bottom - half
        )
        val top = if (tint != 0) withAlpha(tint, 95) else white(if (strong) 72 else 40)
        val bottom = if (tint != 0) withAlpha(tint, 30) else white(if (strong) 26 else 14)
        fill.shader = LinearGradient(
            0f, bounds.top.toFloat(), 0f, bounds.bottom.toFloat(), top, bottom, Shader.TileMode.CLAMP
        )
        stroke.shader = LinearGradient(
            bounds.left.toFloat(), bounds.top.toFloat(), bounds.right.toFloat(), bounds.bottom.toFloat(),
            white(165), white(20), Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, stroke)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** A slowly moving glow of colours. The glass sits on top of it. */
class AuroraView(context: Context) : View(context) {
    private val colors = intArrayOf(
        Color.rgb(108, 92, 231), Color.rgb(0, 168, 255), Color.rgb(255, 79, 163), Color.rgb(0, 210, 160)
    )
    private val paints = Array(4) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private var t = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 28000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val r = max(w, h) * 0.6f
        for (i in 0 until 4) {
            paints[i].shader = RadialGradient(
                0f, 0f, max(r, 1f), withAlpha(colors[i], 150), withAlpha(colors[i], 0), Shader.TileMode.CLAMP
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isRunning) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(5, 6, 10))
        val w = width.toFloat()
        val h = height.toFloat()
        val r = max(w, h) * 0.6f
        for (i in 0 until 4) {
            val a = 2.0 * Math.PI * (t + i * 0.25)
            val k = 1 + i % 2
            val cx = w * (0.5f + 0.42f * cos(a * k).toFloat())
            val cy = h * (0.5f + 0.40f * sin(a * (3 - k)).toFloat())
            canvas.save()
            canvas.translate(cx, cy)
            canvas.drawCircle(0f, 0f, r, paints[i])
            canvas.restore()
        }
        canvas.drawColor(withAlpha(Color.BLACK, 90))
    }
}

/** An on/off switch with a springy thumb. */
class GlassToggle(context: Context) : View(context) {
    private val onColor = Pal.GREEN
    private val offColor = Color.rgb(72, 72, 74)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var t = 0f
    private var anim: ValueAnimator? = null

    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener {
            update(!checked, true)
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(checked)
        }
    }

    fun update(value: Boolean, animate: Boolean) {
        checked = value
        anim?.cancel()
        val target = if (value) 1f else 0f
        if (!animate) {
            t = target
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(t, target).apply {
            duration = 320
            interpolator = OvershootInterpolator(1.6f)
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val d = resources.displayMetrics.density
        setMeasuredDimension((51 * d).toInt(), (31 * d).toInt())
    }

    private fun blend(a: Int, b: Int, f: Float): Int {
        val x = f.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * x).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * x).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.color = blend(offColor, onColor, t)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, paint)
        val pad = 2f * resources.displayMetrics.density
        val r = h / 2f - pad
        val cx = pad + r + (w - 2f * pad - 2f * r) * t
        paint.color = Color.WHITE
        canvas.drawCircle(cx, h / 2f, r, paint)
    }
}

/** A slider with a glowing fill. */
class GlassSlider(context: Context, private val lo: Int, private val hi: Int, start: Int) : View(context) {
    var value = start
        private set
    var onChange: ((Int) -> Unit)? = null
    var onFinish: ((Int) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = white(48) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val thumbRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val rect = RectF()
    private var grow = 0f
    private var growAnim: ValueAnimator? = null

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthSpec), (38 * d).toInt())
    }

    private fun animateGrow(to: Float) {
        growAnim?.cancel()
        growAnim = ValueAnimator.ofFloat(grow, to).apply {
            duration = 180
            addUpdateListener {
                grow = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val pad = 16f * d
        val usable = width - 2f * pad
        val cy = height / 2f
        val th = 6f * d
        val frac = if (hi > lo) (value - lo).toFloat() / (hi - lo) else 0f
        val x = pad + usable * frac
        rect.set(pad, cy - th / 2f, pad + usable, cy + th / 2f)
        canvas.drawRoundRect(rect, th / 2f, th / 2f, track)
        fill.shader = LinearGradient(
            pad, 0f, pad + max(usable, 1f), 0f, Pal.BLUE, Pal.PURPLE, Shader.TileMode.CLAMP
        )
        rect.set(pad, cy - th / 2f, max(x, pad + th), cy + th / 2f)
        canvas.drawRoundRect(rect, th / 2f, th / 2f, fill)
        val r = (11f + 3f * grow) * d
        canvas.drawCircle(x, cy + 1.5f * d, r, thumbRing)
        canvas.drawCircle(x, cy, r, thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val pad = 16f * d
        val usable = max(width - 2f * pad, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    animateGrow(1f)
                }
                val f = ((e.x - pad) / usable).coerceIn(0f, 1f)
                val v = lo + (f * (hi - lo)).roundToInt()
                if (v != value) {
                    value = v
                    invalidate()
                    onChange?.invoke(v)
                } else {
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animateGrow(0f)
                onFinish?.invoke(value)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** A little animated island for the Home screen. It cycles through the things the real one shows. */
class PreviewIsland(context: Context) : FrameLayout(context) {
    private class Scene(val emoji: String, val title: String, val sub: String, val color: Int)

    private val d = resources.displayMetrics.density
    private val scenes = listOf(
        Scene(Emoji.NOTE, "Midnight City", "M83", Pal.PINK),
        Scene(Emoji.BOLT, "Charging", "82%", Pal.GREEN),
        Scene(Emoji.FLASH, "Flashlight", "On", Pal.YELLOW),
        Scene(Emoji.TIMER, "Timer", "04:59", Pal.ORANGE),
        Scene(Emoji.HEADPHONES, "Headphones", "Connected", Pal.BLUE)
    )
    private var idx = 0
    private val handler = Handler(Looper.getMainLooper())

    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private var corner = 0f
    private val pill = FrameLayout(context)
    private val emojiView = TextView(context)
    private val texts = LinearLayout(context)
    private val title = TextView(context)
    private val sub = TextView(context)
    private val eq = EqualizerView(context)

    private val wHolder = FloatValueHolder(130f * d)
    private val hHolder = FloatValueHolder(34f * d)
    private val wAnim = SpringAnimation(wHolder).apply {
        setMinimumVisibleChange(1f)
        setSpring(SpringForce().setDampingRatio(0.6f).setStiffness(380f))
        addUpdateListener { _, v, _ -> sizePill(v, -1f) }
    }
    private val hAnim = SpringAnimation(hHolder).apply {
        setMinimumVisibleChange(1f)
        setSpring(SpringForce().setDampingRatio(0.68f).setStiffness(320f))
        addUpdateListener { _, v, _ -> sizePill(-1f, v) }
    }

    init {
        pill.background = bg
        pill.clipToOutline = true
        pill.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, corner)
            }
        }
        emojiView.textSize = 15f
        emojiView.gravity = Gravity.CENTER
        val eLp = FrameLayout.LayoutParams((26 * d).toInt(), (26 * d).toInt(), Gravity.START or Gravity.CENTER_VERTICAL)
        eLp.marginStart = (9 * d).toInt()
        pill.addView(emojiView, eLp)

        texts.orientation = LinearLayout.VERTICAL
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        sub.textSize = 12f
        sub.setTextColor(Pal.GRAY)
        texts.addView(title)
        texts.addView(sub)
        texts.alpha = 0f
        val tLp = FrameLayout.LayoutParams((190 * d).toInt(), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL)
        tLp.marginStart = (46 * d).toInt()
        pill.addView(texts, tLp)

        val qLp = FrameLayout.LayoutParams((18 * d).toInt(), (14 * d).toInt(), Gravity.END or Gravity.CENTER_VERTICAL)
        qLp.marginEnd = (14 * d).toInt()
        pill.addView(eq, qLp)
        eq.setPlaying(true)

        addView(pill, FrameLayout.LayoutParams((130 * d).toInt(), (34 * d).toInt(), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        applyScene()
    }

    private fun applyScene() {
        val s = scenes[idx % scenes.size]
        emojiView.text = s.emoji
        title.text = s.title
        sub.text = s.sub
        eq.setColor(s.color)
    }

    private fun sizePill(w: Float, h: Float) {
        val lp = pill.layoutParams as FrameLayout.LayoutParams
        if (w > 0f) lp.width = max(w.toInt(), (20 * d).toInt())
        if (h > 0f) lp.height = max(h.toInt(), (12 * d).toInt())
        corner = min(lp.height / 2f, 24f * d)
        bg.cornerRadius = corner
        pill.invalidateOutline()
        pill.layoutParams = lp
    }

    private fun go(wDp: Float, hDp: Float) {
        wAnim.animateToFinalPosition(wDp * d)
        hAnim.animateToFinalPosition(hDp * d)
    }

    private fun cycle() {
        applyScene()
        texts.animate().setStartDelay(0).alpha(0f).setDuration(120).start()
        go(130f, 34f)
        handler.postDelayed({
            go(292f, 66f)
            texts.animate().setStartDelay(160).alpha(1f).setDuration(280).start()
        }, 1100)
        handler.postDelayed({
            texts.animate().setStartDelay(0).alpha(0f).setDuration(120).start()
            go(130f, 34f)
        }, 3300)
        handler.postDelayed({
            idx++
            cycle()
        }, 4400)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        cycle()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
