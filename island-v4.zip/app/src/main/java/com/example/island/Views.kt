package com.example.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

fun white(alpha: Int): Int = Color.argb(alpha, 255, 255, 255)

fun withAlpha(color: Int, alpha: Int): Int =
    Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

fun roundClip(view: View, radius: Float) {
    view.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(v: View, outline: Outline) {
            outline.setRoundRect(0, 0, v.width, v.height, radius)
        }
    }
    view.clipToOutline = true
}

object Pal {
    val RED = Color.rgb(255, 69, 58)
    val GREEN = Color.rgb(48, 209, 88)
    val YELLOW = Color.rgb(255, 196, 0)
    val ORANGE = Color.rgb(255, 159, 10)
    val BLUE = Color.rgb(10, 132, 255)
    val PINK = Color.rgb(255, 55, 95)
    val PURPLE = Color.rgb(191, 90, 242)
    val TEAL = Color.rgb(64, 200, 224)
    val GRAY = Color.rgb(142, 142, 147)
}

object Emoji {
    const val NOTE = "\uD83C\uDFB5"
    const val BOLT = "\u26A1"
    const val FLASH = "\uD83D\uDD26"
    const val PHONE = "\uD83D\uDCDE"
    const val TIMER = "\u23F1\uFE0F"
    const val ALARM = "\u23F0"
    const val HEADPHONES = "\uD83C\uDFA7"
    const val BELL = "\uD83D\uDD14"
    const val BELL_OFF = "\uD83D\uDD15"
    const val VIBRATE = "\uD83D\uDCF3"
    const val MOON = "\uD83C\uDF19"
    const val PLANE = "\u2708\uFE0F"
    const val VOL_HIGH = "\uD83D\uDD0A"
    const val VOL_MID = "\uD83D\uDD09"
    const val VOL_LOW = "\uD83D\uDD08"
    const val VOL_OFF = "\uD83D\uDD07"
    const val BATTERY = "\uD83D\uDD0B"
    const val PLUG = "\uD83D\uDD0C"
    const val HOME = "\uD83C\uDFE0"
    const val SLIDERS = "\uD83C\uDF9B\uFE0F"
    const val APPS = "\uD83D\uDCF1"
    const val BUG = "\uD83D\uDC1E"
    const val BELL_RING = "\uD83D\uDD14"
    const val CHAT = "\uD83D\uDCAC"
}

/** A coloured circle with an emoji on it. Used as the icon for system events. */
class BadgeDrawable(private val emoji: String, private val color: Int) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val b = bounds
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        val r = min(b.width(), b.height()) / 2f
        val light = Color.rgb(
            min(255, Color.red(color) + 55),
            min(255, Color.green(color) + 55),
            min(255, Color.blue(color) + 55)
        )
        bg.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            light, color, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, bg)
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = r * 1.05f
        val fm = tp.fontMetrics
        canvas.drawText(emoji, cx, cy - (fm.ascent + fm.descent) / 2f, tp)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun badge(emoji: String, color: Int): Drawable = BadgeDrawable(emoji, color)

/** Four bouncing bars, like the music indicator on the real island. */
class EqualizerView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()
    private var phase = 0f
    private var running = false
    private val freq = intArrayOf(1, 2, 1, 3)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    fun setColor(color: Int) {
        paint.color = color
        invalidate()
    }

    fun setPlaying(playing: Boolean) {
        running = playing
        if (playing) {
            if (!animator.isRunning) animator.start()
        } else {
            animator.cancel()
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (running && !animator.isRunning) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val bars = freq.size
        val gap = width * 0.14f
        val barW = (width - gap * (bars - 1)) / bars
        val maxH = height.toFloat()
        for (i in 0 until bars) {
            val h = if (running) {
                val wave = abs(sin(2.0 * Math.PI * (phase * freq[i] + i * 0.17))).toFloat()
                maxH * (0.22f + 0.78f * wave)
            } else {
                maxH * 0.22f
            }
            val x = i * (barW + gap)
            val top = (maxH - h) / 2f
            rect.set(x, top, x + barW, top + h)
            canvas.drawRoundRect(rect, barW / 2f, barW / 2f, paint)
        }
    }
}

/** A pulsing dot, used for "flashlight is on". */
class PulseView(context: Context) : View(context) {
    var color: Int = Pal.YELLOW
        set(value) {
            field = value
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1300
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isRunning) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        paint.style = Paint.Style.FILL
        paint.color = color
        canvas.drawCircle(cx, cy, r * 0.42f, paint)
        paint.color = withAlpha(color, ((1f - t) * 150f).toInt())
        canvas.drawCircle(cx, cy, r * (0.42f + 0.58f * t), paint)
    }
}

/** A ring that fills up. Used for battery and volume. */
class RingView(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f * d
        color = white(55)
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f * d
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        textSize = 11f * d
    }
    private val rect = RectF()
    private var value = 0f
    private var label = ""
    private var anim: ValueAnimator? = null

    fun set(progress: Float, labelText: String, color: Int, animate: Boolean) {
        label = labelText
        arc.color = color
        val target = progress.coerceIn(0f, 1f)
        anim?.cancel()
        if (!animate) {
            value = target
            invalidate()
            return
        }
        value = 0f
        anim = ValueAnimator.ofFloat(0f, target).apply {
            duration = 700
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                value = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val pad = 3f * d
        rect.set(pad, pad, width - pad, height - pad)
        canvas.drawOval(rect, track)
        canvas.drawArc(rect, -90f, 360f * value, false, arc)
        val fm = text.fontMetrics
        canvas.drawText(label, width / 2f, height / 2f - (fm.ascent + fm.descent) / 2f, text)
    }
}

/** Thin progress bar you can tap or drag. Used for music position and flashlight strength. */
class ProgressLine(context: Context) : View(context) {
    var fraction = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    var accent = Color.WHITE
        set(value) {
            field = value
            invalidate()
        }
    var dragging = false
    var onSeek: ((Float) -> Unit)? = null

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = white(68) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val lineH = 4f * resources.displayMetrics.density
        val top = (height - lineH) / 2f
        val r = lineH / 2f
        rect.set(0f, top, width.toFloat(), top + lineH)
        canvas.drawRoundRect(rect, r, r, track)
        val w = width * fraction
        if (w > 0f) {
            fill.color = accent
            rect.set(0f, top, max(w, lineH), top + lineH)
            canvas.drawRoundRect(rect, r, r, fill)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (width == 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                fraction = e.x / width
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                fraction = e.x / width
                return true
            }
            MotionEvent.ACTION_UP -> {
                fraction = e.x / width
                dragging = false
                onSeek?.invoke(fraction)
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Previous / play / pause / next icons, drawn by hand so they stay sharp. */
class ControlIconView(context: Context, initial: Int) : View(context) {
    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    var kind: Int = initial
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val path = Path()

    init {
        isClickable = true
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.82f).scaleY(0.82f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }

    private fun triRight(c: Canvas, tipX: Float, cy: Float, w: Float, h: Float) {
        path.reset()
        path.moveTo(tipX - w, cy - h)
        path.lineTo(tipX, cy)
        path.lineTo(tipX - w, cy + h)
        path.close()
        c.drawPath(path, paint)
    }

    private fun triLeft(c: Canvas, tipX: Float, cy: Float, w: Float, h: Float) {
        path.reset()
        path.moveTo(tipX + w, cy - h)
        path.lineTo(tipX, cy)
        path.lineTo(tipX + w, cy + h)
        path.close()
        c.drawPath(path, paint)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = minOf(width, height) * 0.36f
        when (kind) {
            PLAY -> {
                path.reset()
                path.moveTo(cx - s * 0.7f, cy - s)
                path.lineTo(cx + s * 0.95f, cy)
                path.lineTo(cx - s * 0.7f, cy + s)
                path.close()
                canvas.drawPath(path, paint)
            }
            PAUSE -> {
                val bw = s * 0.62f
                canvas.drawRoundRect(cx - s * 0.8f, cy - s, cx - s * 0.8f + bw, cy + s, bw / 4f, bw / 4f, paint)
                canvas.drawRoundRect(cx + s * 0.8f - bw, cy - s, cx + s * 0.8f, cy + s, bw / 4f, bw / 4f, paint)
            }
            NEXT -> {
                triRight(canvas, cx, cy, s * 0.95f, s * 0.8f)
                triRight(canvas, cx + s * 0.95f, cy, s * 0.95f, s * 0.8f)
            }
            PREV -> {
                triLeft(canvas, cx, cy, s * 0.95f, s * 0.8f)
                triLeft(canvas, cx - s * 0.95f, cy, s * 0.95f, s * 0.8f)
            }
        }
    }
}
