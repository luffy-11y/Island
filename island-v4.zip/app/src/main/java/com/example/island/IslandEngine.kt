package com.example.island

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The brain of the island. It owns the floating window and decides what to show.
 *
 *  - CARD   : a big card that pops out for a moment (notification, charging, headphones, ...)
 *  - COMPACT: a small pill that stays while something is "live" (music, flashlight, timer, call)
 *  - MEDIA_BIG: the music card with controls
 *  - HIDDEN : nothing is on screen at all
 */
class IslandEngine(private val ctx: Context) {

    companion object {
        private const val HIDDEN = 0
        private const val COMPACT = 1
        private const val MEDIA_BIG = 2
        private const val CARD = 3

        private const val T_MEDIA = 0
        private const val T_TORCH = 1
        private const val T_TIMER = 2
        private const val T_CALL = 3

        private const val SMALL_H = 34

        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    class CardAction(val label: String, val color: Int, val run: () -> Unit)

    class Card(
        val key: String,
        val appName: String,
        val title: String,
        val text: String,
        val icon: Drawable?,
        val accent: Int = 0,
        val seconds: Int = 5,
        val actions: List<CardAction> = emptyList(),
        val ring: Float = -1f,
        val ringText: String = "",
        val onTap: (() -> Unit)? = null,
        val urgent: Boolean = false,
        val slider: Float = -1f,
        val onSlider: ((Float) -> Unit)? = null,
        val sticky: Boolean = false
    )

    private class Live(
        val id: String,
        val type: Int,
        val appName: String,
        var icon: Drawable?,
        var title: String,
        var text: String,
        var whenMs: Long,
        var countDown: Boolean,
        var color: Int,
        var intent: PendingIntent?,
        var actions: List<Pair<String, PendingIntent>>
    ) {
        val prio: Int
            get() = when (type) {
                T_CALL -> 100
                T_TIMER -> 80
                T_TORCH -> 60
                else -> 40
            }
    }

    // ------------------------------------------------------------------ state

    private val handler = Handler(Looper.getMainLooper())
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private lateinit var params: WindowManager.LayoutParams
    private lateinit var container: FrameLayout
    private val pillBg = GradientDrawable().apply { setColor(Color.BLACK) }
    private var cornerPx = 0f
    private var attached = false
    private var mode = HIDDEN
    private var pushScheduled = false
    private var ready = false
    private var compactW = 0

    // compact pill
    private lateinit var cView: FrameLayout
    private lateinit var cArt: ImageView
    private lateinit var cEq: EqualizerView
    private lateinit var cPulse: PulseView
    private lateinit var cText: TextView

    // music card
    private lateinit var mView: LinearLayout
    private lateinit var mArt: ImageView
    private lateinit var mTitle: TextView
    private lateinit var mArtist: TextView
    private lateinit var mEq: EqualizerView
    private lateinit var mProgress: ProgressLine
    private lateinit var mElapsed: TextView
    private lateinit var mTotal: TextView
    private lateinit var mPrev: ControlIconView
    private lateinit var mPlay: ControlIconView
    private lateinit var mNext: ControlIconView

    // generic card
    private lateinit var kView: LinearLayout
    private lateinit var kIcon: ImageView
    private lateinit var kApp: TextView
    private lateinit var kTitle: TextView
    private lateinit var kText: TextView
    private lateinit var kRing: RingView
    private lateinit var kSlider: ProgressLine
    private lateinit var kActions: LinearLayout

    // cards
    private val cardQueue = ArrayDeque<Card>()
    private var currentCard: Card? = null
    private var liveCard: Card? = null
    private val recent = HashMap<String, Long>()
    private val cardTimeout = Runnable { nextCard() }

    // live things
    private val notifLives = LinkedHashMap<String, Live>()
    private val torchLive = Live(
        "torch", T_TORCH, "Flashlight", badge(Emoji.FLASH, Pal.YELLOW),
        "Flashlight", "On", 0L, false, Pal.YELLOW, null, emptyList()
    )
    private val mediaLive = Live(
        "media", T_MEDIA, "Music", null, "", "", 0L, false, Color.WHITE, null, emptyList()
    )
    private var expandedLive: String? = null
    private val collapseRun = Runnable {
        expandedLive = null
        liveCard = null
        render()
    }
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 1000)
        }
    }
    private var tickerOn = false

    // torch
    private var torchOn = false
    private var torchId: String? = null
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            handler.post { onTorch(cameraId, enabled) }
        }
    }

    // system events
    private var lastLevel = -1
    private var lastFull = false
    private val sysReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            handler.post { onSystem(i) }
        }
    }
    private val deviceCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) {
            handler.post { onDevices(added, true) }
        }

        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) {
            handler.post { onDevices(removed, false) }
        }
    }

    // music
    private var sessionManager: MediaSessionManager? = null
    private var controller: MediaController? = null
    private var mediaTitle: String? = null
    private var mediaArtist: String? = null
    private var mediaArt: Bitmap? = null
    private var mediaPlaying = false
    private var mediaVisible = false
    private var mediaDuration = 0L
    private var accentColor = Color.WHITE
    private var dismissedTitle: String? = null
    private val mediaHide = Runnable {
        mediaVisible = false
        if (expandedLive == "media") expandedLive = null
        render()
    }
    private val progressTick = object : Runnable {
        override fun run() {
            updateProgress()
            if (mode == MEDIA_BIG) handler.postDelayed(this, 500)
        }
    }
    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            updateMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            updateMedia()
        }

        override fun onSessionDestroyed() {
            controller = null
            updateMedia()
        }
    }
    private val sessionListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> onSessions(list ?: emptyList()) }

    // springs: width and height are tuned a little differently so the motion feels alive
    private val wHolder = FloatValueHolder(0f)
    private val hHolder = FloatValueHolder(0f)
    private val wAnim = SpringAnimation(wHolder).apply {
        setMinimumVisibleChange(1f)
        setSpring(SpringForce().setDampingRatio(0.62f).setStiffness(420f))
        addUpdateListener { _, v, _ -> onWidth(v) }
    }
    private val hAnim = SpringAnimation(hHolder).apply {
        setMinimumVisibleChange(1f)
        setSpring(SpringForce().setDampingRatio(0.7f).setStiffness(340f))
        addUpdateListener { _, v, _ -> onHeight(v) }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        onPrefChanged(key)
    }

    private fun onPrefChanged(key: String?) {
        if (key == Prefs.TOP_DP) {
            if (attached) {
                params.y = dp(Prefs.int(ctx, Prefs.TOP_DP, Prefs.DEFAULT_TOP_DP))
                push()
            }
        } else if (key == Prefs.EQUALIZER) {
            applyEq()
        } else {
            render(true)
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Float): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
    private fun dp(v: Int): Int = dp(v.toFloat())

    private fun bigWidth(): Int = min(dp(372), ctx.resources.displayMetrics.widthPixels - dp(24))

    private fun appIcon(pkg: String): Drawable? =
        try {
            ctx.packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }

    private fun appLabel(pkg: String): String =
        try {
            ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean, lines: Int): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = sizeSp
        tv.setTextColor(color)
        tv.maxLines = lines
        tv.ellipsize = TextUtils.TruncateAt.END
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun evt(
        key: String, emoji: String, color: Int, title: String, text: String,
        ring: Float = -1f, ringText: String = "", seconds: Int = 3, app: String = "System"
    ): Card = Card(
        key = key, appName = app, title = title, text = text, icon = badge(emoji, color),
        accent = color, seconds = seconds, ring = ring, ringText = ringText
    )

    // ------------------------------------------------------------------ building the views

    private fun buildViews() {
        val c = ctx

        container = FrameLayout(c)
        container.background = pillBg
        container.clipToOutline = true
        container.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
            }
        }

        // --- compact pill: picture on the left, something live on the right
        cView = FrameLayout(c)
        cArt = ImageView(c)
        cArt.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(cArt, dp(7).toFloat())
        val artLp = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.START or Gravity.CENTER_VERTICAL)
        artLp.marginStart = dp(8)
        cView.addView(cArt, artLp)

        val cRight = FrameLayout(c)
        cEq = EqualizerView(c)
        cRight.addView(cEq, FrameLayout.LayoutParams(dp(18), dp(14), Gravity.END or Gravity.CENTER_VERTICAL))
        cPulse = PulseView(c)
        cRight.addView(cPulse, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.END or Gravity.CENTER_VERTICAL))
        cText = label("", 12f, Color.WHITE, true, 1)
        cText.typeface = Typeface.MONOSPACE
        cText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        cRight.addView(cText, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL))
        val rightLp = FrameLayout.LayoutParams(dp(62), MATCH, Gravity.END)
        rightLp.marginEnd = dp(12)
        cView.addView(cRight, rightLp)
        container.addView(cView, FrameLayout.LayoutParams(MATCH, dp(SMALL_H), Gravity.TOP))
        cView.visibility = View.GONE

        // --- music card
        mView = LinearLayout(c)
        mView.orientation = LinearLayout.VERTICAL
        mView.setPadding(dp(18), dp(16), dp(18), dp(10))
        val header = LinearLayout(c)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        mArt = ImageView(c)
        mArt.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(mArt, dp(12).toFloat())
        header.addView(mArt, LinearLayout.LayoutParams(dp(56), dp(56)))
        val texts = LinearLayout(c)
        texts.orientation = LinearLayout.VERTICAL
        mTitle = label("", 16f, Color.WHITE, true, 1)
        mArtist = label("", 13f, Color.rgb(176, 176, 184), false, 1)
        texts.addView(mTitle)
        texts.addView(mArtist)
        val textsLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        textsLp.marginStart = dp(12)
        textsLp.marginEnd = dp(12)
        header.addView(texts, textsLp)
        mEq = EqualizerView(c)
        header.addView(mEq, LinearLayout.LayoutParams(dp(22), dp(18)))
        mView.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        mProgress = ProgressLine(c)
        val progLp = LinearLayout.LayoutParams(MATCH, dp(20))
        progLp.topMargin = dp(8)
        mView.addView(mProgress, progLp)
        mProgress.onSeek = { f ->
            if (mediaDuration > 0) {
                controller?.transportControls?.seekTo((f * mediaDuration).toLong())
            }
            scheduleCollapse()
        }
        val times = LinearLayout(c)
        times.orientation = LinearLayout.HORIZONTAL
        mElapsed = label("0:00", 11f, Color.rgb(154, 154, 162), false, 1)
        mTotal = label("0:00", 11f, Color.rgb(154, 154, 162), false, 1)
        times.addView(mElapsed, LinearLayout.LayoutParams(0, WRAP, 1f))
        times.addView(mTotal)
        mView.addView(times, LinearLayout.LayoutParams(MATCH, WRAP))

        val controls = LinearLayout(c)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        mPrev = ControlIconView(c, ControlIconView.PREV)
        mPlay = ControlIconView(c, ControlIconView.PLAY)
        mNext = ControlIconView(c, ControlIconView.NEXT)
        controls.addView(mPrev, LinearLayout.LayoutParams(dp(68), dp(48)))
        controls.addView(mPlay, LinearLayout.LayoutParams(dp(76), dp(48)))
        controls.addView(mNext, LinearLayout.LayoutParams(dp(68), dp(48)))
        mView.addView(controls, LinearLayout.LayoutParams(MATCH, WRAP))
        mPrev.setOnClickListener {
            controller?.transportControls?.skipToPrevious()
            scheduleCollapse()
        }
        mNext.setOnClickListener {
            controller?.transportControls?.skipToNext()
            scheduleCollapse()
        }
        mPlay.setOnClickListener {
            val tc = controller?.transportControls
            if (mediaPlaying) tc?.pause() else tc?.play()
            scheduleCollapse()
        }
        container.addView(mView, FrameLayout.LayoutParams(bigWidth(), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        mView.visibility = View.GONE

        // --- generic card
        kView = LinearLayout(c)
        kView.orientation = LinearLayout.VERTICAL
        kView.setPadding(dp(16), dp(14), dp(16), dp(14))
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        kIcon = ImageView(c)
        kIcon.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(kIcon, dp(11).toFloat())
        row.addView(kIcon, LinearLayout.LayoutParams(dp(44), dp(44)))
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        kApp = label("", 11f, Pal.GRAY, false, 1)
        kTitle = label("", 15f, Color.WHITE, true, 1)
        kText = label("", 13f, Color.rgb(209, 209, 214), false, 2)
        col.addView(kApp)
        col.addView(kTitle)
        col.addView(kText)
        val colLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        colLp.marginStart = dp(12)
        row.addView(col, colLp)
        kRing = RingView(c)
        val ringLp = LinearLayout.LayoutParams(dp(44), dp(44))
        ringLp.marginStart = dp(10)
        row.addView(kRing, ringLp)
        kRing.visibility = View.GONE
        kView.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        kSlider = ProgressLine(c)
        val slLp = LinearLayout.LayoutParams(MATCH, dp(26))
        slLp.topMargin = dp(10)
        kView.addView(kSlider, slLp)
        kSlider.visibility = View.GONE
        kActions = LinearLayout(c)
        kActions.orientation = LinearLayout.HORIZONTAL
        kActions.visibility = View.GONE
        val actLp = LinearLayout.LayoutParams(MATCH, WRAP)
        actLp.topMargin = dp(12)
        kView.addView(kActions, actLp)
        container.addView(kView, FrameLayout.LayoutParams(bigWidth(), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        kView.visibility = View.GONE

        // --- touch: tap, swipe up (dismiss), swipe down (open), long press (open settings)
        container.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var longFired = false
            private val longRun = Runnable {
                longFired = true
                openApp()
            }

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        longFired = false
                        handler.postDelayed(longRun, 650)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(e.rawX - downX) > dp(14) || abs(e.rawY - downY) > dp(14)) {
                            handler.removeCallbacks(longRun)
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(longRun)
                        if (longFired) return true
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (dy < -dp(22)) {
                            onSwipeUp()
                        } else if (dy > dp(22) && abs(dx) < dp(60)) {
                            onSwipeDown()
                        } else if (abs(dx) < dp(16) && abs(dy) < dp(16)) {
                            onTap()
                        }
                    }
                }
                return true
            }
        })

        // --- the window
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        params = WindowManager.LayoutParams(
            dp(60),
            dp(16),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // ------------------------------------------------------------------ deciding what to show

    private fun activeLives(): List<Live> {
        val out = ArrayList<Live>()
        for (l in notifLives.values) {
            if (l.type == T_CALL && !Prefs.on(ctx, Prefs.CALLS)) continue
            if (l.type == T_TIMER && !Prefs.on(ctx, Prefs.TIMERS)) continue
            out.add(l)
        }
        if (torchOn && Prefs.on(ctx, Prefs.TORCH)) out.add(torchLive)
        if (mediaOk()) out.add(mediaLive)
        out.sortByDescending { it.prio }
        return out
    }

    private fun mediaOk(): Boolean =
        Prefs.on(ctx, Prefs.MEDIA) && mediaVisible && controller != null && !mediaTitle.isNullOrEmpty()

    fun refresh() {
        handler.post { render() }
    }

    private fun render(force: Boolean = false) {
        if (!Prefs.on(ctx, Prefs.ENABLED) || !Settings.canDrawOverlays(ctx)) {
            setMode(HIDDEN, false)
            return
        }
        val lives = activeLives()
        val ex = expandedLive
        if (ex != null && lives.none { it.id == ex }) {
            expandedLive = null
            liveCard = null
        }
        val target = when {
            currentCard != null -> CARD
            expandedLive == "media" -> MEDIA_BIG
            expandedLive != null -> CARD
            lives.isNotEmpty() -> COMPACT
            else -> HIDDEN
        }
        if (target == COMPACT) bindCompact(lives)
        setMode(target, force)
        val needTick = mode != HIDDEN &&
            (lives.any { it.type == T_TIMER || it.type == T_CALL })
        setTicker(needTick)
    }

    private fun setTicker(on: Boolean) {
        if (on && !tickerOn) {
            tickerOn = true
            handler.postDelayed(ticker, 1000)
        } else if (!on && tickerOn) {
            tickerOn = false
            handler.removeCallbacks(ticker)
        }
    }

    /** Runs once a second while a timer or call is on screen. */
    private fun tick() {
        val lives = activeLives()
        if (mode == COMPACT && lives.isNotEmpty()) {
            val b = if (lives.size > 1) lives[1] else lives[0]
            if (b.type == T_TIMER || b.type == T_CALL) cText.text = liveClock(b)
        }
        val lc = liveCard
        val ex = expandedLive
        if (mode == CARD && lc != null && ex != null) {
            val l = lives.firstOrNull { it.id == ex }
            if (l != null && (l.type == T_TIMER || l.type == T_CALL)) kText.text = liveClock(l)
        }
    }

    private fun liveClock(l: Live): String {
        val now = System.currentTimeMillis()
        val ms = if (l.countDown) max(0L, l.whenMs - now) else max(0L, now - l.whenMs)
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun bindCompact(lives: List<Live>) {
        val a = lives[0]
        val b = if (lives.size > 1) lives[1] else lives[0]

        if (a.type == T_MEDIA) {
            val art = mediaArt
            if (art != null) cArt.setImageBitmap(art) else cArt.setImageDrawable(ColorDrawable(Color.rgb(58, 58, 60)))
        } else {
            cArt.setImageDrawable(a.icon)
        }

        cEq.visibility = View.GONE
        cPulse.visibility = View.GONE
        cText.visibility = View.GONE
        var extra = 0
        when (b.type) {
            T_MEDIA -> {
                cEq.visibility = View.VISIBLE
                cEq.setColor(accentColor)
            }
            T_TORCH -> {
                cPulse.visibility = View.VISIBLE
                cPulse.color = Pal.YELLOW
            }
            else -> {
                cText.visibility = View.VISIBLE
                cText.text = liveClock(b)
                cText.setTextColor(b.color)
                extra = dp(22)
            }
        }
        compactW = dp(Prefs.int(ctx, Prefs.WIDTH_DP, Prefs.DEFAULT_WIDTH_DP)) + extra
    }

    // ------------------------------------------------------------------ the window itself

    private fun setMode(newMode: Int, force: Boolean) {
        if (newMode == HIDDEN) {
            hideIsland()
            return
        }
        if (newMode == mode && !force) return
        val wasHidden = mode == HIDDEN
        val old = mode
        mode = newMode
        if (wasHidden) {
            if (!attached) {
                attachIsland()
            } else {
                container.animate().cancel()
                container.animate().setStartDelay(0).alpha(1f).setDuration(120).start()
            }
        }
        if (!attached) {
            mode = HIDDEN
            return
        }
        val bw = bigWidth()
        (mView.layoutParams as FrameLayout.LayoutParams).width = bw
        (kView.layoutParams as FrameLayout.LayoutParams).width = bw

        val smooth = Prefs.on(ctx, Prefs.SMOOTH)
        wAnim.spring.setDampingRatio(if (smooth) 0.92f else 0.62f)
        hAnim.spring.setDampingRatio(if (smooth) 0.95f else 0.7f)

        showContent(newMode)
        val size = targetSize(newMode)
        wAnim.animateToFinalPosition(size.first.toFloat())
        hAnim.animateToFinalPosition(size.second.toFloat())
        handler.removeCallbacks(progressTick)
        if (newMode == MEDIA_BIG) handler.post(progressTick)
        if (newMode != CARD && newMode != MEDIA_BIG) applyGlow(0)
        if (wasHidden || old != newMode) haptic()
    }

    private fun targetSize(m: Int): Pair<Int, Int> {
        val bw = bigWidth()
        return when (m) {
            COMPACT -> Pair(compactW, dp(SMALL_H))
            MEDIA_BIG -> Pair(bw, measuredHeight(mView, bw))
            else -> Pair(bw, max(dp(76), measuredHeight(kView, bw)))
        }
    }

    private fun measuredHeight(v: View, width: Int): Int {
        v.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return v.measuredHeight
    }

    /** Old content fades out fast; new content fades in with a small zoom. */
    private fun showContent(m: Int) {
        val pairs = listOf(COMPACT to cView, MEDIA_BIG to mView, CARD to kView)
        for ((viewMode, v) in pairs) {
            if (viewMode == m) {
                v.animate().cancel()
                v.visibility = View.VISIBLE
                v.alpha = 0f
                v.scaleX = 0.92f
                v.scaleY = 0.92f
                v.animate().setStartDelay(90).alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
            } else if (v.visibility == View.VISIBLE) {
                v.animate().cancel()
                v.animate().setStartDelay(0).alpha(0f).setDuration(110).withEndAction {
                    if (mode != viewMode) v.visibility = View.GONE
                }.start()
            }
        }
    }

    private fun attachIsland() {
        if (attached) return
        wAnim.cancel()
        hAnim.cancel()
        params.width = dp(60)
        params.height = dp(16)
        params.y = dp(Prefs.int(ctx, Prefs.TOP_DP, Prefs.DEFAULT_TOP_DP))
        wHolder.value = params.width.toFloat()
        hHolder.value = params.height.toFloat()
        cornerPx = params.height / 2f
        pillBg.cornerRadius = cornerPx
        container.alpha = 0f
        try {
            wm.addView(container, params)
            attached = true
            Diag.add("island window added")
        } catch (e: Exception) {
            attached = false
            Diag.add("could not add window: " + e)
            return
        }
        container.animate().cancel()
        container.animate().setStartDelay(0).alpha(1f).setDuration(160).start()
    }

    private fun hideIsland() {
        handler.removeCallbacks(progressTick)
        if (mode == HIDDEN) return
        mode = HIDDEN
        setTicker(false)
        if (!attached) return
        wAnim.animateToFinalPosition(dp(54).toFloat())
        hAnim.animateToFinalPosition(dp(12).toFloat())
        container.animate().cancel()
        container.animate().setStartDelay(40).alpha(0f).setDuration(220).withEndAction {
            if (mode == HIDDEN) detachIsland()
        }.start()
    }

    private fun detachIsland() {
        mode = HIDDEN
        handler.removeCallbacks(progressTick)
        wAnim.cancel()
        hAnim.cancel()
        if (attached) {
            try {
                wm.removeView(container)
            } catch (e: Exception) {
            }
            attached = false
        }
    }

    private fun onWidth(v: Float) {
        params.width = max(v.toInt(), dp(16))
        push()
    }

    private fun onHeight(v: Float) {
        params.height = max(v.toInt(), dp(8))
        push()
    }

    /** Both springs ask for a layout every frame; this merges them into one. */
    private fun push() {
        if (!attached || pushScheduled) return
        pushScheduled = true
        container.postOnAnimation {
            pushScheduled = false
            if (attached) {
                cornerPx = min(params.height / 2f, dp(34).toFloat())
                pillBg.cornerRadius = cornerPx
                container.invalidateOutline()
                try {
                    wm.updateViewLayout(container, params)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun applyGlow(color: Int) {
        if (color != 0 && Prefs.on(ctx, Prefs.GLOW)) {
            pillBg.setStroke(dp(1), withAlpha(color, 170))
        } else {
            pillBg.setStroke(0, 0)
        }
    }

    private fun haptic() {
        if (Prefs.on(ctx, Prefs.HAPTICS)) {
            container.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    private fun openApp() {
        try {
            val i = Intent(ctx, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Diag.add("open app failed: " + e)
        }
    }

    // ------------------------------------------------------------------ touch actions

    private fun onTap() {
        when (mode) {
            CARD -> {
                val c = currentCard ?: liveCard
                try {
                    c?.onTap?.invoke()
                } catch (e: Exception) {
                }
                dismissShown()
            }
            COMPACT -> expandTop()
            MEDIA_BIG -> {
                expandedLive = null
                handler.removeCallbacks(collapseRun)
                render()
            }
        }
    }

    private fun onSwipeDown() {
        if (mode == COMPACT) expandTop()
    }

    private fun onSwipeUp() {
        when (mode) {
            CARD -> dismissShown()
            MEDIA_BIG -> {
                expandedLive = null
                handler.removeCallbacks(collapseRun)
                render()
            }
            COMPACT -> {
                val lives = activeLives()
                if (lives.isNotEmpty()) {
                    val top = lives[0]
                    if (top.type == T_MEDIA) {
                        dismissedTitle = mediaTitle
                        mediaVisible = false
                    } else if (top.type == T_TORCH) {
                        setTorch(false)
                    } else {
                        notifLives.remove(top.id)
                    }
                }
                render()
            }
        }
    }

    private fun expandTop() {
        val lives = activeLives()
        if (lives.isEmpty()) return
        val l = lives[0]
        expandedLive = l.id
        if (l.type != T_MEDIA) {
            val c = cardForLive(l)
            liveCard = c
            bindCard(c, true)
        }
        scheduleCollapse()
        render(true)
    }

    private fun scheduleCollapse() {
        handler.removeCallbacks(collapseRun)
        handler.postDelayed(collapseRun, 8000)
    }

    private fun dismissShown() {
        if (currentCard != null) {
            nextCard()
        } else if (expandedLive != null) {
            expandedLive = null
            liveCard = null
            handler.removeCallbacks(collapseRun)
            render()
        }
    }

    private fun cardForLive(l: Live): Card {
        val contentPi = l.intent
        return when (l.type) {
            T_TORCH -> {
                val max = torchMax()
                val frac = if (max > 1) (torchLevel() - 1f) / (max - 1f) else -1f
                Card(
                    key = "live-torch", appName = "Flashlight", title = "Flashlight", text = "On",
                    icon = l.icon, accent = Pal.YELLOW,
                    actions = listOf(CardAction("Turn off", Pal.RED) { setTorch(false) }),
                    slider = frac, onSlider = { f -> setTorchLevel(f) }
                )
            }
            T_CALL -> Card(
                key = "live-" + l.id, appName = l.appName, title = l.title, text = liveClock(l),
                icon = l.icon, accent = Pal.GREEN,
                actions = actionsToCard(l.actions),
                onTap = { sendIntent(contentPi) }
            )
            else -> Card(
                key = "live-" + l.id, appName = l.appName, title = l.title, text = liveClock(l),
                icon = l.icon, accent = Pal.ORANGE,
                onTap = { sendIntent(contentPi) }
            )
        }
    }

    private fun sendIntent(pi: PendingIntent?) {
        try {
            pi?.send()
        } catch (e: Exception) {
        }
    }

    private fun actionsToCard(list: List<Pair<String, PendingIntent>>): List<CardAction> {
        val red = listOf("decline", "reject", "hang", "end", "dismiss", "ignore", "cancel", "stop")
        val out = ArrayList<CardAction>()
        for (a in list.take(2)) {
            val name = a.first
            val pi = a.second
            val isRed = red.any { name.lowercase().contains(it) }
            out.add(CardAction(name, if (isRed) Pal.RED else Pal.GREEN) { sendIntent(pi) })
        }
        return out
    }

    // ------------------------------------------------------------------ cards

    private fun postCard(c: Card, replace: Boolean = false) {
        if (!Prefs.on(ctx, Prefs.ENABLED)) return
        val cur = currentCard
        if (replace && cur != null && cur.key == c.key) {
            currentCard = c
            bindCard(c, false)
            handler.removeCallbacks(cardTimeout)
            handler.postDelayed(cardTimeout, c.seconds * 1000L)
            return
        }
        if (replace) cardQueue.removeAll { it.key == c.key }
        if (c.urgent) cardQueue.addFirst(c) else cardQueue.addLast(c)
        while (cardQueue.size > 6) cardQueue.removeFirst()
        if (currentCard == null || c.urgent) nextCard()
    }

    private fun nextCard() {
        handler.removeCallbacks(cardTimeout)
        val next = cardQueue.removeFirstOrNull()
        currentCard = next
        if (next != null) {
            bindCard(next, true)
            handler.postDelayed(cardTimeout, (if (next.sticky) 60 else next.seconds) * 1000L)
        } else {
            val lc = liveCard
            if (lc != null) bindCard(lc, true)
        }
        render(true)
    }

    private fun bindCard(c: Card, animate: Boolean) {
        kIcon.setImageDrawable(c.icon)
        kApp.text = c.appName
        kTitle.text = c.title
        kText.text = c.text
        kText.visibility = if (c.text.isEmpty()) View.GONE else View.VISIBLE
        if (c.ring >= 0f) {
            kRing.visibility = View.VISIBLE
            kRing.set(c.ring, c.ringText, if (c.accent != 0) c.accent else Color.WHITE, animate)
        } else {
            kRing.visibility = View.GONE
        }
        if (c.slider >= 0f) {
            kSlider.visibility = View.VISIBLE
            kSlider.accent = if (c.accent != 0) c.accent else Color.WHITE
            kSlider.fraction = c.slider
            kSlider.onSeek = { f ->
                c.onSlider?.invoke(f)
                scheduleCollapse()
            }
        } else {
            kSlider.visibility = View.GONE
            kSlider.onSeek = null
        }
        buildActions(c)
        applyGlow(c.accent)
        if (animate) {
            kIcon.scaleX = 0.5f
            kIcon.scaleY = 0.5f
            kIcon.animate().setStartDelay(120).scaleX(1f).scaleY(1f).setDuration(420)
                .setInterpolator(OvershootInterpolator(2.4f)).start()
        }
    }

    private fun buildActions(c: Card) {
        kActions.removeAllViews()
        if (c.actions.isEmpty()) {
            kActions.visibility = View.GONE
            return
        }
        kActions.visibility = View.VISIBLE
        for ((i, a) in c.actions.withIndex()) {
            val b = TextView(ctx)
            b.text = a.label
            b.textSize = 15f
            b.typeface = Typeface.DEFAULT_BOLD
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            val bg = GradientDrawable()
            bg.setColor(a.color)
            bg.cornerRadius = dp(22).toFloat()
            b.background = bg
            b.setOnClickListener {
                try {
                    a.run()
                } catch (e: Exception) {
                }
                dismissShown()
            }
            val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
            if (i > 0) lp.marginStart = dp(10)
            kActions.addView(b, lp)
        }
    }

    // ------------------------------------------------------------------ notifications

    fun onPosted(sbn: StatusBarNotification, importance: Int) {
        handler.post { handle(sbn, importance, false) }
    }

    fun onRemoved(sbn: StatusBarNotification) {
        handler.post {
            val key = sbn.key
            cardQueue.removeAll { it.key == key }
            val cur = currentCard
            if (cur != null && cur.key == key) nextCard()
            if (notifLives.remove(key) != null) {
                if (expandedLive == key) {
                    expandedLive = null
                    liveCard = null
                }
                render()
            }
        }
    }

    private fun actionsOf(n: Notification): List<Pair<String, PendingIntent>> {
        val out = ArrayList<Pair<String, PendingIntent>>()
        val list = n.actions ?: return out
        for (a in list) {
            val pi = a.actionIntent
            val t = a.title?.toString()
            if (pi != null && t != null) out.add(Pair(t, pi))
        }
        return out
    }

    private fun handle(sbn: StatusBarNotification, importance: Int, initial: Boolean) {
        try {
            if (!Prefs.on(ctx, Prefs.ENABLED)) return
            val pkg = sbn.packageName
            if (pkg == ctx.packageName) return
            val n = sbn.notification ?: return
            if (Prefs.blocked(ctx).contains(pkg)) {
                Diag.add("blocked app: " + pkg)
                return
            }
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

            val ex = n.extras
            val cat = n.category
            if (cat == Notification.CATEGORY_TRANSPORT || cat == Notification.CATEGORY_PROGRESS ||
                cat == Notification.CATEGORY_SERVICE
            ) return
            if (ex != null && ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) return

            val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
            val chrono = ex != null && ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
            val callType = if (ex != null) ex.getInt("android.callType", 0) else 0
            val isCall = cat == Notification.CATEGORY_CALL || callType != 0
            val isAlarm = cat == Notification.CATEGORY_ALARM || cat == Notification.CATEGORY_REMINDER
            val liveCall = isCall && (callType == 2 || chrono)
            val incomingCall = isCall && !liveCall
            val liveTimer = !isCall && chrono && ongoing

            val app = appLabel(pkg)
            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex?.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: ex?.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            val largeIcon: Drawable? = try {
                n.getLargeIcon()?.loadDrawable(ctx)
            } catch (e: Exception) {
                null
            }
            val icon: Drawable? = largeIcon ?: appIcon(pkg)

            // running timers and calls stay on the island as a small pill
            if (liveCall || liveTimer) {
                if (liveCall && !Prefs.on(ctx, Prefs.CALLS)) return
                if (liveTimer && !Prefs.on(ctx, Prefs.TIMERS)) return
                val countDown = ex != null && ex.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN, false)
                val whenMs = if (n.`when` > 0L) n.`when` else System.currentTimeMillis()
                val live = Live(
                    sbn.key,
                    if (liveCall) T_CALL else T_TIMER,
                    app,
                    if (liveCall) badge(Emoji.PHONE, Pal.GREEN) else icon,
                    title.ifEmpty { app },
                    text,
                    whenMs,
                    countDown,
                    if (liveCall) Pal.GREEN else Pal.ORANGE,
                    n.contentIntent,
                    actionsOf(n)
                )
                notifLives[sbn.key] = live
                Diag.add((if (liveCall) "call live: " else "timer live: ") + app)
                render()
                return
            }
            if (notifLives.containsKey(sbn.key)) {
                notifLives.remove(sbn.key)
                if (expandedLive == sbn.key) {
                    expandedLive = null
                    liveCard = null
                }
                render()
            }

            if (initial) return
            if (ongoing && !incomingCall) {
                Diag.add("skip ongoing: " + pkg)
                return
            }
            if (incomingCall || isAlarm) {
                if (!Prefs.on(ctx, Prefs.CALLS)) return
            } else if (!Prefs.on(ctx, Prefs.NOTIFS)) {
                return
            }
            if (importance < NotificationManager.IMPORTANCE_DEFAULT && !incomingCall && !isAlarm) {
                Diag.add("skip silent: " + pkg)
                return
            }
            if (title.isEmpty() && text.isEmpty()) return

            val dedupe = sbn.key + "|" + title.hashCode() + "|" + text.hashCode()
            val now = SystemClock.elapsedRealtime()
            val last = recent[dedupe]
            if (last != null && now - last < 8000) return
            if (recent.size > 60) recent.clear()
            recent[dedupe] = now

            val hide = Prefs.on(ctx, Prefs.HIDE_TEXT)
            val acts = if (incomingCall) actionsToCard(actionsOf(n)) else emptyList()
            val contentPi = n.contentIntent
            val secs = if (incomingCall) 40 else if (isAlarm) 15 else Prefs.int(ctx, Prefs.SECONDS, Prefs.DEFAULT_SECONDS)
            val card = Card(
                key = sbn.key,
                appName = app,
                title = if (hide) app else title.ifEmpty { app },
                text = if (hide) "New notification" else text,
                icon = icon,
                accent = if (incomingCall) Pal.GREEN else if (isAlarm) Pal.ORANGE else 0,
                seconds = secs,
                actions = acts,
                onTap = { sendIntent(contentPi) },
                urgent = incomingCall,
                sticky = incomingCall
            )
            Diag.add("notification: " + app)
            postCard(card)
        } catch (e: Exception) {
            Diag.add("error in notification: " + e)
        }
    }

    // ------------------------------------------------------------------ torch

    private fun onTorch(id: String, enabled: Boolean) {
        if (enabled) torchId = id
        val changed = enabled != torchOn
        torchOn = enabled
        Diag.add("flashlight " + (if (enabled) "on" else "off"))
        if (changed && ready && Prefs.on(ctx, Prefs.ENABLED) && Prefs.on(ctx, Prefs.TORCH)) {
            postCard(
                evt(
                    "torch-evt", Emoji.FLASH, Pal.YELLOW,
                    if (enabled) "Flashlight on" else "Flashlight off", "", -1f, "", 2, "Flashlight"
                ),
                true
            )
        }
        if (!enabled && expandedLive == "torch") {
            expandedLive = null
            liveCard = null
        }
        render()
    }

    private fun flashId(): String? {
        torchId?.let { return it }
        return try {
            camera.cameraIdList.firstOrNull {
                camera.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val id = flashId()
            if (id != null) camera.setTorchMode(id, on) else Diag.add("no flashlight found")
        } catch (e: Exception) {
            Diag.add("flashlight error: " + e)
        }
    }

    private fun torchMax(): Int {
        if (Build.VERSION.SDK_INT < 33) return 1
        val id = torchId ?: return 1
        return try {
            camera.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
        } catch (e: Exception) {
            1
        }
    }

    private fun torchLevel(): Int {
        if (Build.VERSION.SDK_INT < 33) return 1
        val id = torchId ?: return 1
        return try {
            camera.getTorchStrengthLevel(id)
        } catch (e: Exception) {
            1
        }
    }

    private fun setTorchLevel(f: Float) {
        if (Build.VERSION.SDK_INT < 33) return
        val id = torchId ?: return
        val mx = torchMax()
        if (mx <= 1) return
        val level = (1f + f * (mx - 1)).roundToInt().coerceIn(1, mx)
        try {
            camera.turnOnTorchWithStrengthLevel(id, level)
        } catch (e: Exception) {
            Diag.add("flashlight strength error: " + e)
        }
    }

    // ------------------------------------------------------------------ system events

    private fun registerSystemListeners() {
        try {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_POWER_CONNECTED)
            f.addAction(Intent.ACTION_POWER_DISCONNECTED)
            f.addAction(Intent.ACTION_BATTERY_CHANGED)
            f.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            f.addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            f.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            f.addAction("android.media.VOLUME_CHANGED_ACTION")
            if (Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(sysReceiver, f, Context.RECEIVER_EXPORTED)
            } else {
                ctx.registerReceiver(sysReceiver, f)
            }
        } catch (e: Exception) {
            Diag.add("receiver error: " + e)
        }
        try {
            audio.registerAudioDeviceCallback(deviceCb, handler)
        } catch (e: Exception) {
            Diag.add("audio callback error: " + e)
        }
        try {
            camera.registerTorchCallback(torchCb, handler)
        } catch (e: Exception) {
            Diag.add("torch callback error: " + e)
        }
    }

    private fun batteryPercent(): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level >= 0 && scale > 0) level * 100 / scale else -1
    }

    private fun onSystem(i: Intent) {
        val action = i.action ?: return
        if (action == Intent.ACTION_BATTERY_CHANGED) {
            handleBattery(i)
            return
        }
        if (!ready || !Prefs.on(ctx, Prefs.ENABLED)) return

        if (action == Intent.ACTION_POWER_CONNECTED) {
            if (Prefs.on(ctx, Prefs.CHARGING)) {
                val p = max(0, batteryPercent())
                postCard(evt("charge", Emoji.BOLT, Pal.GREEN, "Charging", p.toString() + "% battery", p / 100f, p.toString() + "%", 3, "Battery"), true)
            }
        } else if (action == Intent.ACTION_POWER_DISCONNECTED) {
            if (Prefs.on(ctx, Prefs.CHARGING)) {
                val p = max(0, batteryPercent())
                postCard(evt("charge", Emoji.PLUG, Pal.GRAY, "Unplugged", p.toString() + "% battery", p / 100f, p.toString() + "%", 2, "Battery"), true)
            }
        } else if (action == AudioManager.RINGER_MODE_CHANGED_ACTION) {
            if (Prefs.on(ctx, Prefs.RINGER)) {
                val m = audio.ringerMode
                if (m == AudioManager.RINGER_MODE_SILENT) {
                    postCard(evt("ringer", Emoji.BELL_OFF, Pal.RED, "Silent", "Sounds are off", -1f, "", 2, "Sound"), true)
                } else if (m == AudioManager.RINGER_MODE_VIBRATE) {
                    postCard(evt("ringer", Emoji.VIBRATE, Pal.ORANGE, "Vibrate", "Sounds are off", -1f, "", 2, "Sound"), true)
                } else {
                    postCard(evt("ringer", Emoji.BELL, Pal.BLUE, "Ring", "Sounds are on", -1f, "", 2, "Sound"), true)
                }
            }
        } else if (action == NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED) {
            if (Prefs.on(ctx, Prefs.DND)) {
                val f = nm.currentInterruptionFilter
                val on = f != NotificationManager.INTERRUPTION_FILTER_ALL &&
                    f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
                postCard(
                    evt(
                        "dnd", Emoji.MOON, Pal.PURPLE, "Do Not Disturb",
                        if (on) "On" else "Off", -1f, "", 2, "Focus"
                    ),
                    true
                )
            }
        } else if (action == Intent.ACTION_AIRPLANE_MODE_CHANGED) {
            if (Prefs.on(ctx, Prefs.AIRPLANE)) {
                val on = i.getBooleanExtra("state", false)
                postCard(
                    evt(
                        "airplane", Emoji.PLANE, Pal.ORANGE, "Airplane mode",
                        if (on) "On" else "Off", -1f, "", 2, "Network"
                    ),
                    true
                )
            }
        } else if (action == "android.media.VOLUME_CHANGED_ACTION") {
            if (Prefs.on(ctx, Prefs.VOLUME)) {
                val type = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                if (type == AudioManager.STREAM_MUSIC || type == AudioManager.STREAM_RING) {
                    val mx = max(1, audio.getStreamMaxVolume(type))
                    val v = audio.getStreamVolume(type)
                    val frac = v.toFloat() / mx
                    val emoji = if (v == 0) Emoji.VOL_OFF else if (frac < 0.34f) Emoji.VOL_LOW
                    else if (frac < 0.67f) Emoji.VOL_MID else Emoji.VOL_HIGH
                    val pct = (frac * 100f).roundToInt().toString() + "%"
                    postCard(
                        evt(
                            "volume", emoji, Pal.BLUE,
                            if (type == AudioManager.STREAM_RING) "Ringer volume" else "Volume",
                            "", frac, pct, 2, "Sound"
                        ),
                        true
                    )
                }
            }
        }
    }

    private fun handleBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        if (pct < 0) return
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (ready && Prefs.on(ctx, Prefs.ENABLED)) {
            if (!plugged && Prefs.on(ctx, Prefs.LOWBATT)) {
                if (lastLevel > 20 && pct <= 20) {
                    postCard(evt("lowbatt", Emoji.BATTERY, Pal.RED, "Low battery", pct.toString() + "% remaining", pct / 100f, pct.toString() + "%", 5, "Battery"), true)
                } else if (lastLevel > 10 && pct <= 10) {
                    postCard(evt("lowbatt", Emoji.BATTERY, Pal.RED, "Battery very low", pct.toString() + "% remaining", pct / 100f, pct.toString() + "%", 6, "Battery"), true)
                }
            }
            if (plugged && !lastFull && Prefs.on(ctx, Prefs.CHARGING) &&
                (pct >= 100 || status == BatteryManager.BATTERY_STATUS_FULL)
            ) {
                postCard(evt("charge", Emoji.BATTERY, Pal.GREEN, "Fully charged", "100%", 1f, "100%", 4, "Battery"), true)
            }
        }
        lastFull = plugged && (pct >= 100 || status == BatteryManager.BATTERY_STATUS_FULL)
        lastLevel = pct
    }

    private fun onDevices(devs: Array<out AudioDeviceInfo>?, added: Boolean) {
        if (devs == null || !ready) return
        if (!Prefs.on(ctx, Prefs.ENABLED) || !Prefs.on(ctx, Prefs.HEADSET)) return
        for (d in devs) {
            if (!d.isSink) continue
            val t = d.type
            val wired = t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_USB_HEADSET
            val bt = t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET)
            if (!wired && !bt) continue
            val name = if (bt) (d.productName?.toString() ?: "") else ""
            val title = if (name.isNotBlank()) name else if (bt) "Bluetooth audio" else "Headphones"
            postCard(
                evt(
                    "headset", Emoji.HEADPHONES, Pal.BLUE, title,
                    if (added) "Connected" else "Disconnected", -1f, "", 3, "Audio"
                ),
                true
            )
            return
        }
    }

    // ------------------------------------------------------------------ music

    fun onListenerConnected() {
        handler.post {
            startMediaWatching()
            try {
                val list = IslandListener.instance?.activeNotifications
                if (list != null) {
                    for (s in list) handle(s, NotificationManager.IMPORTANCE_DEFAULT, true)
                }
            } catch (e: Exception) {
                Diag.add("scan failed: " + e)
            }
            render()
        }
    }

    fun onListenerDisconnected() {
        handler.post { stopMediaWatching() }
    }

    private fun startMediaWatching() {
        try {
            val cn = ComponentName(ctx, IslandListener::class.java)
            val sm = ctx.getSystemService(MediaSessionManager::class.java)
            sessionManager = sm
            sm.addOnActiveSessionsChangedListener(sessionListener, cn, handler)
            val list = sm.getActiveSessions(cn)
            Diag.add("music sessions found: " + list.size)
            onSessions(list)
        } catch (e: Exception) {
            Diag.add("music watching failed: " + e)
        }
    }

    private fun stopMediaWatching() {
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionListener)
            controller?.unregisterCallback(controllerCallback)
        } catch (e: Exception) {
        }
        controller = null
        sessionManager = null
    }

    private fun onSessions(list: List<MediaController>) {
        val playing = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val keep = list.firstOrNull { it.sessionToken == controller?.sessionToken }
        val best = playing ?: keep ?: list.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(controllerCallback)
            controller = best
            best?.registerCallback(controllerCallback, handler)
            mediaVisible = false
        }
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        if (c == null) {
            mediaTitle = null
            mediaPlaying = false
            mediaVisible = false
            if (expandedLive == "media") expandedLive = null
            render()
            return
        }
        val md = c.metadata
        val st = c.playbackState

        val newTitle = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val newArtist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        mediaDuration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val state = st?.state ?: PlaybackState.STATE_NONE
        val playing = state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING
        val trackChanged = newTitle != mediaTitle
        val hadTrack = mediaTitle != null
        val wasPlaying = mediaPlaying

        mediaTitle = newTitle
        mediaArtist = newArtist
        if (art != null || trackChanged) {
            mediaArt = art
            accentColor = accentFrom(art)
        }
        mediaPlaying = playing

        if (trackChanged || (playing && !wasPlaying)) dismissedTitle = null

        if (playing) {
            if (dismissedTitle == null || dismissedTitle != newTitle) mediaVisible = true
            handler.removeCallbacks(mediaHide)
        } else if (state == PlaybackState.STATE_STOPPED || state == PlaybackState.STATE_NONE) {
            handler.removeCallbacks(mediaHide)
            mediaVisible = false
            if (expandedLive == "media") expandedLive = null
        } else if (mediaVisible) {
            handler.removeCallbacks(mediaHide)
            handler.postDelayed(mediaHide, 12000)
        }

        bindMedia()

        if (trackChanged && hadTrack && playing && ready && !newTitle.isNullOrEmpty() &&
            Prefs.on(ctx, Prefs.TRACKPEEK) && Prefs.on(ctx, Prefs.MEDIA) && Prefs.on(ctx, Prefs.ENABLED) &&
            expandedLive != "media"
        ) {
            val icon: Drawable = if (art != null) BitmapDrawable(ctx.resources, art) else badge(Emoji.NOTE, Pal.PINK)
            postCard(
                Card(
                    key = "track", appName = "Now playing", title = newTitle ?: "",
                    text = newArtist ?: "", icon = icon, accent = accentColor, seconds = 3
                ),
                true
            )
        } else {
            render()
        }
    }

    private fun bindMedia() {
        mTitle.text = mediaTitle ?: ""
        mArtist.text = mediaArtist ?: ""
        val art = mediaArt
        if (art != null) {
            mArt.setImageBitmap(art)
        } else {
            mArt.setImageDrawable(ColorDrawable(Color.rgb(58, 58, 60)))
        }
        mEq.setColor(accentColor)
        cEq.setColor(accentColor)
        mProgress.accent = accentColor
        mPlay.kind = if (mediaPlaying) ControlIconView.PAUSE else ControlIconView.PLAY
        applyEq()
        updateProgress()
    }

    private fun applyEq() {
        val run = Prefs.on(ctx, Prefs.EQUALIZER) && mediaPlaying
        cEq.setPlaying(run)
        mEq.setPlaying(run)
    }

    private fun accentFrom(b: Bitmap?): Int {
        if (b == null) return Color.WHITE
        return try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            if (hsv[1] < 0.15f) {
                Color.WHITE
            } else {
                hsv[1] = max(hsv[1], 0.5f)
                hsv[2] = max(hsv[2], 0.9f)
                Color.HSVToColor(hsv)
            }
        } catch (e: Exception) {
            Color.WHITE
        }
    }

    private fun currentPosition(): Long {
        val st = controller?.playbackState ?: return 0L
        var pos = st.position
        if (pos < 0) pos = 0
        if (st.state == PlaybackState.STATE_PLAYING) {
            val delta = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
            pos += (delta * st.playbackSpeed).toLong()
        }
        if (mediaDuration > 0) pos = min(pos, mediaDuration)
        return max(pos, 0L)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val pos = currentPosition()
        if (!mProgress.dragging) {
            mProgress.fraction = if (mediaDuration > 0) pos.toFloat() / mediaDuration else 0f
        }
        mElapsed.text = fmt(pos)
        mTotal.text = if (mediaDuration > 0) fmt(mediaDuration) else "--:--"
    }

    // ------------------------------------------------------------------ demos for the app screen

    fun demo(kind: String) {
        handler.post {
            if (!Prefs.on(ctx, Prefs.ENABLED)) {
                Diag.add("demo ignored: island is switched off")
                return@post
            }
            when (kind) {
                "notif" -> postCard(
                    Card(
                        key = "demo-n", appName = "Messages", title = "Alex",
                        text = "Are we still on for tonight?", icon = badge(Emoji.CHAT, Pal.GREEN),
                        seconds = 5
                    ),
                    true
                )
                "music" -> postCard(
                    Card(
                        key = "demo-m", appName = "Now playing", title = "Midnight City",
                        text = "M83", icon = badge(Emoji.NOTE, Pal.PINK), accent = Pal.PINK, seconds = 4
                    ),
                    true
                )
                "charge" -> postCard(evt("demo-c", Emoji.BOLT, Pal.GREEN, "Charging", "82% battery", 0.82f, "82%", 4, "Battery"), true)
                "headset" -> postCard(evt("demo-h", Emoji.HEADPHONES, Pal.BLUE, "Headphones", "Connected", -1f, "", 3, "Audio"), true)
                "volume" -> postCard(evt("demo-v", Emoji.VOL_MID, Pal.BLUE, "Volume", "", 0.6f, "60%", 3, "Sound"), true)
                "ringer" -> postCard(evt("demo-r", Emoji.BELL_OFF, Pal.RED, "Silent", "Sounds are off", -1f, "", 3, "Sound"), true)
                "call" -> postCard(
                    Card(
                        key = "demo-call", appName = "Phone", title = "Sam Rivera",
                        text = "Incoming call", icon = badge(Emoji.PHONE, Pal.GREEN), accent = Pal.GREEN,
                        seconds = 8,
                        actions = listOf(
                            CardAction("Decline", Pal.RED) {},
                            CardAction("Answer", Pal.GREEN) {}
                        ),
                        urgent = true
                    )
                )
                "timer" -> {
                    notifLives["demo-timer"] = Live(
                        "demo-timer", T_TIMER, "Timer", badge(Emoji.TIMER, Pal.ORANGE), "Timer", "",
                        System.currentTimeMillis() + 5 * 60 * 1000L, true, Pal.ORANGE, null, emptyList()
                    )
                    render()
                    handler.postDelayed({
                        notifLives.remove("demo-timer")
                        if (expandedLive == "demo-timer") {
                            expandedLive = null
                            liveCard = null
                        }
                        render()
                    }, 20000)
                }
                "torch" -> setTorch(!torchOn)
                else -> {}
            }
        }
    }

    // ------------------------------------------------------------------ shutdown and start

    fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        try {
            Prefs.sp(ctx).unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (e: Exception) {
        }
        try {
            ctx.unregisterReceiver(sysReceiver)
        } catch (e: Exception) {
        }
        try {
            audio.unregisterAudioDeviceCallback(deviceCb)
        } catch (e: Exception) {
        }
        try {
            camera.unregisterTorchCallback(torchCb)
        } catch (e: Exception) {
        }
        stopMediaWatching()
        detachIsland()
        Diag.add("engine stopped")
    }

    // This must stay at the very end: it runs after every property above has been set up.
    init {
        buildViews()
        Prefs.sp(ctx).registerOnSharedPreferenceChangeListener(prefListener)
        registerSystemListeners()
        handler.postDelayed({
            ready = true
            Diag.add("island ready")
        }, 2000)
        if (Diag.listenerConnected) onListenerConnected()
        Diag.add("engine created")
    }
}
