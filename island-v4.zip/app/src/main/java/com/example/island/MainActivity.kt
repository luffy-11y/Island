package com.example.island

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private class StatusRow(val view: View, val dot: View, val status: TextView)

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pages: Array<ScrollView>
    private lateinit var indicator: View
    private var current = 0

    private lateinit var overlayRow: StatusRow
    private lateinit var listenerRow: StatusRow
    private lateinit var engineRow: StatusRow
    private lateinit var dbgOverlay: StatusRow
    private lateinit var dbgAccess: StatusRow
    private lateinit var dbgConnected: StatusRow
    private lateinit var dbgEngine: StatusRow
    private lateinit var logView: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 6, 10)
        window.navigationBarColor = Color.rgb(5, 6, 10)

        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val holder = FrameLayout(this)
        pages = arrayOf(homePage(), featuresPage(), appsPage(), debugPage())
        for ((i, p) in pages.withIndex()) {
            holder.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))
            p.visibility = if (i == 0) View.VISIBLE else View.GONE
        }
        root.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))

        val bar = buildTabs()
        val barLp = FrameLayout.LayoutParams(MATCH, dp(66), Gravity.BOTTOM)
        barLp.setMargins(dp(16), 0, dp(16), dp(14))
        root.addView(bar, barLp)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && Prefs.on(this, Prefs.ENABLED) && IslandBus.engine == null) {
            IslandService.start(this)
        }
        handler.post(logLoop)
    }

    override fun onPause() {
        handler.removeCallbacks(logLoop)
        super.onPause()
    }

    private val logLoop = object : Runnable {
        override fun run() {
            refreshStatus()
            val lines = Diag.all().take(30)
            logView.text = if (lines.isEmpty()) "(nothing yet)" else lines.joinToString("\n")
            handler.postDelayed(this, 1500)
        }
    }

    // ------------------------------------------------------------------ small building blocks

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = s
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun glass(v: View, radius: Int, strong: Boolean = false, tint: Int = 0) {
        v.background = GlassDrawable(dp(radius).toFloat(), dp(1).toFloat(), strong, tint)
    }

    private fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(2f)).start()
            }
            false
        }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(20), dp(16), dp(20))
        return c
    }

    private fun scrollOf(col: LinearLayout): ScrollView {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        sv.setPadding(0, 0, 0, dp(100))
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun add(col: LinearLayout, v: View, topDp: Int = 0) {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(topDp)
        col.addView(v, lp)
    }

    private fun header(title: String, sub: String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(8), dp(4), dp(16))
        val t = text(title, 36f, Color.WHITE, true)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        box.addView(t)
        box.addView(text(sub, 15f, white(170)))
        return box
    }

    private fun sectionTitle(s: String): View {
        val tv = text(s, 12f, white(140), true)
        tv.letterSpacing = 0.08f
        tv.setPadding(dp(8), dp(26), dp(8), dp(8))
        return tv
    }

    private fun card(vararg rows: View): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        glass(c, 24)
        for ((i, r) in rows.withIndex()) {
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(white(26))
                val lp = LinearLayout.LayoutParams(MATCH, 1)
                lp.marginStart = dp(16)
                c.addView(line, lp)
            }
            c.addView(r)
        }
        return c
    }

    private fun badgeView(emoji: String, color: Int): View {
        val tv = text(emoji, 17f, Color.WHITE)
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(color)
        tv.background = bg
        return tv
    }

    private fun toggleRow(emoji: String, color: Int, title: String, sub: String?, key: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(16), dp(12))
        row.addView(badgeView(emoji, color), LinearLayout.LayoutParams(dp(34), dp(34)))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(text(title, 16f, Color.WHITE))
        if (sub != null) {
            val s = text(sub, 12.5f, white(140))
            s.setPadding(0, dp(2), 0, 0)
            left.addView(s)
        }
        val leftLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        leftLp.marginStart = dp(12)
        leftLp.marginEnd = dp(10)
        row.addView(left, leftLp)

        val toggle = GlassToggle(this)
        toggle.update(Prefs.on(this, key), false)
        toggle.onChange = { v ->
            Prefs.sp(this).edit().putBoolean(key, v).apply()
            if (key == Prefs.ENABLED && v) IslandService.start(this)
        }
        row.addView(toggle)
        return row
    }

    private fun sliderRow(
        title: String, key: String, lo: Int, hi: Int, def: Int, unit: String, preview: Boolean
    ): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(dp(16), dp(14), dp(16), dp(8))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(text(title, 16f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
        val cur = Prefs.int(this, key, def)
        val value = text(cur.toString() + unit, 15f, white(170))
        head.addView(value)
        row.addView(head)
        val slider = GlassSlider(this, lo, hi, cur)
        slider.onChange = { v ->
            value.text = v.toString() + unit
            Prefs.sp(this).edit().putInt(key, v).apply()
            if (preview) IslandBus.engine?.demo("notif")
        }
        row.addView(slider, LinearLayout.LayoutParams(MATCH, WRAP))
        return row
    }

    private fun statusRow(title: String, onClick: () -> Unit): StatusRow {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(18), dp(14), dp(18), dp(14))
        row.isClickable = true
        row.setOnClickListener { onClick() }
        pressable(row)
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(text(title, 16f, Color.WHITE))
        val s = text("", 13f, white(150))
        left.addView(s)
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val dot = View(this)
        val dotBg = GradientDrawable()
        dotBg.shape = GradientDrawable.OVAL
        dotBg.setColor(Pal.ORANGE)
        dot.background = dotBg
        row.addView(dot, LinearLayout.LayoutParams(dp(11), dp(11)))
        return StatusRow(row, dot, s)
    }

    private fun setRow(r: StatusRow, ok: Boolean, okText: String, noText: String) {
        r.status.text = if (ok) okText else noText
        r.status.setTextColor(if (ok) Pal.GREEN else Pal.ORANGE)
        (r.dot.background as GradientDrawable).setColor(if (ok) Pal.GREEN else Pal.ORANGE)
    }

    private fun button(label: String, color: Int, onClick: () -> Unit): View {
        val b = text(label, 16f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(15), dp(16), dp(15))
        glass(b, 18, true, color)
        b.setOnClickListener { onClick() }
        pressable(b)
        return b
    }

    private fun open(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Couldn't open that screen")
        }
    }

    private fun demo(kind: String) {
        val e = IslandBus.engine
        if (e == null) {
            toast("Island isn't running yet. Allow 'Display over other apps' first.")
            if (Settings.canDrawOverlays(this)) IslandService.start(this)
        } else {
            e.demo(kind)
        }
    }

    private fun isListenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun overlayIntent(): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))

    private fun listenerIntent(): Intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)

    private fun appInfoIntent(): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))

    // ------------------------------------------------------------------ status

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val access = isListenerEnabled()
        val connected = Diag.listenerConnected
        val engine = IslandBus.engine != null
        setRow(overlayRow, overlay, "Allowed", "Tap to allow")
        setRow(
            listenerRow, access && connected, "Connected",
            if (access) "On, waiting to connect" else "Tap to allow"
        )
        setRow(engineRow, engine, "Running", "Not running")
        setRow(dbgOverlay, overlay, "Allowed", "Not allowed")
        setRow(dbgAccess, access, "Switched on in Settings", "Switched off")
        setRow(dbgConnected, connected, "Connected", "Not connected")
        setRow(dbgEngine, engine, "Running", "Not running")
    }

    private fun report(): String {
        val sb = StringBuilder()
        sb.append("Island 1.0 report\n")
        sb.append("Phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
        sb.append(", Android ").append(Build.VERSION.RELEASE)
        sb.append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("Overlay permission: ").append(Settings.canDrawOverlays(this)).append('\n')
        sb.append("Notification access on: ").append(isListenerEnabled()).append('\n')
        sb.append("Listener connected: ").append(Diag.listenerConnected).append('\n')
        sb.append("Engine running: ").append(IslandBus.engine != null).append('\n')
        sb.append("--- log (newest first) ---\n")
        for (l in Diag.all()) sb.append(l).append('\n')
        return sb.toString()
    }

    // ------------------------------------------------------------------ pages

    private fun homePage(): ScrollView {
        val col = column()
        add(col, header("Island", "A Dynamic Island for your phone"))

        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(12), dp(18), dp(12), dp(14))
        glass(hero, 28, true)
        hero.addView(PreviewIsland(this), LinearLayout.LayoutParams(MATCH, dp(84)))
        val cap = text("Live preview", 12f, white(140))
        cap.gravity = Gravity.CENTER
        hero.addView(cap, LinearLayout.LayoutParams(MATCH, WRAP))
        add(col, hero)

        add(col, sectionTitle("STATUS"))
        overlayRow = statusRow("Display over other apps") { open(overlayIntent()) }
        listenerRow = statusRow("Notification access") { open(listenerIntent()) }
        engineRow = statusRow("Island service") {
            IslandService.start(this)
            toast("Starting...")
        }
        add(col, card(overlayRow.view, listenerRow.view, engineRow.view))

        add(col, sectionTitle("TRY IT"))
        val pairs = listOf(
            Pair(Emoji.CHAT + "  Message", "notif"), Pair(Emoji.NOTE + "  Song", "music"),
            Pair(Emoji.BOLT + "  Charging", "charge"), Pair(Emoji.FLASH + "  Flashlight", "torch"),
            Pair(Emoji.TIMER + "  Timer", "timer"), Pair(Emoji.PHONE + "  Call", "call"),
            Pair(Emoji.HEADPHONES + "  Headphones", "headset"), Pair(Emoji.VOL_HIGH + "  Volume", "volume")
        )
        var i = 0
        while (i < pairs.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in i until min2(i + 2, pairs.size)) {
                val p = pairs[j]
                val chip = text(p.first, 15f, Color.WHITE, true)
                chip.gravity = Gravity.CENTER
                chip.setPadding(dp(8), dp(16), dp(8), dp(16))
                glass(chip, 18)
                chip.setOnClickListener { demo(p.second) }
                pressable(chip)
                val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                row.addView(chip, lp)
            }
            add(col, row)
            i += 2
        }
        val hint = text(
            "Real music and notifications show up on their own. Play a song or send yourself a message to see them.",
            12.5f, white(130)
        )
        hint.setPadding(dp(8), dp(12), dp(8), 0)
        add(col, hint)
        return scrollOf(col)
    }

    private fun min2(a: Int, b: Int): Int = if (a < b) a else b

    private fun featuresPage(): ScrollView {
        val col = column()
        add(col, header("Features", "Switch things on and off"))

        add(col, sectionTitle("ISLAND"))
        add(
            col,
            card(
                toggleRow("\u2728", Pal.BLUE, "Island", "Turn the whole island on or off", Prefs.ENABLED)
            )
        )

        add(col, sectionTitle("WHAT IT SHOWS"))
        add(
            col,
            card(
                toggleRow(Emoji.CHAT, Pal.GREEN, "Notifications", "Messages, mail and app alerts", Prefs.NOTIFS),
                toggleRow(Emoji.PHONE, Pal.GREEN, "Calls and alarms", "Answer or decline from the island", Prefs.CALLS),
                toggleRow(Emoji.TIMER, Pal.ORANGE, "Timers", "Running timers stay as a small pill", Prefs.TIMERS),
                toggleRow(Emoji.NOTE, Pal.PINK, "Music", "Now playing, with controls", Prefs.MEDIA),
                toggleRow("\uD83C\uDFB6", Pal.PINK, "Song change peek", "Pops open when the song changes", Prefs.TRACKPEEK)
            )
        )

        add(col, sectionTitle("SYSTEM"))
        add(
            col,
            card(
                toggleRow(Emoji.FLASH, Pal.YELLOW, "Flashlight", "Shows while the torch is on", Prefs.TORCH),
                toggleRow(Emoji.BOLT, Pal.GREEN, "Charging", "Plug in, unplug, fully charged", Prefs.CHARGING),
                toggleRow(Emoji.BATTERY, Pal.RED, "Low battery", "Warns at 20% and 10%", Prefs.LOWBATT),
                toggleRow(Emoji.HEADPHONES, Pal.BLUE, "Headphones", "Wired and Bluetooth", Prefs.HEADSET),
                toggleRow(Emoji.BELL_OFF, Pal.RED, "Silent and vibrate", "When you change the sound mode", Prefs.RINGER),
                toggleRow(Emoji.MOON, Pal.PURPLE, "Do Not Disturb", "When it turns on or off", Prefs.DND),
                toggleRow(Emoji.PLANE, Pal.ORANGE, "Airplane mode", "When it turns on or off", Prefs.AIRPLANE),
                toggleRow(Emoji.VOL_HIGH, Pal.BLUE, "Volume", "Shows a bar when you change volume", Prefs.VOLUME)
            )
        )

        add(col, sectionTitle("LOOK AND FEEL"))
        add(
            col,
            card(
                toggleRow("\uD83D\uDD12", Pal.GRAY, "Hide message text", "Show only the app name", Prefs.HIDE_TEXT),
                toggleRow("\uD83D\uDCCA", Pal.PINK, "Equalizer bars", "Moving bars while music plays", Prefs.EQUALIZER),
                toggleRow("\uD83D\uDCA1", Pal.YELLOW, "Colored glow", "A soft colored edge on cards", Prefs.GLOW),
                toggleRow("\uD83C\uDF0A", Pal.TEAL, "Smooth motion", "Less bounce, calmer animation", Prefs.SMOOTH),
                toggleRow("\uD83D\uDCF3", Pal.ORANGE, "Haptic tick", "A tiny vibration when it opens", Prefs.HAPTICS)
            )
        )

        add(col, sectionTitle("SIZE AND POSITION"))
        add(
            col,
            card(
                sliderRow("Notification time", Prefs.SECONDS, 2, 10, Prefs.DEFAULT_SECONDS, " s", false),
                sliderRow("Distance from top", Prefs.TOP_DP, -40, 120, Prefs.DEFAULT_TOP_DP, " dp", true),
                sliderRow("Small pill width", Prefs.WIDTH_DP, 130, 230, Prefs.DEFAULT_WIDTH_DP, " dp", true)
            )
        )
        val note = text(
            "Drag Distance from top until the pill sits over your camera hole.",
            12.5f, white(130)
        )
        note.setPadding(dp(8), dp(10), dp(8), 0)
        add(col, note)
        return scrollOf(col)
    }

    private fun appsPage(): ScrollView {
        val col = column()
        add(col, header("Apps", "Choose which apps can use the island"))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        glass(list, 24)
        val loading = text("Loading apps...", 15f, white(150))
        loading.setPadding(dp(18), dp(18), dp(18), dp(18))
        list.addView(loading)
        add(col, list)
        loadApps(list)
        return scrollOf(col)
    }

    private fun loadApps(list: LinearLayout) {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_LAUNCHER)
            val items = ArrayList<Triple<String, String, Drawable>>()
            val seen = HashSet<String>()
            try {
                for (ri in pm.queryIntentActivities(intent, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || !seen.add(pkg)) continue
                    items.add(Triple(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
                }
            } catch (e: Exception) {
                Diag.add("app list failed: " + e)
            }
            items.sortBy { it.second.lowercase() }
            runOnUiThread {
                list.removeAllViews()
                val blocked = Prefs.blocked(this)
                for ((idx, item) in items.withIndex()) {
                    if (idx > 0) {
                        val line = View(this)
                        line.setBackgroundColor(white(22))
                        val llp = LinearLayout.LayoutParams(MATCH, 1)
                        llp.marginStart = dp(68)
                        list.addView(line, llp)
                    }
                    val row = LinearLayout(this)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER_VERTICAL
                    row.setPadding(dp(16), dp(10), dp(16), dp(10))
                    val icon = ImageView(this)
                    icon.setImageDrawable(item.third)
                    roundClip(icon, dp(10).toFloat())
                    row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                    val name = text(item.second, 16f, Color.WHITE)
                    name.maxLines = 1
                    val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
                    nlp.marginStart = dp(12)
                    nlp.marginEnd = dp(10)
                    row.addView(name, nlp)
                    val toggle = GlassToggle(this)
                    toggle.update(!blocked.contains(item.first), false)
                    toggle.onChange = { on -> Prefs.setBlocked(this, item.first, !on) }
                    row.addView(toggle)
                    list.addView(row)
                }
            }
        }.start()
    }

    private fun debugPage(): ScrollView {
        val col = column()
        add(col, header("Debug", "If something doesn't work, tap Copy report and send it to me"))

        dbgOverlay = statusRow("Display over other apps") { open(overlayIntent()) }
        dbgAccess = statusRow("Notification access") { open(listenerIntent()) }
        dbgConnected = statusRow("Listener connected") { open(listenerIntent()) }
        dbgEngine = statusRow("Island service") {
            IslandService.start(this)
            toast("Starting...")
        }
        add(col, card(dbgOverlay.view, dbgAccess.view, dbgConnected.view, dbgEngine.view))

        add(col, sectionTitle("FIX IT"))
        add(col, button("Open Notification access", Pal.BLUE) { open(listenerIntent()) })
        add(col, button("Open App info", Pal.PURPLE) { open(appInfoIntent()) }, 10)
        add(col, button("Restart island", Pal.ORANGE) {
            stopService(Intent(this, IslandService::class.java))
            handler.postDelayed({ IslandService.start(this) }, 600)
            toast("Restarting...")
        }, 10)
        add(col, button("Copy report", Pal.GREEN) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Island report", report()))
            toast("Copied. Paste it in the chat.")
        }, 10)

        add(col, sectionTitle("NOTIFICATION ACCESS GREYED OUT?"))
        val help = text(
            "Android blocks it for apps installed outside the Play Store.\n\n" +
                "1. Tap Open App info.\n" +
                "2. Tap the three dots at the top right.\n" +
                "3. Tap Allow restricted settings and confirm.\n" +
                "4. Go back and switch on Notification access for Island.\n" +
                "5. In App info, open Battery and choose Unrestricted.\n\n" +
                "If the three dots menu is missing, first try to switch on Notification access once, then look again.",
            13.5f, white(190)
        )
        help.setPadding(dp(18), dp(16), dp(18), dp(16))
        val helpCard = LinearLayout(this)
        helpCard.orientation = LinearLayout.VERTICAL
        glass(helpCard, 24)
        helpCard.addView(help)
        add(col, helpCard)

        add(col, sectionTitle("LOG"))
        logView = text("(nothing yet)", 11.5f, white(190))
        logView.typeface = Typeface.MONOSPACE
        logView.setPadding(dp(16), dp(14), dp(16), dp(14))
        val logCard = LinearLayout(this)
        logCard.orientation = LinearLayout.VERTICAL
        glass(logCard, 24)
        logCard.addView(logView)
        add(col, logCard)
        return scrollOf(col)
    }

    // ------------------------------------------------------------------ tab bar

    private fun buildTabs(): View {
        val wrap = FrameLayout(this)
        glass(wrap, 33, true)

        indicator = View(this)
        indicator.background = GlassDrawable(dp(26).toFloat(), dp(1).toFloat(), true, Pal.BLUE)
        val indLp = FrameLayout.LayoutParams(dp(60), dp(54), Gravity.START or Gravity.CENTER_VERTICAL)
        indLp.marginStart = dp(6)
        wrap.addView(indicator, indLp)

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(dp(6), 0, dp(6), 0)
        val items = listOf(
            Pair(Emoji.HOME, "Home"), Pair(Emoji.SLIDERS, "Features"),
            Pair(Emoji.APPS, "Apps"), Pair(Emoji.BUG, "Debug")
        )
        for ((i, p) in items.withIndex()) {
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER
            val e = text(p.first, 19f, Color.WHITE)
            e.gravity = Gravity.CENTER
            val l = text(p.second, 10.5f, white(210), true)
            l.gravity = Gravity.CENTER
            t.addView(e)
            t.addView(l)
            t.setOnClickListener { selectTab(i) }
            pressable(t)
            tabs.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        wrap.addView(tabs, FrameLayout.LayoutParams(MATCH, MATCH))

        wrap.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = (r - l - dp(12)) / 4
            val lp = indicator.layoutParams as FrameLayout.LayoutParams
            if (lp.width != w) {
                lp.width = w
                indicator.layoutParams = lp
            }
            indicator.translationX = current * w.toFloat()
        }
        return wrap
    }

    private fun selectTab(i: Int) {
        if (i == current) return
        val fromIndex = current
        val from = pages[fromIndex]
        val to = pages[i]
        val dir = if (i > fromIndex) 1 else -1
        val shift = dp(44).toFloat() * dir

        to.animate().cancel()
        to.visibility = View.VISIBLE
        to.alpha = 0f
        to.translationX = shift
        to.animate().alpha(1f).translationX(0f).setDuration(320)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()

        from.animate().cancel()
        from.animate().alpha(0f).translationX(-shift).setDuration(220).withEndAction {
            if (current != fromIndex) from.visibility = View.GONE
        }.start()

        current = i
        val w = indicator.layoutParams.width.toFloat()
        indicator.animate().translationX(i * w).setDuration(420)
            .setInterpolator(OvershootInterpolator(1.15f)).start()
    }
}
