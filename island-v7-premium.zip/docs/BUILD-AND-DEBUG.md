# Build and troubleshooting

## GitHub ZIP build

The repository workflow expects a root-level archive named `island-*.zip`. It extracts that archive, locates the Gradle project, installs JDK 17 / Android SDK 34 / Gradle 8.9, builds `assembleDebug`, verifies the APK, and uploads `app-debug.apk` as the `Island-V7-debug-APK` artifact.

If no run starts after uploading, check that:

- the archive filename begins with `island-` and ends with `.zip`;
- it was committed to `main` or `master`;
- the repository workflow exists at `.github/workflows/build.yml` on the default branch;
- GitHub Actions are enabled for the repository.

If the run fails, open the build job and inspect the **first Gradle or Kotlin error**. The final `BUILD FAILED` line is only a summary. Keep the full log when asking for help.

## Manual workflow run

From **Actions → Island APK Builder → Run workflow**, set the archive field to the repository-relative path of the ZIP. The default is `island-v7-premium.zip`.

## Local build

Use JDK 17, Android SDK Platform 34, Android Build Tools 34.0.0 and Gradle 8.9. Run:

```bash
gradle --no-daemon --stacktrace clean assembleDebug
```

## Device troubleshooting

The app requires both Display over other apps and Notification access. Samsung battery restrictions can affect background reliability. If the app's overlay is not visible, verify both permissions first, then restart the notification-listener service from Android Settings.
