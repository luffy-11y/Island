# Feature map

## App and settings screen

`MainActivity.kt` builds the setup dashboard, live preview, permission status, camera-cutout calibration controls, module switches, appearance controls, gesture choices and app blocklist UI.

## Overlay and event handling

`IslandListenerService.kt` owns the notification listener and floating window. It selects the active presentation mode, queues notification items, attaches media-session callbacks, handles supported call actions and listens for selected system status changes. The service is bound to the Android notification-listener permission and separately checks overlay permission before displaying the window.

## Drawing and interaction

`Views.kt` contains custom-drawn UI components: the pill container, equalizer, battery ring, media progress line, transport icons, toggles, sliders and segmented controls. Spring animations are used for overlay and preview transitions.

## Preferences

`Prefs.kt` stores feature switches, visual preferences, positioning values, gesture behavior and the per-app blocklist using Android `SharedPreferences`.

## Functional boundaries

The UI can only act on information and `PendingIntent` actions provided by Android or the source app. A missing media session, chronometer or call action is an upstream limitation, not something an overlay can reliably manufacture.
