# Permissions and privacy

Island requests Android permissions for specific operating-system capabilities:

- **Display over other apps:** required to draw the floating island above other apps.
- **Notification access:** allows the notification-listener service to observe notifications, their visible content and actions supplied by the originating app.
- **Vibration:** supports optional haptic feedback.
- **Bluetooth permissions:** support Bluetooth/headset status on Android versions that require runtime Bluetooth access.
- **Package visibility:** supports listing installed apps for the app blocklist UI.

Notification access and overlay access are special permissions controlled by Android Settings. Island cannot grant them to itself or bypass user consent. Avoid sharing logs or screenshots containing private notification content. You can revoke these permissions at any time from Android Settings.
