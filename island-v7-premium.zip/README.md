# Island V7 — Premium Android Dynamic Island

Island is a Kotlin Android app that presents a Dynamic Island-style floating overlay using Android's notification-listener, media-session and overlay APIs.

## What changed in V7

- Rebuilt the app's control centre with a premium dark dashboard, clearer hierarchy, compact status cards and consistent controls.
- Added a live hero preview and one-tap notification/music preview triggers.
- Reorganized permission setup, live modules, cutout calibration, appearance, gestures and privacy controls.
- Kept the existing notification/media/timer/call/system overlay engine and preferences so the redesign remains connected to real Android events rather than being a static mockup.
- Added a Galaxy A52s calibration preset and retained manual position/scale controls.
- Advanced app version to 7.0 (version code 7).

## Android project

| Item | Value |
|---|---|
| Application ID | `com.example.island` |
| Minimum Android | Android 8.0 / API 26 |
| Compile / target SDK | API 34 / API 34 |
| Android Gradle Plugin | 8.5.2 |
| Gradle | 8.9 |
| Kotlin plugin | 1.9.24 |
| Java | 17 |
| Version | 7.0-A52s / code 7 |

## Build using GitHub Actions

This archive includes `.github/workflows/build.yml`, but GitHub does not activate workflow files nested inside an uploaded ZIP. First copy that file into your repository at `.github/workflows/build.yml` and commit it. Then upload this archive itself to the repository root as `island-v7-premium.zip` and commit. The workflow extracts the archive, compiles the debug APK, verifies the output and uploads an artifact named `Island-V7-debug-APK`.

To build manually, open **Actions → Island APK Builder → Run workflow** and provide `island-v7-premium.zip` as the archive path.

## Local build

Open this folder in Android Studio with JDK 17 and Android SDK Platform 34 installed. Run:

```bash
gradle --no-daemon --stacktrace clean assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important platform limitations

The app can only display information and invoke actions exposed by Android and the originating app. Media controls require an active MediaSession; timers require notification chronometer metadata; call actions require exposed call-notification PendingIntents. Overlay permission and notification access must be granted by the user. Behavior can vary by Android version, One UI release and individual apps.

## Testing status

The archive structure and ZIP integrity are checked before delivery. This environment does not contain the Android SDK/Gradle build environment, so this package has **not** been compiled or tested on a physical Galaxy A52s here. GitHub Actions performs the first actual APK build.
