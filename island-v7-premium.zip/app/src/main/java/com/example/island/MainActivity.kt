package com.example.island

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** A deliberately redesigned control centre. Runtime overlay logic remains in IslandListenerService. */
class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 16)
    private val panel = Color.rgb(19, 22, 32)
    private val panel2 = Color.rgb(25, 29, 42)
    private val muted = Color.rgb(151, 158, 177)
    private val accent = Color.rgb(126, 111, 255)
    private lateinit var root: LinearLayout
    private var statusOverlay: TextView? = null
    private var statusListener: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(34)) }
        scroll.addView(root)
        setContentView(scroll)
        buildDashboard()
    }

    override fun onResume() { super.onResume(); refreshStatuses() }

    private fun buildDashboard() {
        root.removeAllViews()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = column(0)
        heading.addView(label("ISLAND", 12, accent, true))
        heading.addView(label("Your phone, in a glance.", 25, Color.WHITE, true))
        heading.addView(label("A smarter live display for Android", 13, muted, false))
        top.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val version = label("V7", 12, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = pillBg(accent, 30); setPadding(dp(14), dp(8), dp(14), dp(8)) }
        top.addView(version)
        root.addView(top, margin(bottom = 20))

        root.addView(buildHero(), margin(bottom = 18))
        root.addView(section("GET STARTED", "Two permissions power the live island"))
        root.addView(permissionCard(), margin(bottom = 18))
        root.addView(section("LIVE MODULES", "Choose what can appear in the island"))
        root.addView(moduleCard(), margin(bottom = 18))
        root.addView(section("PERSONALISE", "Tune the island to your display"))
        root.addView(positionCard(), margin(bottom = 18))
        root.addView(appearanceCard(), margin(bottom = 18))
        root.addView(gestureCard(), margin(bottom = 18))
        root.addView(section("PRIVACY & CONTROL", "You stay in charge"))
        root.addView(privacyCard(), margin(bottom = 18))
        root.addView(label("Island uses Android notification access and display-over-other-apps permission to show live information. Some features depend on what each app exposes to Android.", 12, muted, false).apply { setPadding(dp(4), dp(8), dp(4), dp(10)) })
    }

    private fun buildHero(): View {
        val card = card(true)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = column(0)
        left.addView(label("LIVE DISPLAY", 11, Color.rgb(185,178,255), true))
        left.addView(label("A little more\nlife at the top.", 24, Color.WHITE, true))
        left.addView(label("Notifications · Music · System alerts", 12, muted, false))
        row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val pill = FrameLayout(this).apply { background = pillBg(Color.BLACK, 30); elevation = dp(8).toFloat() }
        val pRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(13), 0, dp(13), 0) }
        val dot = View(this).apply { background = pillBg(accent, 20); layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)) }
        pRow.addView(dot)
        pRow.addView(label("  ISLAND  ", 11, Color.WHITE, true))
        val bars = EqualizerView(this, 4).apply { barColor = 0xFF30D158.toInt(); isPlaying = true; layoutParams = LinearLayout.LayoutParams(dp(22), dp(16)) }
        pRow.addView(bars)
        pill.addView(pRow, FrameLayout.LayoutParams(-1, dp(46), Gravity.CENTER))
        row.addView(pill, LinearLayout.LayoutParams(dp(136), dp(58)))
        card.addView(row)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val enable = switchRow("Enable Island", "Master switch for the overlay", Prefs.isEnabled(this), accent) { Prefs.setEnabled(this, it); notifyService() }
        card.addView(space(14))
        card.addView(enable)
        card.addView(space(12))
        val preview = actionButton("TRY A PREVIEW", accent) { sendPreviewBroadcast("notif") }
        actions.addView(preview, LinearLayout.LayoutParams(0, dp(44), 1f))
        val music = actionButton("MUSIC DEMO", Color.rgb(43, 48, 67)) { sendPreviewBroadcast("music") }
        actions.addView(music, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(9) })
        card.addView(actions)
        return card
    }

    private fun permissionCard(): View {
        val c = card()
        c.addView(permissionRow("Display over other apps", "Allows the island to float above apps", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        c.addView(separator())
        c.addView(permissionRow("Notification access", "Reads notification content and media controls", { isListenerEnabled() }) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        c.addView(separator())
        c.addView(permissionRow("Battery optimisation", "Allow reliable background updates", { true }) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { openAppDetails() }
        })
        return c
    }

    private fun moduleCard(): View {
        val c = card()
        val items = listOf(
            Triple("Notifications", "Incoming alerts and app messages", Prefs.isNotifs(this)) to { v: Boolean -> Prefs.setNotifs(this, v) },
            Triple("Media player", "Track, artwork and playback state", Prefs.isMedia(this)) to { v: Boolean -> Prefs.setMedia(this, v) },
            Triple("Calls", "Incoming call notification controls", Prefs.isCalls(this)) to { v: Boolean -> Prefs.setCalls(this, v) },
            Triple("Timers & stopwatch", "Chronometer notifications", Prefs.isTimers(this)) to { v: Boolean -> Prefs.setTimers(this, v) },
            Triple("Battery & charging", "Charging and battery status", Prefs.isBattery(this)) to { v: Boolean -> Prefs.setBattery(this, v) },
            Triple("Bluetooth", "Connection state changes", Prefs.isBluetooth(this)) to { v: Boolean -> Prefs.setBluetooth(this, v) },
            Triple("Ringer mode", "Silent, vibrate and sound changes", Prefs.isRinger(this)) to { v: Boolean -> Prefs.setRinger(this, v) }
        )
        items.forEachIndexed { i, item ->
            c.addView(switchRow(item.first.first, item.first.second, item.first.third, accent, item.second))
            if (i != items.lastIndex) c.addView(separator())
        }
        return c
    }

    private fun positionCard(): View {
        val c = card()
        c.addView(switchRow("Auto align to camera cutout", "Recommended for Galaxy A52s", Prefs.isAutoCutout(this), accent) { Prefs.setAutoCutout(this, it); notifyService() })
        c.addView(separator())
        slider(c, "Vertical position", -45, 120, Prefs.getTopDp(this), "${Prefs.getTopDp(this)} dp") { Prefs.setTopDp(this, it); notifyService() }
        slider(c, "Horizontal offset", -60, 60, Prefs.getOffsetXDp(this), "${Prefs.getOffsetXDp(this)} dp") { Prefs.setOffsetXDp(this, it); notifyService() }
        slider(c, "Island size", 80, 130, Prefs.getScalePct(this), "${Prefs.getScalePct(this)}%") { Prefs.setScalePct(this, it); notifyService() }
        val reset = actionButton("APPLY GALAXY A52s PRESET", Color.rgb(43,48,67)) { Prefs.applyA52sPreset(this); notifyService(); buildDashboard() }
        c.addView(reset, margin(top = 10))
        return c
    }

    private fun appearanceCard(): View {
        val c = card()
        c.addView(switchRow("Subtle edge glow", "A restrained highlight around the pill", Prefs.isGlowBorder(this), accent) { Prefs.setGlowBorder(this, it); notifyService() })
        c.addView(separator())
        c.addView(switchRow("Animated equalizer", "Show motion while audio is playing", Prefs.isEqualizer(this), accent) { Prefs.setEqualizer(this, it); notifyService() })
        c.addView(separator())
        c.addView(switchRow("Haptic feedback", "Small tactile response to interactions", Prefs.isHaptics(this), accent) { Prefs.setHaptics(this, it); notifyService() })
        c.addView(separator())
        c.addView(switchRow("Always-on idle pill", "Keep a compact pill visible when idle", Prefs.isIdlePill(this), accent) { Prefs.setIdlePill(this, it); notifyService() })
        c.addView(separator())
        c.addView(label("ACCENT STYLE", 10, muted, true).apply { setPadding(0, dp(14), 0, dp(8)) })
        val names = arrayOf("Adaptive", "Indigo", "Green", "Coral", "Cyan", "White")
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names); setSelection(Prefs.getAccentMode(this@MainActivity)); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}; override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { Prefs.setAccentMode(this@MainActivity, pos); notifyService() } } }
        c.addView(spinner)
        return c
    }

    private fun gestureCard(): View {
        val c = card()
        c.addView(choiceRow("Tap action", arrayOf("Expand / collapse", "Open app"), Prefs.getTapAction(this)) { Prefs.setTapAction(this, it); notifyService() })
        c.addView(separator())
        c.addView(choiceRow("Long-press action", arrayOf("Open app", "Expand / collapse", "Dismiss"), Prefs.getLongPressAction(this)) { Prefs.setLongPressAction(this, it); notifyService() })
        return c
    }

    private fun privacyCard(): View {
        val c = card()
        c.addView(switchRow("Hide notification text", "Keep message previews out of the island", Prefs.isHideText(this), accent) { Prefs.setHideText(this, it); notifyService() })
        c.addView(separator())
        c.addView(switchRow("Hide in landscape", "Avoid covering content in wide layouts", Prefs.isHideLandscape(this), accent) { Prefs.setHideLandscape(this, it); notifyService() })
        c.addView(separator())
        c.addView(switchRow("Quick replies", "Show supported notification actions", Prefs.isQuickReplies(this), accent) { Prefs.setQuickReplies(this, it); notifyService() })
        c.addView(separator())
        val block = actionButton("MANAGE BLOCKED APPS", Color.rgb(43,48,67)) { showBlocklist() }
        c.addView(block, margin(top = 10))
        return c
    }

    private fun showBlocklist() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        val checked = BooleanArray(apps.size) { Prefs.isAppBlocked(this, apps[it].packageName) }
        AlertDialog.Builder(this).setTitle("Blocked apps").setMultiChoiceItems(names, checked) { _, which, isChecked -> Prefs.toggleAppBlocked(this, apps[which].packageName); notifyService() }.setPositiveButton("Done", null).show()
    }

    private fun slider(parent: LinearLayout, title: String, min: Int, max: Int, value: Int, suffix: String, save: (Int) -> Unit) {
        val box = column(0)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(title, 14, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val valueLabel = label(suffix, 12, accent, true)
        row.addView(valueLabel)
        box.addView(row)
        val seek = SeekBar(this).apply { this.max = max - min; progress = value - min; progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { val v = p + min; valueLabel.text = if (title == "Island size") "$v%" else "$v dp"; if (user) save(v) }; override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} })
        box.addView(seek)
        parent.addView(box, margin(top = 12, bottom = 8))
    }

    private fun choiceRow(title: String, choices: Array<String>, selected: Int, save: (Int) -> Unit): View {
        val box = column(0); box.addView(label(title, 14, Color.WHITE, true))
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, choices); setSelection(selected); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}; override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { save(pos) } } }
        box.addView(spinner); return box
    }

    private fun permissionRow(title: String, subtitle: String, granted: () -> Boolean, action: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)); isClickable = true; setOnClickListener { action() } }
        val text = column(0); text.addView(label(title, 14, Color.WHITE, true)); text.addView(label(subtitle, 11, muted, false))
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        val badge = label(if (granted()) "READY" else "SET UP", 10, if (granted()) Color.rgb(75,220,145) else Color.rgb(255,190,90), true).apply { background = pillBg(if (granted()) 0x223FD18A else 0x22FFBE5A, 30); setPadding(dp(10), dp(7), dp(10), dp(7)) }
        row.addView(badge); return row
    }

    private fun switchRow(title: String, subtitle: String, checked: Boolean, tint: Int, changed: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, dp(9)) }
        val texts = column(0); texts.addView(label(title, 14, Color.WHITE, true)); texts.addView(label(subtitle, 11, muted, false))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { isChecked = checked; thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE); trackTintList = android.content.res.ColorStateList.valueOf(tint); setOnCheckedChangeListener { _, v -> changed(v) } }
        row.addView(sw); return row
    }

    private fun section(title: String, subtitle: String): View { val c = column(3); c.addView(label(title, 10, accent, true)); c.addView(label(subtitle, 17, Color.WHITE, true)); return c.apply { setPadding(dp(3), dp(4), dp(3), dp(10)) } }
    private fun card(hero: Boolean = false) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(16)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, if (hero) intArrayOf(0xFF292748.toInt(), 0xFF171A28.toInt()) else intArrayOf(panel2, panel)).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), if (hero) 0x665F56B8 else 0x223B435A) }; elevation = dp(2).toFloat() }
    private fun column(gap: Int) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; setTextColor(color); textSize = size.toFloat(); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD); includeFontPadding = false }
    private fun actionButton(text: String, color: Int, action: () -> Unit) = TextView(this).apply { this.text = text; gravity = Gravity.CENTER; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); background = pillBg(color, 13); isClickable = true; setOnClickListener { action() } }
    private fun pillBg(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun separator() = View(this).apply { setBackgroundColor(0x223D4558); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun margin(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun isListenerEnabled(): Boolean { val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false; return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName } }
    private fun refreshStatuses() { statusOverlay?.text = if (Settings.canDrawOverlays(this)) "READY" else "SET UP"; statusListener?.text = if (isListenerEnabled()) "READY" else "SET UP" }
    private fun notifyService() { sendBroadcast(Intent(Prefs.ACTION_PREFS_CHANGED).setPackage(packageName)) }
    private fun sendPreviewBroadcast(kind: String) { sendBroadcast(Intent(Prefs.ACTION_PREVIEW).setPackage(packageName).putExtra(Prefs.EXTRA_PREVIEW_TYPE, kind)); Toast.makeText(this, "Preview requested", Toast.LENGTH_SHORT).show() }
    private fun openAppDetails() { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
}
