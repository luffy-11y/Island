package com.example.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

fun Context.dp(v: Float): Int =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

fun Context.dpF(v: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            val w = view.width
            val h = view.height
            if (w > 0 && h > 0) {
                outline.setRoundRect(0, 0, w, h, radiusPx)
            }
        }
    }
    clipToOutline = true
}

fun roundedBg(fillColor: Int, radiusPx: Float, strokeWidthPx: Int = 0, strokeColor: Int = 0): GradientDrawable {
    return GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx
        setColor(fillColor)
        if (strokeWidthPx > 0) {
            setStroke(strokeWidthPx, strokeColor)
        }
    }
}

fun extractDominantColor(bmp: Bitmap?, fallback: Int = 0xFF5E5CE6.toInt()): Int {
    if (bmp == null || bmp.isRecycled) return fallback
    return try {
        val scaled = Bitmap.createScaledBitmap(bmp, 16, 16, false)
        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        var count = 0L
        for (x in 0 until scaled.width) {
            for (y in 0 until scaled.height) {
                val c = scaled.getPixel(x, y)
                val a = Color.alpha(c)
                if (a < 128) continue
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                // Prefer colorful, non-black, non-white pixels
                val weight = if (maxCh - minCh > 28 && maxCh in 45..245) 4 else 1
                rSum += r * weight
                gSum += g * weight
                bSum += b * weight
                count += weight
            }
        }
        if (count == 0L) return fallback
        val hsv = FloatArray(3)
        Color.RGBToHSV((rSum / count).toInt(), (gSum / count).toInt(), (bSum / count).toInt(), hsv)
        hsv[1] = hsv[1].coerceIn(0.55f, 0.92f)
        hsv[2] = hsv[2].coerceIn(0.78f, 1.0f)
        Color.HSVToColor(hsv)
    } catch (_: Throwable) {
        fallback
    }
}

/**
 * Custom root container for the Dynamic Island pill that draws a pitch-black rounded pill
 * plus an optional subtle glowing edge border and smooth corner radius transitions.
 */
class IslandContainerView(context: Context) : FrameLayout(context) {
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.BLACK
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(1.3f)
        color = 0x555E5CE6
    }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val rect = RectF()
    var cornerRadiusPx: Float = context.dpF(24f)
        set(value) {
            field = value
            roundClip(value)
            invalidate()
        }
    var showGlowBorder: Boolean = true
        set(value) {
            field = value
            invalidate()
        }
    var glowColor: Int = 0xFF5E5CE6.toInt()
        set(value) {
            field = value
            invalidate()
        }
    var pillAlphaPct: Int = 100
        set(value) {
            field = value.coerceIn(75, 100)
            bgPaint.alpha = (field * 255) / 100
            invalidate()
        }

    init {
        setWillNotDraw(false)
        roundClip(cornerRadiusPx)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        roundClip(cornerRadiusPx)
    }

    override fun dispatchDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = min(cornerRadiusPx, min(w, h) / 2f)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, bgPaint)

        // A restrained specular highlight makes expanded surfaces feel
        // glass-finished without washing out the AMOLED-black island.
        glossPaint.shader = LinearGradient(
            0f, 0f, 0f, h * 0.72f,
            intArrayOf(0x20FFFFFF, 0x08FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.42f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, r, r, glossPaint)
        super.dispatchDraw(canvas)
        if (showGlowBorder) {
            val inset = borderPaint.strokeWidth / 2f
            rect.set(inset, inset, w - inset, h - inset)
            val alphaColor = (glowColor and 0x00FFFFFF) or (0x66 shl 24)
            val subtleColor = 0x26FFFFFF
            borderPaint.shader = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(alphaColor, subtleColor, alphaColor),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rect, r - inset, r - inset, borderPaint)
        }
    }
}

/**
 * Multi-bar animated music equalizer with smooth sinusoidal wave motion.
 */
class EqualizerView(context: Context, private val barCount: Int = 4) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF30D158.toInt()
    }
    private val barRect = RectF()
    private var phase = 0f
    var isPlaying: Boolean = true
        set(value) {
            if (field != value) {
                field = value
                updateAnim()
                invalidate()
            }
        }
    var barColor: Int = 0xFF30D158.toInt()
        set(value) {
            field = value
            paint.color = value
            invalidate()
        }

    private val animator = ValueAnimator.ofFloat(0f, (Math.PI * 2.0).toFloat()).apply {
        duration = 950L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    private fun updateAnim() {
        if (isAttachedToWindow && isPlaying && visibility == VISIBLE) {
            if (!animator.isStarted) animator.start()
        } else {
            animator.cancel()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnim()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun setVisibility(visibility: Int) {
        super.setVisibility(visibility)
        updateAnim()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val gap = context.dpF(2.5f)
        val totalGap = gap * (barCount - 1)
        val barW = ((w - totalGap) / barCount).coerceAtLeast(context.dpF(2f))
        val radius = barW / 2f

        for (i in 0 until barCount) {
            val ratio = if (isPlaying) {
                val freq = 1.0f + i * 0.42f
                val wave = (sin((phase * freq + i * 1.15f).toDouble()).toFloat() + 1f) * 0.5f
                0.24f + wave * 0.72f
            } else {
                0.22f
            }
            val barH = (h * ratio).coerceAtLeast(barW)
            val left = i * (barW + gap)
            val top = (h - barH) / 2f
            barRect.set(left, top, left + barW, top + barH)
            canvas.drawRoundRect(barRect, radius, radius, paint)
        }
    }
}

/**
 * Circular or pill-shaped battery/timer ring indicator.
 */
class BatteryRingView(context: Context) : View(context) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(3f)
        color = 0x33FFFFFF
        strokeCap = Paint.Cap.ROUND
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(3f)
        color = 0xFF30D158.toInt()
        strokeCap = Paint.Cap.ROUND
    }
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF30D158.toInt()
    }
    private val arcRect = RectF()
    private val boltPath = Path()

    var levelPct: Int = 85
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }
    var isCharging: Boolean = true
        set(value) {
            field = value
            invalidate()
        }
    var ringColor: Int = 0xFF30D158.toInt()
        set(value) {
            field = value
            progressPaint.color = value
            boltPaint.color = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val pad = trackPaint.strokeWidth * 0.85f
        val size = min(w, h) - pad * 2f
        val cx = w / 2f
        val cy = h / 2f
        arcRect.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f)

        canvas.drawOval(arcRect, trackPaint)
        val sweep = (levelPct / 100f) * 360f
        canvas.drawArc(arcRect, -90f, sweep, false, progressPaint)

        if (isCharging) {
            val r = size * 0.28f
            boltPath.reset()
            boltPath.moveTo(cx + r * 0.15f, cy - r)
            boltPath.lineTo(cx - r * 0.65f, cy + r * 0.1f)
            boltPath.lineTo(cx - r * 0.05f, cy + r * 0.1f)
            boltPath.lineTo(cx - r * 0.15f, cy + r)
            boltPath.lineTo(cx + r * 0.65f, cy - r * 0.1f)
            boltPath.lineTo(cx + r * 0.05f, cy - r * 0.1f)
            boltPath.close()
            canvas.drawPath(boltPath, boltPaint)
        }
    }
}

/**
 * Interactive draggable media seek bar with smooth progress line and thumb.
 */
class ProgressLine(context: Context) : View(context) {
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x38FFFFFF
    }
    private val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val rect = RectF()
    private var progressValue: Float = 0f
    var progress: Float
        get() = progressValue
        set(value) {
            if (!isDragging) {
                progressValue = value.coerceIn(0f, 1f)
                invalidate()
            }
        }
    var activeColor: Int = Color.WHITE
        set(value) {
            field = value
            fgPaint.color = value
            invalidate()
        }
    var onSeek: ((Float) -> Unit)? = null
    private var isDragging = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (onSeek == null || width <= 0) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                isDragging = true
                updateFromTouch(event.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                updateFromTouch(event.x)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                updateFromTouch(event.x)
                isDragging = false
                onSeek?.invoke(progress)
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun updateFromTouch(x: Float) {
        val pad = context.dpF(6f)
        val usable = (width - pad * 2f).coerceAtLeast(1f)
        val ratio = ((x - pad) / usable).coerceIn(0f, 1f)
        // Keep drag updates in our own backing value. Reflection is unnecessary
        // here and fails on some runtimes because Kotlin properties are accessors.
        progressValue = ratio
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val barH = if (isDragging) context.dpF(6f) else context.dpF(4.5f)
        val cy = h / 2f
        val pad = context.dpF(6f)
        val trackW = (w - pad * 2f).coerceAtLeast(1f)
        val r = barH / 2f

        rect.set(pad, cy - r, pad + trackW, cy + r)
        canvas.drawRoundRect(rect, r, r, bgPaint)

        val fillW = trackW * progress.coerceIn(0f, 1f)
        if (fillW > 0f) {
            rect.set(pad, cy - r, pad + fillW, cy + r)
            canvas.drawRoundRect(rect, r, r, fgPaint)
        }

        val thumbRadius = if (isDragging) context.dpF(6.5f) else context.dpF(4.5f)
        canvas.drawCircle(pad + fillW, cy, thumbRadius, fgPaint)
    }
}

/**
 * Hand-drawn vector icon view for media, call, timer, bluetooth, and ringer controls.
 */
class ControlIconView(context: Context, var kind: Int = KIND_PLAY) : View(context) {
    companion object {
        const val KIND_PREV = 0
        const val KIND_PLAY = 1
        const val KIND_PAUSE = 2
        const val KIND_NEXT = 3
        const val KIND_PHONE_ACCEPT = 4
        const val KIND_PHONE_DECLINE = 5
        const val KIND_TIMER = 6
        const val KIND_BT = 7
        const val KIND_RINGER_NORMAL = 8
        const val KIND_RINGER_VIBRATE = 9
        const val KIND_RINGER_SILENT = 10
        const val KIND_CLOSE = 11
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dpF(2.2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val path = Path()
    private val rect = RectF()

    var iconColor: Int = Color.WHITE
        set(value) {
            field = value
            fillPaint.color = value
            strokePaint.color = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val s = min(w, h) * 0.36f

        when (kind) {
            KIND_PLAY -> {
                path.reset()
                path.moveTo(cx - s * 0.55f, cy - s * 0.85f)
                path.lineTo(cx + s * 0.85f, cy)
                path.lineTo(cx - s * 0.55f, cy + s * 0.85f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_PAUSE -> {
                val bw = s * 0.42f
                val bh = s * 1.55f
                val gap = s * 0.32f
                rect.set(cx - gap - bw, cy - bh / 2f, cx - gap, cy + bh / 2f)
                canvas.drawRoundRect(rect, bw / 3f, bw / 3f, fillPaint)
                rect.set(cx + gap, cy - bh / 2f, cx + gap + bw, cy + bh / 2f)
                canvas.drawRoundRect(rect, bw / 3f, bw / 3f, fillPaint)
            }
            KIND_PREV -> {
                val barW = s * 0.25f
                rect.set(cx - s * 0.85f, cy - s * 0.75f, cx - s * 0.85f + barW, cy + s * 0.75f)
                canvas.drawRoundRect(rect, barW / 2f, barW / 2f, fillPaint)
                path.reset()
                path.moveTo(cx + s * 0.75f, cy - s * 0.75f)
                path.lineTo(cx - s * 0.5f, cy)
                path.lineTo(cx + s * 0.75f, cy + s * 0.75f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_NEXT -> {
                val barW = s * 0.25f
                rect.set(cx + s * 0.85f - barW, cy - s * 0.75f, cx + s * 0.85f, cy + s * 0.75f)
                canvas.drawRoundRect(rect, barW / 2f, barW / 2f, fillPaint)
                path.reset()
                path.moveTo(cx - s * 0.75f, cy - s * 0.75f)
                path.lineTo(cx + s * 0.5f, cy)
                path.lineTo(cx - s * 0.75f, cy + s * 0.75f)
                path.close()
                canvas.drawPath(path, fillPaint)
            }
            KIND_PHONE_ACCEPT -> {
                strokePaint.strokeWidth = context.dpF(2.5f)
                rect.set(cx - s * 0.8f, cy - s * 0.8f, cx + s * 0.8f, cy + s * 0.8f)
                canvas.drawArc(rect, 130f, 110f, false, strokePaint)
                canvas.drawCircle(cx - s * 0.55f, cy + s * 0.45f, s * 0.24f, fillPaint)
                canvas.drawCircle(cx + s * 0.45f, cy - s * 0.55f, s * 0.24f, fillPaint)
            }
            KIND_PHONE_DECLINE -> {
                strokePaint.strokeWidth = context.dpF(2.5f)
                rect.set(cx - s * 0.85f, cy - s * 0.45f, cx + s * 0.85f, cy + s * 0.75f)
                canvas.drawArc(rect, 200f, 140f, false, strokePaint)
                canvas.drawCircle(cx - s * 0.68f, cy + s * 0.05f, s * 0.22f, fillPaint)
                canvas.drawCircle(cx + s * 0.68f, cy + s * 0.05f, s * 0.22f, fillPaint)
            }
            KIND_TIMER -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                canvas.drawCircle(cx, cy + s * 0.1f, s * 0.82f, strokePaint)
                canvas.drawLine(cx - s * 0.3f, cy - s * 0.92f, cx + s * 0.3f, cy - s * 0.92f, strokePaint)
                canvas.drawLine(cx, cy + s * 0.1f, cx, cy - s * 0.38f, strokePaint)
                canvas.drawLine(cx, cy + s * 0.1f, cx + s * 0.4f, cy + s * 0.25f, strokePaint)
            }
            KIND_BT -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                path.reset()
                path.moveTo(cx - s * 0.45f, cy - s * 0.45f)
                path.lineTo(cx + s * 0.45f, cy + s * 0.45f)
                path.lineTo(cx, cy + s * 0.9f)
                path.lineTo(cx, cy - s * 0.9f)
                path.lineTo(cx + s * 0.45f, cy - s * 0.45f)
                path.lineTo(cx - s * 0.45f, cy + s * 0.45f)
                canvas.drawPath(path, strokePaint)
            }
            KIND_RINGER_NORMAL -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                path.reset()
                path.moveTo(cx, cy - s * 0.85f)
                path.quadTo(cx + s * 0.68f, cy - s * 0.6f, cx + s * 0.72f, cy + s * 0.4f)
                path.lineTo(cx - s * 0.72f, cy + s * 0.4f)
                path.quadTo(cx - s * 0.68f, cy - s * 0.6f, cx, cy - s * 0.85f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawCircle(cx, cy + s * 0.72f, s * 0.2f, fillPaint)
            }
            KIND_RINGER_VIBRATE -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                rect.set(cx - s * 0.4f, cy - s * 0.65f, cx + s * 0.4f, cy + s * 0.65f)
                canvas.drawRoundRect(rect, s * 0.15f, s * 0.15f, strokePaint)
                canvas.drawLine(cx - s * 0.78f, cy - s * 0.4f, cx - s * 0.78f, cy + s * 0.4f, strokePaint)
                canvas.drawLine(cx + s * 0.78f, cy - s * 0.4f, cx + s * 0.78f, cy + s * 0.4f, strokePaint)
            }
            KIND_RINGER_SILENT -> {
                strokePaint.strokeWidth = context.dpF(2.0f)
                path.reset()
                path.moveTo(cx, cy - s * 0.85f)
                path.quadTo(cx + s * 0.68f, cy - s * 0.6f, cx + s * 0.72f, cy + s * 0.4f)
                path.lineTo(cx - s * 0.72f, cy + s * 0.4f)
                path.quadTo(cx - s * 0.68f, cy - s * 0.6f, cx, cy - s * 0.85f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - s * 0.85f, cy - s * 0.85f, cx + s * 0.85f, cy + s * 0.85f, strokePaint)
            }
            KIND_CLOSE -> {
                strokePaint.strokeWidth = context.dpF(2.2f)
                canvas.drawLine(cx - s * 0.55f, cy - s * 0.55f, cx + s * 0.55f, cy + s * 0.55f, strokePaint)
                canvas.drawLine(cx + s * 0.55f, cy - s * 0.55f, cx - s * 0.55f, cy + s * 0.55f, strokePaint)
            }
        }
    }
}

/**
 * Animated iOS-style toggle switch.
 */
class ToggleView(context: Context) : View(context) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val rect = RectF()
    private var animPos = 0f
    private var animator: ValueAnimator? = null

    var isChecked: Boolean = false
        private set
    var activeColor: Int = 0xFF30D158.toInt()
    var onChanged: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener {
            setChecked(!isChecked, animate = true)
            onChanged?.invoke(isChecked)
        }
    }

    fun setChecked(checked: Boolean, animate: Boolean = false) {
        isChecked = checked
        val target = if (checked) 1f else 0f
        animator?.cancel()
        if (animate && isAttachedToWindow) {
            animator = ValueAnimator.ofFloat(animPos, target).apply {
                duration = 190L
                addUpdateListener {
                    animPos = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            animPos = target
            invalidate()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(context.dp(50f), context.dp(30f))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f

        val offColor = 0xFF39393D.toInt()
        trackPaint.color = blendColors(offColor, activeColor, animPos)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, trackPaint)

        val pad = context.dpF(2.5f)
        val thumbR = (h - pad * 2f) / 2f
        val startX = pad + thumbR
        val endX = w - pad - thumbR
        val cx = startX + (endX - startX) * animPos
        canvas.drawCircle(cx, h / 2f, thumbR, thumbPaint)
    }

    private fun blendColors(c1: Int, c2: Int, ratio: Float): Int {
        val inv = 1f - ratio
        val r = (Color.red(c1) * inv + Color.red(c2) * ratio).toInt()
        val g = (Color.green(c1) * inv + Color.green(c2) * ratio).toInt()
        val b = (Color.blue(c1) * inv + Color.blue(c2) * ratio).toInt()
        return Color.rgb(r, g, b)
    }
}

/**
 * Slider control row with "-" and "+" fine-tuning buttons for 1-dp precision on a phone screen.
 */
class SliderRowView(
    context: Context,
    title: String,
    subtitle: String,
    private val minVal: Int,
    private val maxVal: Int,
    initialVal: Int,
    private val unitSuffix: String,
    private val onValueChange: (Int) -> Unit
) : LinearLayout(context) {

    private val valueLabel: TextView
    private val seekBar: SeekBar
    private var currentValue: Int = initialVal.coerceIn(minVal, maxVal)
    private var suppressCallback = false

    init {
        orientation = VERTICAL
        setPadding(context.dp(16f), context.dp(12f), context.dp(16f), context.dp(12f))

        val topRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val textCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }

        val titleTv = TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        textCol.addView(titleTv)

        if (subtitle.isNotEmpty()) {
            val subTv = TextView(context).apply {
                text = subtitle
                setTextColor(0xFF9898A0.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            }
            textCol.addView(subTv)
        }
        topRow.addView(textCol)

        // Minus button
        val minusBtn = TextView(context).apply {
            text = "−"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBg(0xFF2C2C34.toInt(), context.dpF(8f))
            layoutParams = LayoutParams(context.dp(32f), context.dp(32f)).apply {
                rightMargin = context.dp(8f)
            }
            setOnClickListener { setValue(currentValue - 1, notify = true) }
        }
        topRow.addView(minusBtn)

        valueLabel = TextView(context).apply {
            text = "$currentValue$unitSuffix"
            gravity = Gravity.CENTER
            setTextColor(0xFF5E5CE6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            minWidth = context.dp(54f)
        }
        topRow.addView(valueLabel)

        // Plus button
        val plusBtn = TextView(context).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBg(0xFF2C2C34.toInt(), context.dpF(8f))
            layoutParams = LayoutParams(context.dp(32f), context.dp(32f)).apply {
                leftMargin = context.dp(8f)
            }
            setOnClickListener { setValue(currentValue + 1, notify = true) }
        }
        topRow.addView(plusBtn)

        addView(topRow)

        seekBar = SeekBar(context).apply {
            max = maxVal - minVal
            progress = currentValue - minVal
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = context.dp(6f)
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = (minVal + p).coerceIn(minVal, maxVal)
                    currentValue = v
                    valueLabel.text = "$v$unitSuffix"
                    if (!suppressCallback) {
                        onValueChange(v)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        addView(seekBar)
    }

    fun setValue(newVal: Int, notify: Boolean = false) {
        val clamped = newVal.coerceIn(minVal, maxVal)
        currentValue = clamped
        suppressCallback = !notify
        seekBar.progress = clamped - minVal
        valueLabel.text = "$clamped$unitSuffix"
        suppressCallback = false
        if (notify) onValueChange(clamped)
    }
}

/**
 * Segmented pill selector row for choosing between 2..6 options.
 */
class SegmentedRowView(
    context: Context,
    title: String,
    options: List<String>,
    initialIndex: Int,
    private val onSelect: (Int) -> Unit
) : LinearLayout(context) {

    private val optionViews = mutableListOf<TextView>()
    private var selectedIdx = initialIndex.coerceIn(0, options.size - 1)

    init {
        orientation = VERTICAL
        setPadding(context.dp(16f), context.dp(12f), context.dp(16f), context.dp(12f))

        val titleTv = TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        addView(titleTv)

        val pillRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            background = roundedBg(0xFF23242C.toInt(), context.dpF(10f))
            val pad = context.dp(3f)
            setPadding(pad, pad, pad, pad)
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = context.dp(8f)
            }
        }

        options.forEachIndexed { idx, label ->
            val tv = TextView(context).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(context.dp(6f), context.dp(8f), context.dp(6f), context.dp(8f))
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setSelectedIndex(idx, notify = true)
                }
            }
            optionViews.add(tv)
            pillRow.addView(tv)
        }

        addView(pillRow)
        refreshStyles()
    }

    fun setSelectedIndex(idx: Int, notify: Boolean = false) {
        if (idx !in optionViews.indices) return
        selectedIdx = idx
        refreshStyles()
        if (notify) onSelect(idx)
    }

    private fun refreshStyles() {
        optionViews.forEachIndexed { idx, tv ->
            if (idx == selectedIdx) {
                tv.background = roundedBg(0xFF5E5CE6.toInt(), context.dpF(8f))
                tv.setTextColor(Color.WHITE)
            } else {
                tv.background = null
                tv.setTextColor(0xFF9898A0.toInt())
            }
        }
    }
}
