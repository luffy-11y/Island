package com.example.island

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE_NAME = "island_prefs"

    // Broadcast Actions
    const val ACTION_PREFS_CHANGED = "com.example.island.ACTION_PREFS_CHANGED"
    const val ACTION_PREVIEW = "com.example.island.ACTION_PREVIEW"
    const val EXTRA_PREVIEW_TYPE = "preview_type"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    // Master & Feature Toggles
    var enabled: Boolean = true
    fun isEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("enabled", true)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("enabled", v).apply()

    // Always-on idle pill around the camera punch-hole
    fun isIdlePill(ctx: Context): Boolean = sp(ctx).getBoolean("idle_pill", false)
    fun setIdlePill(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("idle_pill", v).apply()

    // Auto-align to hardware display cutout (Samsung Galaxy A52s punch-hole)
    fun isAutoCutout(ctx: Context): Boolean = sp(ctx).getBoolean("auto_cutout", true)
    fun setAutoCutout(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("auto_cutout", v).apply()

    // Core feature modules
    fun isNotifs(ctx: Context): Boolean = sp(ctx).getBoolean("notifs", true)
    fun setNotifs(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("notifs", v).apply()

    fun isMedia(ctx: Context): Boolean = sp(ctx).getBoolean("media", true)
    fun setMedia(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("media", v).apply()

    fun isCalls(ctx: Context): Boolean = sp(ctx).getBoolean("calls", true)
    fun setCalls(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("calls", v).apply()

    fun isTimers(ctx: Context): Boolean = sp(ctx).getBoolean("timers", true)
    fun setTimers(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("timers", v).apply()

    fun isBattery(ctx: Context): Boolean = sp(ctx).getBoolean("battery", true)
    fun setBattery(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("battery", v).apply()

    fun isBluetooth(ctx: Context): Boolean = sp(ctx).getBoolean("bluetooth", true)
    fun setBluetooth(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("bluetooth", v).apply()

    fun isRinger(ctx: Context): Boolean = sp(ctx).getBoolean("ringer", true)
    fun setRinger(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("ringer", v).apply()

    // Visual & Privacy Options
    fun isHideText(ctx: Context): Boolean = sp(ctx).getBoolean("hide_text", false)
    fun setHideText(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_text", v).apply()

    fun isHideLandscape(ctx: Context): Boolean = sp(ctx).getBoolean("hide_landscape", true)
    fun setHideLandscape(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_landscape", v).apply()

    fun isQuickReplies(ctx: Context): Boolean = sp(ctx).getBoolean("quick_replies", true)
    fun setQuickReplies(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("quick_replies", v).apply()

    fun isEqualizer(ctx: Context): Boolean = sp(ctx).getBoolean("equalizer", true)
    fun setEqualizer(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("equalizer", v).apply()

    fun isSpinArt(ctx: Context): Boolean = sp(ctx).getBoolean("spin_art", false)
    fun setSpinArt(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("spin_art", v).apply()

    fun isGlowBorder(ctx: Context): Boolean = sp(ctx).getBoolean("glow_border", true)
    fun setGlowBorder(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("glow_border", v).apply()

    fun isHaptics(ctx: Context): Boolean = sp(ctx).getBoolean("haptics", true)
    fun setHaptics(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("haptics", v).apply()

    // Position & Sizing Sliders
    // Default top_dp = -28 matches Samsung Galaxy A52s punch-hole center when cutout mode is active
    fun getTopDp(ctx: Context): Int = sp(ctx).getInt("top_dp", -28)
    fun setTopDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("top_dp", v.coerceIn(-45, 120)).apply()

    fun getOffsetXDp(ctx: Context): Int = sp(ctx).getInt("offset_x_dp", 0)
    fun setOffsetXDp(ctx: Context, v: Int) = sp(ctx).edit().putInt("offset_x_dp", v.coerceIn(-60, 60)).apply()

    fun getScalePct(ctx: Context): Int = sp(ctx).getInt("scale_pct", 100)
    fun setScalePct(ctx: Context, v: Int) = sp(ctx).edit().putInt("scale_pct", v.coerceIn(80, 130)).apply()

    fun getSeconds(ctx: Context): Int = sp(ctx).getInt("seconds", 5)
    fun setSeconds(ctx: Context, v: Int) = sp(ctx).edit().putInt("seconds", v.coerceIn(2, 12)).apply()

    fun getOpacityPct(ctx: Context): Int = sp(ctx).getInt("opacity_pct", 100)
    fun setOpacityPct(ctx: Context, v: Int) = sp(ctx).edit().putInt("opacity_pct", v.coerceIn(75, 100)).apply()

    // Segmented Choices
    // 0 = Bouncy (iOS style), 1 = Balanced, 2 = Snappy
    fun getSpringStyle(ctx: Context): Int = sp(ctx).getInt("spring_style", 0)
    fun setSpringStyle(ctx: Context, v: Int) = sp(ctx).edit().putInt("spring_style", v.coerceIn(0, 2)).apply()

    // 0 = Adaptive (Album / App Color), 1 = iOS Indigo, 2 = Neon Green, 3 = Sunset Coral, 4 = Cyan Pulse, 5 = Pure White
    fun getAccentMode(ctx: Context): Int = sp(ctx).getInt("accent_mode", 0)
    fun setAccentMode(ctx: Context, v: Int) = sp(ctx).edit().putInt("accent_mode", v.coerceIn(0, 5)).apply()

    // Gesture Customization
    // Tap: 0 = Expand / Collapse, 1 = Open App Directly
    fun getTapAction(ctx: Context): Int = sp(ctx).getInt("tap_action", 0)
    fun setTapAction(ctx: Context, v: Int) = sp(ctx).edit().putInt("tap_action", v.coerceIn(0, 1)).apply()

    // Long-press: 0 = Open App, 1 = Expand / Collapse, 2 = Dismiss
    fun getLongPressAction(ctx: Context): Int = sp(ctx).getInt("long_press_action", 0)
    fun setLongPressAction(ctx: Context, v: Int) = sp(ctx).edit().putInt("long_press_action", v.coerceIn(0, 2)).apply()

    // Per-App Blocklist
    fun getBlockedApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("blocked_apps", emptySet()) ?: emptySet()

    fun isAppBlocked(ctx: Context, pkg: String): Boolean =
        getBlockedApps(ctx).contains(pkg)

    fun toggleAppBlocked(ctx: Context, pkg: String): Boolean {
        val current = getBlockedApps(ctx).toMutableSet()
        val nowBlocked = if (current.contains(pkg)) {
            current.remove(pkg)
            false
        } else {
            current.add(pkg)
            true
        }
        sp(ctx).edit().putStringSet("blocked_apps", current).apply()
        return nowBlocked
    }

    fun resolveAccentColor(ctx: Context, dynamicColor: Int): Int {
        return when (getAccentMode(ctx)) {
            0 -> dynamicColor
            1 -> 0xFF5E5CE6.toInt() // iOS Indigo
            2 -> 0xFF30D158.toInt() // Neon Green
            3 -> 0xFFFF6B6B.toInt() // Sunset Coral
            4 -> 0xFF32ADE6.toInt() // Cyan Pulse
            5 -> 0xFFFFFFFF.toInt() // Pure White
            else -> dynamicColor
        }
    }

    fun applyA52sPreset(ctx: Context) {
        sp(ctx).edit()
            .putBoolean("auto_cutout", true)
            .putInt("top_dp", -28)
            .putInt("offset_x_dp", 0)
            .putInt("scale_pct", 100)
            .putInt("spring_style", 0)
            .putBoolean("glow_border", true)
            .apply()
    }
}
