# Changelog

## 7.0-A52s
- Rebuilt the settings/control-centre UI as a premium dark dashboard.
- Added hero preview, preview actions and reorganized live-module, calibration, appearance, gesture and privacy controls.
- Connected all settings controls to the existing persistent preferences and service update broadcast.
- Corrected preview action identifiers to match the overlay service (`notif` and `music`).
- Updated version code/name to 7 / 7.0-A52s.
