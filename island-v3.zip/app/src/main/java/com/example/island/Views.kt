package com.example.island

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/** Clips a view to a rounded rectangle. */
fun roundClip(view: View, radius: Float) {
    view.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(v: View, outline: Outline) {
            outline.setRoundRect(0, 0, v.width, v.height, radius)
        }
    }
    view.clipToOutline = true
}

/** Four bouncing bars, like the music indicator on the real island. */
class EqualizerView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()
    private var phase = 0f
    private var running = false
    private val freq = intArrayOf(1, 2, 1, 3)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    fun setColor(color: Int) {
        paint.color = color
        invalidate()
    }

    fun setPlaying(playing: Boolean) {
        running = playing
        if (playing) {
            if (!animator.isRunning) animator.start()
        } else {
            animator.cancel()
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (running && !animator.isRunning) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val bars = freq.size
        val gap = width * 0.14f
        val barW = (width - gap * (bars - 1)) / bars
        val maxH = height.toFloat()
        for (i in 0 until bars) {
            val h = if (running) {
                val wave = abs(sin(2.0 * Math.PI * (phase * freq[i] + i * 0.17))).toFloat()
                maxH * (0.22f + 0.78f * wave)
            } else {
                maxH * 0.22f
            }
            val x = i * (barW + gap)
            val top = (maxH - h) / 2f
            rect.set(x, top, x + barW, top + h)
            canvas.drawRoundRect(rect, barW / 2f, barW / 2f, paint)
        }
    }
}

/** Thin music progress bar you can tap or drag to seek. */
class ProgressLine(context: Context) : View(context) {
    var fraction = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    var accent = Color.WHITE
        set(value) {
            field = value
            invalidate()
        }
    var dragging = false
    var onSeek: ((Float) -> Unit)? = null

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x44FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val lineH = 4f * resources.displayMetrics.density
        val top = (height - lineH) / 2f
        val r = lineH / 2f
        rect.set(0f, top, width.toFloat(), top + lineH)
        canvas.drawRoundRect(rect, r, r, track)
        val w = width * fraction
        if (w > 0f) {
            fill.color = accent
            rect.set(0f, top, max(w, lineH), top + lineH)
            canvas.drawRoundRect(rect, r, r, fill)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (width == 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                fraction = e.x / width
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                fraction = e.x / width
                return true
            }
            MotionEvent.ACTION_UP -> {
                fraction = e.x / width
                dragging = false
                onSeek?.invoke(fraction)
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Previous / play / pause / next icons, drawn by hand so they stay sharp. */
class ControlIconView(context: Context, initial: Int) : View(context) {
    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    var kind: Int = initial
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val path = Path()

    init {
        isClickable = true
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.82f).scaleY(0.82f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }

    private fun triRight(c: Canvas, tipX: Float, cy: Float, w: Float, h: Float) {
        path.reset()
        path.moveTo(tipX - w, cy - h)
        path.lineTo(tipX, cy)
        path.lineTo(tipX - w, cy + h)
        path.close()
        c.drawPath(path, paint)
    }

    private fun triLeft(c: Canvas, tipX: Float, cy: Float, w: Float, h: Float) {
        path.reset()
        path.moveTo(tipX + w, cy - h)
        path.lineTo(tipX, cy)
        path.lineTo(tipX + w, cy + h)
        path.close()
        c.drawPath(path, paint)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = minOf(width, height) * 0.36f
        when (kind) {
            PLAY -> {
                path.reset()
                path.moveTo(cx - s * 0.7f, cy - s)
                path.lineTo(cx + s * 0.95f, cy)
                path.lineTo(cx - s * 0.7f, cy + s)
                path.close()
                canvas.drawPath(path, paint)
            }
            PAUSE -> {
                val bw = s * 0.62f
                canvas.drawRoundRect(cx - s * 0.8f, cy - s, cx - s * 0.8f + bw, cy + s, bw / 4f, bw / 4f, paint)
                canvas.drawRoundRect(cx + s * 0.8f - bw, cy - s, cx + s * 0.8f, cy + s, bw / 4f, bw / 4f, paint)
            }
            NEXT -> {
                triRight(canvas, cx, cy, s * 0.95f, s * 0.8f)
                triRight(canvas, cx + s * 0.95f, cy, s * 0.95f, s * 0.8f)
            }
            PREV -> {
                triLeft(canvas, cx, cy, s * 0.95f, s * 0.8f)
                triLeft(canvas, cx - s * 0.95f, cy, s * 0.95f, s * 0.8f)
            }
        }
    }
}

/** A smooth on/off switch. */
class ToggleView(context: Context) : View(context) {
    private val onColor = 0xFF30D158.toInt()
    private val offColor = 0xFF48484A.toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val argb = ArgbEvaluator()
    private var t = 0f
    private var anim: ValueAnimator? = null

    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener {
            update(!checked, true)
            onChange?.invoke(checked)
        }
    }

    fun update(value: Boolean, animate: Boolean) {
        checked = value
        anim?.cancel()
        val target = if (value) 1f else 0f
        if (!animate) {
            t = target
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(t, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val d = resources.displayMetrics.density
        setMeasuredDimension((51 * d).toInt(), (31 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.color = argb.evaluate(t.coerceIn(0f, 1f), offColor, onColor) as Int
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, paint)
        val pad = 2f * resources.displayMetrics.density
        val r = h / 2f - pad
        val cx = pad + r + (w - 2f * pad - 2f * r) * t
        paint.color = Color.WHITE
        canvas.drawCircle(cx, h / 2f, r, paint)
    }
}
