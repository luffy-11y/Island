package com.example.island

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private val cardColor = 0xFF1C1C1E.toInt()
    private val dividerColor = 0xFF2C2C2E.toInt()
    private val textSub = 0xFF8E8E93.toInt()
    private val accent = 0xFF0A84FF.toInt()
    private val green = 0xFF30D158.toInt()
    private val orange = 0xFFFF9F0A.toInt()

    private class StatusRow(val view: View, val dot: View, val status: TextView)

    private lateinit var overlayRow: StatusRow
    private lateinit var listenerRow: StatusRow

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.isVerticalScrollBarEnabled = false

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(28), dp(16), dp(40))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        col.addView(hero())

        // ---- setup
        col.addView(sectionTitle("SETUP"))
        overlayRow = statusRow("Display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
            )
        }
        listenerRow = statusRow("Notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        col.addView(card(overlayRow.view, listenerRow.view))

        val helpText = TextView(this)
        helpText.text = "Can't switch on Notification access? Android blocks it for apps installed " +
            "outside the Play Store. Open App info, tap the three dots at the top right, choose " +
            "Allow restricted settings, then try again. Also set Battery to Unrestricted so the " +
            "island is never put to sleep."
        helpText.setTextColor(textSub)
        helpText.textSize = 13f
        val help = LinearLayout(this)
        help.orientation = LinearLayout.VERTICAL
        help.setPadding(dp(16), dp(14), dp(16), dp(14))
        help.addView(helpText)
        help.addView(
            smallButton("Open App info") {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
                )
            },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(10) }
        )
        col.addView(card(help))

        // ---- master + what to show
        col.addView(sectionTitle("ISLAND"))
        col.addView(
            card(
                toggleRow("Island", "Turn the whole island on or off", Prefs.ENABLED),
                toggleRow("Notifications", "Messages, emails and app alerts", Prefs.NOTIFS),
                toggleRow("Music", "Now playing, with controls", Prefs.MEDIA),
                toggleRow("Calls, alarms and timers", "Answer and decline from the island", Prefs.CALLS)
            )
        )

        col.addView(sectionTitle("BEHAVIOR"))
        col.addView(
            card(
                toggleRow("Hide message text", "Show only the app name for privacy", Prefs.HIDE_TEXT),
                toggleRow("Equalizer animation", "Moving bars while music plays", Prefs.EQUALIZER),
                toggleRow("Haptic tick", "A tiny vibration when the island opens", Prefs.HAPTICS),
                sliderRow("Notification time", Prefs.SECONDS, 2, 10, Prefs.DEFAULT_SECONDS, " s", false)
            )
        )

        col.addView(sectionTitle("POSITION"))
        col.addView(
            card(
                sliderRow("Distance from top", Prefs.TOP_DP, -40, 120, Prefs.DEFAULT_TOP_DP, " dp", true)
            )
        )
        val posNote = TextView(this)
        posNote.text = "Drag the slider and watch the island. Line it up with your camera hole."
        posNote.setTextColor(textSub)
        posNote.textSize = 12f
        posNote.setPadding(dp(16), dp(8), dp(16), 0)
        col.addView(posNote)

        val preview = primaryButton("Preview island") {
            val svc = IslandListenerService.instance
            if (svc == null) {
                Toast.makeText(this, "Turn on Notification access first", Toast.LENGTH_LONG).show()
            } else {
                svc.demo()
            }
        }
        col.addView(preview, LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(22) })

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------------ status

    private fun isListenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun refreshStatus() {
        setStatus(overlayRow, Settings.canDrawOverlays(this), "Allowed", "Tap to allow")
        val running = IslandListenerService.instance != null
        setStatus(
            listenerRow,
            isListenerEnabled(),
            if (running) "Running" else "Allowed",
            "Tap to allow"
        )
    }

    private fun setStatus(r: StatusRow, ok: Boolean, okText: String, noText: String) {
        r.status.text = if (ok) okText else noText
        r.status.setTextColor(if (ok) green else orange)
        (r.dot.background as GradientDrawable).setColor(if (ok) green else orange)
    }

    // ------------------------------------------------------------------ building blocks

    private fun hero(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(26), dp(22), dp(26))
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF5E5CE6.toInt(), 0xFF0A84FF.toInt())
        )
        bg.cornerRadius = dp(28).toFloat()
        box.background = bg

        val title = TextView(this)
        title.text = "Island"
        title.textSize = 34f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        box.addView(title)

        val sub = TextView(this)
        sub.text = "A Dynamic Island for your Android phone"
        sub.textSize = 15f
        sub.setTextColor(0xCCFFFFFF.toInt())
        box.addView(sub)

        val pill = FrameLayout(this)
        val pillBg = GradientDrawable()
        pillBg.setColor(Color.BLACK)
        pillBg.cornerRadius = dp(17).toFloat()
        pill.background = pillBg

        val dot = View(this)
        val dotBg = GradientDrawable()
        dotBg.shape = GradientDrawable.OVAL
        dotBg.setColor(0xFFFF375F.toInt())
        dot.background = dotBg
        val dotLp = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.START or Gravity.CENTER_VERTICAL)
        dotLp.marginStart = dp(8)
        pill.addView(dot, dotLp)

        val eq = EqualizerView(this)
        eq.setColor(0xFFFF375F.toInt())
        eq.setPlaying(true)
        val eqLp = FrameLayout.LayoutParams(dp(18), dp(14), Gravity.END or Gravity.CENTER_VERTICAL)
        eqLp.marginEnd = dp(12)
        pill.addView(eq, eqLp)

        val pillLp = LinearLayout.LayoutParams(dp(172), dp(34))
        pillLp.topMargin = dp(20)
        box.addView(pill, pillLp)
        return box
    }

    private fun sectionTitle(text: String): View {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(textSub)
        tv.setPadding(dp(16), dp(24), dp(16), dp(8))
        return tv
    }

    private fun card(vararg rows: View): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(cardColor)
        bg.cornerRadius = dp(18).toFloat()
        c.background = bg
        for ((i, r) in rows.withIndex()) {
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(dividerColor)
                val lp = LinearLayout.LayoutParams(MATCH, 1)
                lp.marginStart = dp(16)
                c.addView(line, lp)
            }
            c.addView(r)
        }
        return c
    }

    private fun statusRow(title: String, onClick: () -> Unit): StatusRow {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        row.isClickable = true
        row.setOnClickListener { onClick() }

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        val s = TextView(this)
        s.textSize = 13f
        s.setTextColor(textSub)
        left.addView(t)
        left.addView(s)
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val dot = View(this)
        val dotBg = GradientDrawable()
        dotBg.shape = GradientDrawable.OVAL
        dotBg.setColor(orange)
        dot.background = dotBg
        row.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
        return StatusRow(row, dot, s)
    }

    private fun toggleRow(title: String, sub: String?, key: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(13), dp(16), dp(13))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        left.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 12.5f
            s.setTextColor(textSub)
            s.setPadding(0, dp(2), 0, 0)
            left.addView(s)
        }
        val leftLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        leftLp.marginEnd = dp(12)
        row.addView(left, leftLp)

        val toggle = ToggleView(this)
        toggle.update(Prefs.on(this, key), false)
        toggle.onChange = { v -> Prefs.sp(this).edit().putBoolean(key, v).apply() }
        row.addView(toggle)
        return row
    }

    private fun sliderRow(
        title: String,
        key: String,
        lo: Int,
        hi: Int,
        def: Int,
        unit: String,
        live: Boolean
    ): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(dp(16), dp(13), dp(16), dp(10))

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        val value = TextView(this)
        value.textSize = 15f
        value.setTextColor(textSub)
        header.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(value)
        row.addView(header)

        val current = Prefs.int(this, key, def)
        value.text = current.toString() + unit

        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = current - lo
        bar.progressTintList = ColorStateList.valueOf(accent)
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                value.text = v.toString() + unit
                if (fromUser) {
                    Prefs.sp(this@MainActivity).edit().putInt(key, v).apply()
                    if (live) IslandListenerService.instance?.previewPosition()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        return row
    }

    private fun primaryButton(label: String, onClick: () -> Unit): View {
        val b = TextView(this)
        b.text = label
        b.gravity = Gravity.CENTER
        b.textSize = 16f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.setColor(accent)
        bg.cornerRadius = dp(16).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(label: String, onClick: () -> Unit): View {
        val b = TextView(this)
        b.text = label
        b.gravity = Gravity.CENTER
        b.textSize = 14f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(Color.WHITE)
        b.setPadding(dp(16), dp(9), dp(16), dp(9))
        val bg = GradientDrawable()
        bg.setColor(0xFF2C2C2E.toInt())
        bg.cornerRadius = dp(14).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }
}
