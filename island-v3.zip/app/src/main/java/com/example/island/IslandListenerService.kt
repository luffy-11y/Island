package com.example.island

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The island itself. It lives inside the notification listener, so Android keeps it alive
 * and tells it about every new notification and every music session.
 */
class IslandListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: IslandListenerService? = null

        private const val HIDDEN = 0
        private const val MEDIA_SMALL = 1
        private const val MEDIA_BIG = 2
        private const val NOTIF = 3

        private const val SMALL_W = 172
        private const val SMALL_H = 34

        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private class NotifData(
        val key: String,
        val title: String,
        val text: String,
        val appName: String,
        val icon: Drawable?,
        val contentIntent: PendingIntent?,
        val actions: List<Pair<String, PendingIntent>>,
        val isCall: Boolean,
        val seconds: Int
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var container: FrameLayout
    private val pillBg = GradientDrawable().apply { setColor(Color.BLACK) }
    private var cornerPx = 0f
    private var attached = false
    private var mode = HIDDEN
    private var pushScheduled = false

    // views
    private lateinit var smallView: FrameLayout
    private lateinit var smallArt: ImageView
    private lateinit var smallEq: EqualizerView
    private lateinit var bigView: LinearLayout
    private lateinit var bigArt: ImageView
    private lateinit var bigTitle: TextView
    private lateinit var bigArtist: TextView
    private lateinit var bigEq: EqualizerView
    private lateinit var progress: ProgressLine
    private lateinit var tvElapsed: TextView
    private lateinit var tvTotal: TextView
    private lateinit var btnPrev: ControlIconView
    private lateinit var btnPlay: ControlIconView
    private lateinit var btnNext: ControlIconView
    private lateinit var notifView: LinearLayout
    private lateinit var nIcon: ImageView
    private lateinit var nApp: TextView
    private lateinit var nTitle: TextView
    private lateinit var nText: TextView
    private lateinit var nActions: LinearLayout

    // notifications
    private val notifQueue = ArrayDeque<NotifData>()
    private var currentNotif: NotifData? = null
    private val recent = HashMap<String, Long>()
    private val notifTimeout = Runnable { nextNotif() }

    // music
    private var sessionManager: MediaSessionManager? = null
    private var controller: MediaController? = null
    private var mediaTitle: String? = null
    private var mediaArtist: String? = null
    private var mediaArt: Bitmap? = null
    private var mediaPlaying = false
    private var mediaVisible = false
    private var mediaExpanded = false
    private var mediaDuration = 0L
    private var accentColor = Color.WHITE
    private var dismissedTitle: String? = null
    private val mediaHide = Runnable {
        mediaVisible = false
        mediaExpanded = false
        render()
    }
    private val mediaCollapse = Runnable {
        mediaExpanded = false
        render()
    }
    private val progressTick = object : Runnable {
        override fun run() {
            updateProgress()
            if (mode == MEDIA_BIG) handler.postDelayed(this, 500)
        }
    }

    // springs: one for width, one for height, tuned slightly differently so it feels alive
    private val wHolder = FloatValueHolder(0f)
    private val hHolder = FloatValueHolder(0f)
    private val wAnim = SpringAnimation(wHolder).apply {
        setMinimumVisibleChange(1f)
        setSpring(SpringForce().setDampingRatio(0.62f).setStiffness(420f))
        addUpdateListener { _, v, _ -> onWidth(v) }
    }
    private val hAnim = SpringAnimation(hHolder).apply {
        setMinimumVisibleChange(1f)
        setSpring(SpringForce().setDampingRatio(0.7f).setStiffness(340f))
        addUpdateListener { _, v, _ -> onHeight(v) }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.TOP_DP -> if (attached) {
                params.y = dp(Prefs.int(this, Prefs.TOP_DP, Prefs.DEFAULT_TOP_DP))
                push()
            }
            Prefs.EQUALIZER -> applyEq()
            else -> render()
        }
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            updateMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            updateMedia()
        }

        override fun onSessionDestroyed() {
            controller = null
            updateMedia()
        }
    }

    private val sessionListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> onSessions(list ?: emptyList()) }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dp(v: Int): Int = dp(v.toFloat())

    private fun bigWidth(): Int = min(dp(372), resources.displayMetrics.widthPixels - dp(24))

    private fun appIcon(pkg: String): Drawable? =
        try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }

    private fun appLabel(pkg: String): String =
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean, lines: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = sizeSp
        tv.setTextColor(color)
        tv.maxLines = lines
        tv.ellipsize = TextUtils.TruncateAt.END
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildViews()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onListenerConnected() {
        instance = this
        startMediaWatching()
        render()
    }

    override fun onListenerDisconnected() {
        stopMediaWatching()
        detachIsland()
        instance = null
    }

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        stopMediaWatching()
        handler.removeCallbacksAndMessages(null)
        detachIsland()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ building the views

    private fun buildViews() {
        val c = this

        container = FrameLayout(c)
        container.background = pillBg
        container.clipToOutline = true
        container.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
            }
        }

        // --- small music pill: album art on the left, equalizer on the right
        smallView = FrameLayout(c)
        smallArt = ImageView(c)
        smallArt.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(smallArt, dp(7).toFloat())
        smallEq = EqualizerView(c)
        val artLp = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.START or Gravity.CENTER_VERTICAL)
        artLp.marginStart = dp(8)
        smallView.addView(smallArt, artLp)
        val eqLp = FrameLayout.LayoutParams(dp(18), dp(14), Gravity.END or Gravity.CENTER_VERTICAL)
        eqLp.marginEnd = dp(12)
        smallView.addView(smallEq, eqLp)
        container.addView(
            smallView,
            FrameLayout.LayoutParams(dp(SMALL_W), dp(SMALL_H), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        )
        smallView.visibility = View.GONE

        // --- big music card
        bigView = LinearLayout(c)
        bigView.orientation = LinearLayout.VERTICAL
        bigView.setPadding(dp(18), dp(16), dp(18), dp(10))

        val header = LinearLayout(c)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        bigArt = ImageView(c)
        bigArt.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(bigArt, dp(12).toFloat())
        header.addView(bigArt, LinearLayout.LayoutParams(dp(56), dp(56)))
        val texts = LinearLayout(c)
        texts.orientation = LinearLayout.VERTICAL
        bigTitle = label("", 16f, Color.WHITE, true, 1)
        bigArtist = label("", 13f, 0xFFB0B0B8.toInt(), false, 1)
        texts.addView(bigTitle)
        texts.addView(bigArtist)
        val textsLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        textsLp.marginStart = dp(12)
        textsLp.marginEnd = dp(12)
        header.addView(texts, textsLp)
        bigEq = EqualizerView(c)
        header.addView(bigEq, LinearLayout.LayoutParams(dp(22), dp(18)))
        bigView.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        progress = ProgressLine(c)
        val progLp = LinearLayout.LayoutParams(MATCH, dp(20))
        progLp.topMargin = dp(8)
        bigView.addView(progress, progLp)
        progress.onSeek = { f ->
            if (mediaDuration > 0) {
                controller?.transportControls?.seekTo((f * mediaDuration).toLong())
            }
            scheduleCollapse()
        }

        val times = LinearLayout(c)
        times.orientation = LinearLayout.HORIZONTAL
        tvElapsed = label("0:00", 11f, 0xFF9A9AA2.toInt(), false, 1)
        tvTotal = label("0:00", 11f, 0xFF9A9AA2.toInt(), false, 1)
        times.addView(tvElapsed, LinearLayout.LayoutParams(0, WRAP, 1f))
        times.addView(tvTotal)
        bigView.addView(times, LinearLayout.LayoutParams(MATCH, WRAP))

        val controls = LinearLayout(c)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        btnPrev = ControlIconView(c, ControlIconView.PREV)
        btnPlay = ControlIconView(c, ControlIconView.PLAY)
        btnNext = ControlIconView(c, ControlIconView.NEXT)
        controls.addView(btnPrev, LinearLayout.LayoutParams(dp(68), dp(48)))
        controls.addView(btnPlay, LinearLayout.LayoutParams(dp(76), dp(48)))
        controls.addView(btnNext, LinearLayout.LayoutParams(dp(68), dp(48)))
        bigView.addView(controls, LinearLayout.LayoutParams(MATCH, WRAP))
        btnPrev.setOnClickListener {
            controller?.transportControls?.skipToPrevious()
            scheduleCollapse()
        }
        btnNext.setOnClickListener {
            controller?.transportControls?.skipToNext()
            scheduleCollapse()
        }
        btnPlay.setOnClickListener {
            val tc = controller?.transportControls
            if (mediaPlaying) tc?.pause() else tc?.play()
            scheduleCollapse()
        }
        container.addView(
            bigView,
            FrameLayout.LayoutParams(bigWidth(), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        )
        bigView.visibility = View.GONE

        // --- notification card
        notifView = LinearLayout(c)
        notifView.orientation = LinearLayout.VERTICAL
        notifView.setPadding(dp(16), dp(14), dp(16), dp(14))
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        nIcon = ImageView(c)
        nIcon.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(nIcon, dp(11).toFloat())
        row.addView(nIcon, LinearLayout.LayoutParams(dp(44), dp(44)))
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        nApp = label("", 11f, 0xFF8E8E93.toInt(), false, 1)
        nTitle = label("", 15f, Color.WHITE, true, 1)
        nText = label("", 13f, 0xFFD1D1D6.toInt(), false, 2)
        col.addView(nApp)
        col.addView(nTitle)
        col.addView(nText)
        val colLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        colLp.marginStart = dp(12)
        row.addView(col, colLp)
        notifView.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        nActions = LinearLayout(c)
        nActions.orientation = LinearLayout.HORIZONTAL
        nActions.visibility = View.GONE
        val actLp = LinearLayout.LayoutParams(MATCH, WRAP)
        actLp.topMargin = dp(12)
        notifView.addView(nActions, actLp)
        container.addView(
            notifView,
            FrameLayout.LayoutParams(bigWidth(), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        )
        notifView.visibility = View.GONE

        // --- touch: tap and swipe up
        container.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (dy < -dp(22)) {
                            onSwipeUp()
                        } else if (abs(dx) < dp(16) && abs(dy) < dp(16)) {
                            onTap()
                        }
                    }
                }
                return true
            }
        })

        // --- the window
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        params = WindowManager.LayoutParams(
            dp(60),
            dp(16),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // ------------------------------------------------------------------ deciding what to show

    private fun render(force: Boolean = false) {
        if (!Prefs.on(this, Prefs.ENABLED) || !Settings.canDrawOverlays(this)) {
            setMode(HIDDEN, false)
            return
        }
        val mediaOn = Prefs.on(this, Prefs.MEDIA) && mediaVisible &&
            controller != null && !mediaTitle.isNullOrEmpty()
        val target = when {
            currentNotif != null -> NOTIF
            mediaOn && mediaExpanded -> MEDIA_BIG
            mediaOn -> MEDIA_SMALL
            else -> HIDDEN
        }
        setMode(target, force)
    }

    private fun setMode(newMode: Int, force: Boolean) {
        if (newMode == HIDDEN) {
            hideIsland()
            return
        }
        if (newMode == mode && !force) return
        val wasHidden = mode == HIDDEN
        val old = mode
        mode = newMode
        if (wasHidden) {
            if (!attached) {
                attachIsland()
            } else {
                container.animate().cancel()
                container.animate().setStartDelay(0).alpha(1f).setDuration(120).start()
            }
        }
        if (!attached) {
            mode = HIDDEN
            return
        }
        val bw = bigWidth()
        (bigView.layoutParams as FrameLayout.LayoutParams).width = bw
        (notifView.layoutParams as FrameLayout.LayoutParams).width = bw
        showContent(newMode)
        val size = targetSize(newMode)
        wAnim.animateToFinalPosition(size.first.toFloat())
        hAnim.animateToFinalPosition(size.second.toFloat())
        handler.removeCallbacks(progressTick)
        if (newMode == MEDIA_BIG) handler.post(progressTick)
        if (wasHidden || old != newMode) haptic()
    }

    private fun targetSize(m: Int): Pair<Int, Int> {
        val bw = bigWidth()
        return when (m) {
            MEDIA_SMALL -> Pair(dp(SMALL_W), dp(SMALL_H))
            MEDIA_BIG -> Pair(bw, measuredHeight(bigView, bw))
            else -> Pair(bw, max(dp(76), measuredHeight(notifView, bw)))
        }
    }

    private fun measuredHeight(v: View, width: Int): Int {
        v.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return v.measuredHeight
    }

    /** Cross-fades the content: old one fades out fast, new one fades in with a little zoom. */
    private fun showContent(m: Int) {
        val pairs = listOf(MEDIA_SMALL to smallView, MEDIA_BIG to bigView, NOTIF to notifView)
        for ((viewMode, v) in pairs) {
            if (viewMode == m) {
                v.animate().cancel()
                v.visibility = View.VISIBLE
                v.alpha = 0f
                v.scaleX = 0.92f
                v.scaleY = 0.92f
                v.animate().setStartDelay(90).alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
            } else if (v.visibility == View.VISIBLE) {
                v.animate().cancel()
                v.animate().setStartDelay(0).alpha(0f).setDuration(110).withEndAction {
                    if (mode != viewMode) v.visibility = View.GONE
                }.start()
            }
        }
    }

    // ------------------------------------------------------------------ the window

    private fun attachIsland() {
        if (attached) return
        wAnim.cancel()
        hAnim.cancel()
        params.width = dp(60)
        params.height = dp(16)
        params.y = dp(Prefs.int(this, Prefs.TOP_DP, Prefs.DEFAULT_TOP_DP))
        wHolder.value = params.width.toFloat()
        hHolder.value = params.height.toFloat()
        cornerPx = params.height / 2f
        pillBg.cornerRadius = cornerPx
        container.alpha = 0f
        try {
            wm.addView(container, params)
            attached = true
        } catch (e: Exception) {
            attached = false
            return
        }
        container.animate().cancel()
        container.animate().setStartDelay(0).alpha(1f).setDuration(160).start()
    }

    private fun hideIsland() {
        handler.removeCallbacks(progressTick)
        if (mode == HIDDEN) return
        mode = HIDDEN
        if (!attached) return
        wAnim.animateToFinalPosition(dp(54).toFloat())
        hAnim.animateToFinalPosition(dp(12).toFloat())
        container.animate().cancel()
        container.animate().setStartDelay(40).alpha(0f).setDuration(220).withEndAction {
            if (mode == HIDDEN) detachIsland()
        }.start()
    }

    private fun detachIsland() {
        mode = HIDDEN
        handler.removeCallbacks(progressTick)
        wAnim.cancel()
        hAnim.cancel()
        if (attached) {
            try {
                wm.removeView(container)
            } catch (e: Exception) {
            }
            attached = false
        }
    }

    private fun onWidth(v: Float) {
        params.width = max(v.toInt(), dp(16))
        push()
    }

    private fun onHeight(v: Float) {
        params.height = max(v.toInt(), dp(8))
        push()
    }

    /** Both springs ask for a layout every frame; this merges them into one. */
    private fun push() {
        if (!attached || pushScheduled) return
        pushScheduled = true
        container.postOnAnimation {
            pushScheduled = false
            if (attached) {
                cornerPx = min(params.height / 2f, dp(34).toFloat())
                pillBg.cornerRadius = cornerPx
                container.invalidateOutline()
                try {
                    wm.updateViewLayout(container, params)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun haptic() {
        if (Prefs.on(this, Prefs.HAPTICS)) {
            container.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    // ------------------------------------------------------------------ touch

    private fun onTap() {
        when (mode) {
            NOTIF -> {
                try {
                    currentNotif?.contentIntent?.send()
                } catch (e: Exception) {
                }
                nextNotif()
            }
            MEDIA_SMALL -> {
                mediaExpanded = true
                scheduleCollapse()
                render()
            }
            MEDIA_BIG -> {
                mediaExpanded = false
                handler.removeCallbacks(mediaCollapse)
                render()
            }
        }
    }

    private fun onSwipeUp() {
        when (mode) {
            NOTIF -> nextNotif()
            MEDIA_BIG -> {
                mediaExpanded = false
                handler.removeCallbacks(mediaCollapse)
                render()
            }
            MEDIA_SMALL -> {
                dismissedTitle = mediaTitle
                mediaVisible = false
                render()
            }
        }
    }

    private fun scheduleCollapse() {
        handler.removeCallbacks(mediaCollapse)
        handler.postDelayed(mediaCollapse, 8000)
    }

    // ------------------------------------------------------------------ notifications

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        handler.post { handlePosted(sbn) }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        handler.post {
            notifQueue.removeAll { it.key == sbn.key }
            val cur = currentNotif
            if (cur != null && cur.key == sbn.key) nextNotif()
        }
    }

    private fun handlePosted(sbn: StatusBarNotification) {
        try {
            if (!Prefs.on(this, Prefs.ENABLED)) return
            val n = sbn.notification ?: return
            if (sbn.packageName == packageName) return
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

            val cat = n.category
            val isCall = cat == Notification.CATEGORY_CALL
            val isAlarm = cat == Notification.CATEGORY_ALARM || cat == Notification.CATEGORY_REMINDER
            if (cat == Notification.CATEGORY_TRANSPORT ||
                cat == Notification.CATEGORY_PROGRESS ||
                cat == Notification.CATEGORY_SERVICE
            ) return
            val ex = n.extras
            if (ex != null && ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) return
            val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
            if (ongoing && !isCall) return

            if (isCall || isAlarm) {
                if (!Prefs.on(this, Prefs.CALLS)) return
            } else if (!Prefs.on(this, Prefs.NOTIFS)) {
                return
            }

            try {
                val rm = Ranking()
                if (currentRanking.getRanking(sbn.key, rm) &&
                    rm.importance < NotificationManager.IMPORTANCE_DEFAULT
                ) return
            } catch (e: Exception) {
            }

            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex?.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: ex?.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return

            val app = appLabel(sbn.packageName)
            val dedupe = sbn.key + "|" + title.hashCode() + "|" + text.hashCode()
            val now = SystemClock.elapsedRealtime()
            val last = recent[dedupe]
            if (last != null && now - last < 8000) return
            if (recent.size > 60) recent.clear()
            recent[dedupe] = now

            val hide = Prefs.on(this, Prefs.HIDE_TEXT)
            val icon: Drawable? = n.getLargeIcon()?.loadDrawable(this) ?: appIcon(sbn.packageName)

            val actions = ArrayList<Pair<String, PendingIntent>>()
            if (isCall) {
                val list = n.actions
                if (list != null) {
                    for (a in list) {
                        val pi = a.actionIntent
                        val t = a.title?.toString()
                        if (pi != null && t != null) actions.add(Pair(t, pi))
                    }
                }
            }
            val secs = if (isCall) 40 else if (isAlarm) 15
            else Prefs.int(this, Prefs.SECONDS, Prefs.DEFAULT_SECONDS)

            enqueue(
                NotifData(
                    sbn.key,
                    if (hide) app else title.ifEmpty { app },
                    if (hide) "New notification" else text,
                    app,
                    icon,
                    n.contentIntent,
                    actions,
                    isCall,
                    secs
                )
            )
        } catch (e: Exception) {
        }
    }

    private fun enqueue(d: NotifData) {
        if (d.isCall) notifQueue.addFirst(d) else notifQueue.addLast(d)
        while (notifQueue.size > 5) notifQueue.removeFirst()
        if (currentNotif == null || d.isCall) nextNotif()
    }

    private fun nextNotif() {
        handler.removeCallbacks(notifTimeout)
        val next = notifQueue.removeFirstOrNull()
        currentNotif = next
        if (next != null) {
            bindNotif(next)
            handler.postDelayed(notifTimeout, next.seconds * 1000L)
        }
        render(true)
    }

    private fun bindNotif(d: NotifData) {
        nIcon.setImageDrawable(d.icon)
        nApp.text = d.appName
        nTitle.text = d.title
        nText.text = d.text
        nText.visibility = if (d.text.isEmpty()) View.GONE else View.VISIBLE
        nActions.removeAllViews()
        if (d.actions.isEmpty()) {
            nActions.visibility = View.GONE
            return
        }
        nActions.visibility = View.VISIBLE
        val redWords = listOf("decline", "reject", "hang", "end", "dismiss", "ignore", "cancel")
        for ((i, action) in d.actions.take(2).withIndex()) {
            val name = action.first
            val pi = action.second
            val red = redWords.any { name.lowercase().contains(it) }
            val b = TextView(this)
            b.text = name
            b.textSize = 15f
            b.typeface = Typeface.DEFAULT_BOLD
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            val bg = GradientDrawable()
            bg.setColor(if (red) 0xFFFF453A.toInt() else 0xFF30D158.toInt())
            bg.cornerRadius = dp(22).toFloat()
            b.background = bg
            b.setOnClickListener {
                try {
                    pi.send()
                } catch (e: Exception) {
                }
                nextNotif()
            }
            val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
            if (i > 0) lp.marginStart = dp(10)
            nActions.addView(b, lp)
        }
    }

    // ------------------------------------------------------------------ music

    private fun startMediaWatching() {
        try {
            val cn = ComponentName(this, IslandListenerService::class.java)
            val sm = getSystemService(MediaSessionManager::class.java)
            sessionManager = sm
            sm.addOnActiveSessionsChangedListener(sessionListener, cn, handler)
            onSessions(sm.getActiveSessions(cn))
        } catch (e: Exception) {
        }
    }

    private fun stopMediaWatching() {
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionListener)
            controller?.unregisterCallback(controllerCallback)
        } catch (e: Exception) {
        }
        controller = null
        sessionManager = null
    }

    private fun onSessions(list: List<MediaController>) {
        val playing = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val keep = list.firstOrNull { it.sessionToken == controller?.sessionToken }
        val best = playing ?: keep ?: list.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(controllerCallback)
            controller = best
            best?.registerCallback(controllerCallback, handler)
            mediaVisible = false
        }
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        if (c == null) {
            mediaTitle = null
            mediaPlaying = false
            mediaVisible = false
            mediaExpanded = false
            render()
            return
        }
        val md = c.metadata
        val st = c.playbackState

        val newTitle = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val newArtist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        mediaDuration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val state = st?.state ?: PlaybackState.STATE_NONE
        val playing = state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING
        val trackChanged = newTitle != mediaTitle
        val wasPlaying = mediaPlaying

        mediaTitle = newTitle
        mediaArtist = newArtist
        if (art != null || trackChanged) {
            mediaArt = art
            accentColor = accentFrom(art)
        }
        mediaPlaying = playing

        if (trackChanged || (playing && !wasPlaying)) dismissedTitle = null

        if (playing) {
            if (dismissedTitle == null || dismissedTitle != newTitle) mediaVisible = true
            handler.removeCallbacks(mediaHide)
        } else if (state == PlaybackState.STATE_STOPPED || state == PlaybackState.STATE_NONE) {
            handler.removeCallbacks(mediaHide)
            mediaVisible = false
            mediaExpanded = false
        } else if (mediaVisible) {
            handler.removeCallbacks(mediaHide)
            handler.postDelayed(mediaHide, 12000)
        }

        bindMedia()
        render()
    }

    private fun bindMedia() {
        bigTitle.text = mediaTitle ?: ""
        bigArtist.text = mediaArtist ?: ""
        val art = mediaArt
        if (art != null) {
            smallArt.setImageBitmap(art)
            bigArt.setImageBitmap(art)
        } else {
            smallArt.setImageDrawable(ColorDrawable(0xFF3A3A3C.toInt()))
            bigArt.setImageDrawable(ColorDrawable(0xFF3A3A3C.toInt()))
        }
        smallEq.setColor(accentColor)
        bigEq.setColor(accentColor)
        progress.accent = accentColor
        btnPlay.kind = if (mediaPlaying) ControlIconView.PAUSE else ControlIconView.PLAY
        applyEq()
        updateProgress()
    }

    private fun applyEq() {
        val run = Prefs.on(this, Prefs.EQUALIZER) && mediaPlaying
        smallEq.setPlaying(run)
        bigEq.setPlaying(run)
    }

    private fun accentFrom(b: Bitmap?): Int {
        if (b == null) return Color.WHITE
        return try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            if (hsv[1] < 0.15f) {
                Color.WHITE
            } else {
                hsv[1] = max(hsv[1], 0.5f)
                hsv[2] = max(hsv[2], 0.9f)
                Color.HSVToColor(hsv)
            }
        } catch (e: Exception) {
            Color.WHITE
        }
    }

    private fun currentPosition(): Long {
        val st = controller?.playbackState ?: return 0L
        var pos = st.position
        if (pos < 0) pos = 0
        if (st.state == PlaybackState.STATE_PLAYING) {
            val delta = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
            pos += (delta * st.playbackSpeed).toLong()
        }
        if (mediaDuration > 0) pos = min(pos, mediaDuration)
        return max(pos, 0L)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val pos = currentPosition()
        if (!progress.dragging) {
            progress.fraction = if (mediaDuration > 0) pos.toFloat() / mediaDuration else 0f
        }
        tvElapsed.text = fmt(pos)
        tvTotal.text = if (mediaDuration > 0) fmt(mediaDuration) else "--:--"
    }

    // ------------------------------------------------------------------ used by the app screen

    fun demo() {
        handler.post {
            enqueue(
                NotifData(
                    "demo",
                    "Dynamic Island",
                    "This is how your notifications will look.",
                    "Island",
                    appIcon(packageName),
                    null,
                    emptyList(),
                    false,
                    5
                )
            )
        }
    }

    fun previewPosition() {
        handler.post {
            val cur = currentNotif
            if (cur != null && cur.key == "demo") {
                handler.removeCallbacks(notifTimeout)
                handler.postDelayed(notifTimeout, 3000)
            } else {
                demo()
            }
        }
    }
}
