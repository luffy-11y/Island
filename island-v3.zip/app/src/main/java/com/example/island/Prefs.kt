package com.example.island

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val ENABLED = "enabled"
    const val NOTIFS = "notifs"
    const val MEDIA = "media"
    const val CALLS = "calls"
    const val HIDE_TEXT = "hide_text"
    const val EQUALIZER = "equalizer"
    const val HAPTICS = "haptics"
    const val SECONDS = "seconds"
    const val TOP_DP = "top_dp"

    const val DEFAULT_TOP_DP = 36
    const val DEFAULT_SECONDS = 5

    fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("island_prefs", Context.MODE_PRIVATE)

    // Every switch is ON by default, except "hide text".
    fun on(ctx: Context, key: String): Boolean = sp(ctx).getBoolean(key, key != HIDE_TEXT)

    fun int(ctx: Context, key: String, def: Int): Int = sp(ctx).getInt(key, def)
}
