package com.example.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

class IslandService : Service() {

    // ---- Tweak these numbers to fit your phone (all in dp) ----
    private val collapsedWidthDp = 110f
    private val collapsedHeightDp = 32f
    private val expandedWidthDp = 340f
    private val expandedHeightDp = 110f
    private val topOffsetDp = 6f
    // -----------------------------------------------------------

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var pillBg: GradientDrawable
    private lateinit var content: LinearLayout
    private var root: FrameLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private val holder = FloatValueHolder(0f)
    private val autoCollapse = Runnable { setExpanded(false) }

    private val anim = SpringAnimation(holder).apply {
        setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE)
        setSpring(SpringForce(0f).setDampingRatio(0.55f).setStiffness(350f))
        addUpdateListener { _, value, _ -> applyProgress(value) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) {
            addIsland()
            // Small demo: pop open shortly after starting
            handler.postDelayed({ setExpanded(true) }, 700)
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Island service", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, "island")
            .setContentTitle("Island is running")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun addIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        pillBg = GradientDrawable().apply {
            setColor(Color.BLACK)
            cornerRadius = dp(collapsedHeightDp) / 2f
        }

        val title = TextView(this).apply {
            text = "Dynamic Island"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        val sub = TextView(this).apply {
            text = "Tap to collapse"
            setTextColor(0xFFAAAAAA.toInt())
            textSize = 13f
            maxLines = 1
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f
            addView(title)
            addView(sub)
        }

        val container = FrameLayout(this).apply {
            background = pillBg
            addView(
                content,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            setOnClickListener { setExpanded(holder.value < 0.5f) }
        }

        params = WindowManager.LayoutParams(
            dp(collapsedWidthDp).toInt(),
            dp(collapsedHeightDp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(topOffsetDp).toInt()
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        wm.addView(container, params)
        root = container
    }

    private fun setExpanded(open: Boolean) {
        handler.removeCallbacks(autoCollapse)
        anim.animateToFinalPosition(if (open) 1f else 0f)
        if (open) handler.postDelayed(autoCollapse, 4000)
    }

    // p = 0 is the small pill, p = 1 is fully expanded. The spring overshoots a bit, which gives the bounce.
    private fun applyProgress(p: Float) {
        val view = root ?: return
        val w = lerp(dp(collapsedWidthDp), dp(expandedWidthDp), p)
            .coerceAtLeast(dp(collapsedWidthDp) * 0.8f)
        val h = lerp(dp(collapsedHeightDp), dp(expandedHeightDp), p)
            .coerceAtLeast(dp(collapsedHeightDp) * 0.8f)
        val t = p.coerceIn(0f, 1f)
        val corner = lerp(dp(collapsedHeightDp) / 2f, dp(30f), t)

        pillBg.cornerRadius = minOf(corner, h / 2f)
        content.alpha = ((p - 0.55f) / 0.45f).coerceIn(0f, 1f)
        params.width = w.toInt()
        params.height = h.toInt()
        wm.updateViewLayout(view, params)
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (anim.isRunning) anim.cancel()
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }
}
