package com.example.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class IslandListenerService : NotificationListenerService() {

    enum class Mode {
        HIDDEN,
        IDLE_PILL,
        MEDIA_SMALL,
        MEDIA_BIG,
        TIMER_SMALL,
        NOTIF,
        CALL,
        SYSTEM_HUD
    }

    data class ActionBtn(
        val label: String,
        val intent: PendingIntent?,
        val isPositive: Boolean = false,
        val isNegative: Boolean = false
    )

    data class IslandItem(
        val key: String,
        val pkg: String,
        val appName: String,
        val title: String,
        val text: String,
        val icon: Drawable?,
        val largeBitmap: Bitmap?,
        val contentIntent: PendingIntent?,
        val actions: List<ActionBtn>,
        val isCall: Boolean,
        val isTimer: Boolean,
        val chronometerBase: Long,
        val chronometerCountDown: Boolean,
        val whenMs: Long,
        val durationMs: Long,
        val accentColor: Int
    )

    data class SystemHudData(
        val title: String,
        val subtitle: String,
        val accentColor: Int,
        val hudKind: Int, // 0 = battery, 1 = bluetooth, 2 = ringer
        val batteryLevel: Int = 0,
        val isCharging: Boolean = false,
        val ringerKind: Int = ControlIconView.KIND_RINGER_NORMAL
    )

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var lp: WindowManager.LayoutParams? = null
    private var rootContainer: IslandContainerView? = null
    private var contentFrame: FrameLayout? = null
    private var windowAdded = false

    private var currentMode: Mode = Mode.HIDDEN
    private var currentWidthPx: Float = 0f
    private var currentHeightPx: Float = 0f
    private var widthSpring: SpringAnimation? = null
    private var heightSpring: SpringAnimation? = null

    // Notification & Call Queue
    private val notifQueue = ArrayDeque<IslandItem>()
    private var activeItem: IslandItem? = null
    private val recentSignatures = HashMap<String, Long>()
    private var activeTimerItem: IslandItem? = null

    // System HUD state
    private var activeHud: SystemHudData? = null
    private var lastChargingState: Boolean? = null

    // Media Session state
    private var mediaSessionManager: MediaSessionManager? = null
    private var activeController: MediaController? = null
    private var mediaTitle: String = ""
    private var mediaArtist: String = ""
    private var mediaArt: Bitmap? = null
    private var mediaAccent: Int = 0xFF30D158.toInt()
    private var mediaPlaying: Boolean = false
    private var mediaDuration: Long = 0L
    private var mediaPosition: Long = 0L
    private var mediaLastStateTime: Long = 0L
    private var mediaDismissedUntilChange: Boolean = false
    private var lastTrackSignature: String = ""

    // Live UI references for fast updates without rebuilding layouts
    private var liveSeekLine: ProgressLine? = null
    private var liveElapsedTv: TextView? = null
    private var liveTotalTv: TextView? = null
    private var liveEqualizerSmall: EqualizerView? = null
    private var liveEqualizerBig: EqualizerView? = null
    private var livePlayPauseIcon: ControlIconView? = null
    private var liveTimerTextSmall: TextView? = null
    private var liveTimerTextBig: TextView? = null
    private var spinAnimator: ValueAnimator? = null

    // Scheduled Runnables
    private val autoDismissRunnable = Runnable { onItemTimeout() }
    private val mediaCollapseRunnable = Runnable {
        if (currentMode == Mode.MEDIA_BIG) {
            decideNextState()
        }
    }
    private val mediaPauseHideRunnable = Runnable {
        if (!mediaPlaying && (currentMode == Mode.MEDIA_SMALL || currentMode == Mode.MEDIA_BIG)) {
            decideNextState()
        }
    }
    private val hudHideRunnable = Runnable {
        activeHud = null
        decideNextState()
    }
    private val tickerRunnable = object : Runnable {
        override fun run() {
            updateLiveTickers()
            if (windowAdded && currentMode != Mode.HIDDEN) {
                handler.postDelayed(this, 500L)
            }
        }
    }

    private val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
        bindMediaControllers(controllers)
    }

    private val mediaCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            readMediaState()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMediaState()
        }
    }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            when (action) {
                Prefs.ACTION_PREFS_CHANGED -> {
                    applyWindowPositionAndStyle()
                    decideNextState()
                }
                Prefs.ACTION_PREVIEW -> {
                    val kind = intent.getStringExtra(Prefs.EXTRA_PREVIEW_TYPE) ?: "notif"
                    triggerPreview(kind)
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    if (!Prefs.isBattery(this@IslandListenerService)) return
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                    val pct = (level * 100) / scale
                    if (lastChargingState == null) {
                        lastChargingState = charging
                    } else if (lastChargingState != charging) {
                        lastChargingState = charging
                        if (charging) {
                            showSystemHud(
                                SystemHudData(
                                    title = "Charging",
                                    subtitle = "$pct% Battery",
                                    accentColor = 0xFF30D158.toInt(),
                                    hudKind = 0,
                                    batteryLevel = pct,
                                    isCharging = true
                                )
                            )
                        }
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    if (!Prefs.isBluetooth(this@IslandListenerService)) return
                    val devName = try {
                        val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        dev?.name ?: "Audio Device"
                    } catch (_: SecurityException) {
                        "Bluetooth Device"
                    } catch (_: Throwable) {
                        "Bluetooth Device"
                    }
                    showSystemHud(
                        SystemHudData(
                            title = devName,
                            subtitle = "Connected",
                            accentColor = 0xFF32ADE6.toInt(),
                            hudKind = 1
                        )
                    )
                }
                Intent.ACTION_HEADSET_PLUG -> {
                    if (!Prefs.isBluetooth(this@IslandListenerService)) return
                    val state = intent.getIntExtra("state", 0)
                    if (state == 1 && !isInitialStickyBroadcast) {
                        showSystemHud(
                            SystemHudData(
                                title = "Headphones",
                                subtitle = "Audio Jack Connected",
                                accentColor = 0xFF32ADE6.toInt(),
                                hudKind = 1
                            )
                        )
                    }
                }
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    if (!Prefs.isRinger(this@IslandListenerService) || isInitialStickyBroadcast) return
                    val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                    when (am.ringerMode) {
                        AudioManager.RINGER_MODE_SILENT -> showSystemHud(
                            SystemHudData(
                                title = "Silent Mode",
                                subtitle = "Bell Muted",
                                accentColor = 0xFFFF453A.toInt(),
                                hudKind = 2,
                                ringerKind = ControlIconView.KIND_RINGER_SILENT
                            )
                        )
                        AudioManager.RINGER_MODE_VIBRATE -> showSystemHud(
                            SystemHudData(
                                title = "Vibrate Mode",
                                subtitle = "Haptics Active",
                                accentColor = 0xFFFF9F0A.toInt(),
                                hudKind = 2,
                                ringerKind = ControlIconView.KIND_RINGER_VIBRATE
                            )
                        )
                        AudioManager.RINGER_MODE_NORMAL -> showSystemHud(
                            SystemHudData(
                                title = "Ring Mode",
                                subtitle = "Sound On",
                                accentColor = 0xFF30D158.toInt(),
                                hudKind = 2,
                                ringerKind = ControlIconView.KIND_RINGER_NORMAL
                            )
                        )
                    }
                }
                Intent.ACTION_CONFIGURATION_CHANGED -> {
                    decideNextState()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        registerReceivers()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        setupMediaSessions()
        decideNextState()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(systemReceiver)
        } catch (_: Throwable) {}
        try {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(sessionListener)
            activeController?.unregisterCallback(mediaCallback)
        } catch (_: Throwable) {}
        removeOverlayImmediate()
        super.onDestroy()
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(Prefs.ACTION_PREFS_CHANGED)
            addAction(Prefs.ACTION_PREVIEW)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(Intent.ACTION_CONFIGURATION_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(systemReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(systemReceiver, filter)
        }
    }

    private fun setupMediaSessions() {
        try {
            mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
            val comp = ComponentName(this, IslandListenerService::class.java)
            mediaSessionManager?.addOnActiveSessionsChangedListener(sessionListener, comp)
            val initial = mediaSessionManager?.getActiveSessions(comp)
            bindMediaControllers(initial)
        } catch (_: Throwable) {}
    }

    private fun bindMediaControllers(controllers: List<MediaController>?) {
        try {
            activeController?.unregisterCallback(mediaCallback)
        } catch (_: Throwable) {}
        activeController = null
        if (controllers.isNullOrEmpty()) {
            mediaPlaying = false
            decideNextState()
            return
        }
        // Prefer a controller that is actively playing, or fall back to the first one
        val chosen = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.firstOrNull()
        activeController = chosen
        try {
            chosen?.registerCallback(mediaCallback, handler)
        } catch (_: Throwable) {}
        readMediaState()
    }

    private fun readMediaState() {
        val ctrl = activeController
        if (ctrl == null) {
            mediaPlaying = false
            decideNextState()
            return
        }
        val state = ctrl.playbackState
        val isNowPlaying = state?.state == PlaybackState.STATE_PLAYING ||
                state?.state == PlaybackState.STATE_BUFFERING
        mediaPosition = state?.position ?: 0L
        mediaLastStateTime = state?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime()

        val meta = ctrl.metadata
        val newTitle = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: ""
        val newArtist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
            ?: ""
        mediaDuration = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val bmp = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) {
            mediaArt = bmp
            mediaAccent = extractDominantColor(bmp, 0xFF30D158.toInt())
        }

        val sig = "$newTitle|$newArtist"
        if (sig != lastTrackSignature || (!mediaPlaying && isNowPlaying)) {
            mediaDismissedUntilChange = false
            lastTrackSignature = sig
        }
        val wasPlaying = mediaPlaying
        mediaTitle = newTitle
        mediaArtist = newArtist
        mediaPlaying = isNowPlaying

        handler.removeCallbacks(mediaPauseHideRunnable)
        if (!mediaPlaying && wasPlaying) {
            handler.postDelayed(mediaPauseHideRunnable, 12_000L)
        }

        if (currentMode == Mode.MEDIA_SMALL || currentMode == Mode.MEDIA_BIG) {
            liveEqualizerSmall?.isPlaying = mediaPlaying
            liveEqualizerBig?.isPlaying = mediaPlaying
            livePlayPauseIcon?.kind = if (mediaPlaying) ControlIconView.KIND_PAUSE else ControlIconView.KIND_PLAY
            livePlayPauseIcon?.invalidate()
        }
        decideNextState()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!Prefs.isEnabled(this) || !Settings.canDrawOverlays(this)) return

        val pkg = sbn.packageName ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (Prefs.isAppBlocked(this, pkg)) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        // Skip media-style notifications (handled natively via MediaSessionManager)
        val extras = n.extras
        if (extras != null && (extras.containsKey(Notification.EXTRA_MEDIA_SESSION) ||
                    n.category == Notification.CATEGORY_TRANSPORT)) {
            return
        }

        val category = n.category ?: ""
        val isCall = category == Notification.CATEGORY_CALL ||
                (sbn.isOngoing && (category == Notification.CATEGORY_CALL || hasCallActions(n)))
        val isAlarm = category == Notification.CATEGORY_ALARM || category == Notification.CATEGORY_REMINDER
        val showChrono = extras?.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false) == true
        val isTimer = showChrono && n. `when` > 0L

        if (isTimer && Prefs.isTimers(this)) {
            activeTimerItem = buildIslandItem(sbn, isCall = false, isTimer = true, durationMs = 0L)
            decideNextState()
            return
        }

        // Skip ongoing background services unless it's a call, alarm, or live timer
        if (sbn.isOngoing && !isCall && !isAlarm) return
        if (category == Notification.CATEGORY_SERVICE || category == Notification.CATEGORY_PROGRESS) return

        // Check user module toggles
        if (isCall && !Prefs.isCalls(this)) return
        if (!isCall && !Prefs.isNotifs(this)) return

        // Importance check
        val ranking = Ranking()
        if (currentRanking != null && currentRanking.getRanking(sbn.key, ranking)) {
            if (ranking.importance < android.app.NotificationManager.IMPORTANCE_DEFAULT && !isCall && !isAlarm) {
                return
            }
        }

        val item = buildIslandItem(
            sbn = sbn,
            isCall = isCall,
            isTimer = false,
            durationMs = when {
                isCall -> 40_000L
                isAlarm -> 15_000L
                else -> Prefs.getSeconds(this) * 1000L
            }
        )
        if (item.title.isBlank() && item.text.isBlank() && !isCall) return

        // Deduplicate within 8 seconds
        val now = SystemClock.elapsedRealtime()
        val sig = "${item.pkg}|${item.title}|${item.text}"
        val lastTime = recentSignatures[sig]
        if (lastTime != null && now - lastTime < 8_000L && !isCall) {
            return
        }
        recentSignatures[sig] = now

        enqueueItem(item)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (activeTimerItem?.key == sbn.key) {
            activeTimerItem = null
        }
        notifQueue.removeAll { it.key == sbn.key }
        if (activeItem?.key == sbn.key) {
            handler.removeCallbacks(autoDismissRunnable)
            activeItem = null
        }
        decideNextState()
    }

    private fun hasCallActions(n: Notification): Boolean {
        val acts = n.actions ?: return false
        if (acts.size < 2) return false
        val labels = acts.mapNotNull { it.title?.toString()?.lowercase() }
        return labels.any { it.contains("answer") || it.contains("accept") } &&
                labels.any { it.contains("decline") || it.contains("reject") || it.contains("hang") }
    }

    private fun buildIslandItem(
        sbn: StatusBarNotification,
        isCall: Boolean,
        isTimer: Boolean,
        durationMs: Long
    ): IslandItem {
        val n = sbn.notification
        val ex = n.extras
        val pkg = sbn.packageName

        val appName = try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Throwable) {
            pkg.substringAfterLast('.')
        }

        val rawTitle = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: ex?.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
            ?: appName
        val rawText = ex?.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: ex?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: ex?.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
            ?: ""

        val iconDrawable: Drawable? = try {
            n.smallIcon?.loadDrawable(this) ?: packageManager.getApplicationIcon(pkg)
        } catch (_: Throwable) {
            null
        }

        val largeBmp: Bitmap? = try {
            val lgIcon = n.getLargeIcon()
            val dr = lgIcon?.loadDrawable(this)
            drawableToBitmap(dr)
        } catch (_: Throwable) {
            null
        }

        val actionsList = mutableListOf<ActionBtn>()
        n.actions?.take(3)?.forEach { act ->
            val lbl = act.title?.toString()?.trim() ?: ""
            if (lbl.isNotEmpty()) {
                val low = lbl.lowercase()
                val pos = low.contains("answer") || low.contains("accept")
                val neg = low.contains("decline") || low.contains("reject") || low.contains("dismiss") || low.contains("stop")
                actionsList.add(ActionBtn(lbl, act.actionIntent, pos, neg))
            }
        }

        val countDown = if (Build.VERSION.SDK_INT >= 24) {
            ex?.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN, false) ?: false
        } else {
            false
        }

        val dynColor = if (n.color != 0) {
            n.color or 0xFF000000.toInt()
        } else if (largeBmp != null) {
            extractDominantColor(largeBmp, 0xFF5E5CE6.toInt())
        } else {
            0xFF5E5CE6.toInt()
        }

        return IslandItem(
            key = sbn.key,
            pkg = pkg,
            appName = appName,
            title = rawTitle,
            text = if (Prefs.isHideText(this) && !isCall && !isTimer) "Notification hidden" else rawText,
            icon = iconDrawable,
            largeBitmap = largeBmp,
            contentIntent = n.contentIntent,
            actions = actionsList,
            isCall = isCall,
            isTimer = isTimer,
            chronometerBase = n.`when`,
            chronometerCountDown = countDown,
            whenMs = n.`when`,
            durationMs = durationMs,
            accentColor = Prefs.resolveAccentColor(this, dynColor)
        )
    }

    private fun enqueueItem(item: IslandItem) {
        if (item.isCall) {
            // Calls jump straight to the front
            activeItem?.let { notifQueue.addFirst(it) }
            activeItem = item
            scheduleAutoDismiss(item.durationMs)
            hapticTick()
            decideNextState(forceRebuild = true)
            return
        }

        if (activeItem == null) {
            activeItem = item
            scheduleAutoDismiss(item.durationMs)
            hapticTick()
            decideNextState(forceRebuild = true)
        } else {
            if (notifQueue.size >= 5) {
                notifQueue.removeLast()
            }
            notifQueue.addLast(item)
        }
    }

    private fun scheduleAutoDismiss(ms: Long) {
        handler.removeCallbacks(autoDismissRunnable)
        if (ms > 0L) {
            handler.postDelayed(autoDismissRunnable, ms)
        }
    }

    private fun onItemTimeout() {
        activeItem = notifQueue.removeFirstOrNull()
        if (activeItem != null) {
            scheduleAutoDismiss(activeItem!!.durationMs)
            hapticTick()
            decideNextState(forceRebuild = true)
        } else {
            decideNextState()
        }
    }

    private fun showSystemHud(hud: SystemHudData) {
        if (!Prefs.isEnabled(this) || !Settings.canDrawOverlays(this)) return
        activeHud = hud
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 3_200L)
        hapticTick()
        decideNextState(forceRebuild = true)
    }

    private fun triggerPreview(kind: String) {
        if (!Settings.canDrawOverlays(this)) return
        when (kind) {
            "music" -> {
                mediaTitle = "Starboy (Galaxy A52s Mix)"
                mediaArtist = "The Weeknd & Daft Punk"
                mediaPlaying = true
                mediaDuration = 230_000L
                mediaPosition = 78_000L
                mediaLastStateTime = SystemClock.elapsedRealtime()
                mediaAccent = Prefs.resolveAccentColor(this, 0xFF30D158.toInt())
                mediaDismissedUntilChange = false
                currentMode = Mode.HIDDEN
                hapticTick()
                transitionToMode(Mode.MEDIA_BIG, forceRebuild = true)
                handler.removeCallbacks(mediaCollapseRunnable)
                handler.postDelayed(mediaCollapseRunnable, 8_000L)
            }
            "call" -> {
                val fakeCall = IslandItem(
                    key = "preview_call_${SystemClock.elapsedRealtime()}",
                    pkg = packageName,
                    appName = "Phone",
                    title = "Alex Rivera",
                    text = "Incoming Mobile Call • HD Voice",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = listOf(
                        ActionBtn("Decline", null, isPositive = false, isNegative = true),
                        ActionBtn("Answer", null, isPositive = true, isNegative = false)
                    ),
                    isCall = true,
                    isTimer = false,
                    chronometerBase = 0L,
                    chronometerCountDown = false,
                    whenMs = System.currentTimeMillis(),
                    durationMs = 8_000L,
                    accentColor = 0xFF30D158.toInt()
                )
                enqueueItem(fakeCall)
            }
            "battery" -> {
                showSystemHud(
                    SystemHudData(
                        title = "Super Fast Charging",
                        subtitle = "88% Charged",
                        accentColor = 0xFF30D158.toInt(),
                        hudKind = 0,
                        batteryLevel = 88,
                        isCharging = true
                    )
                )
            }
            "timer" -> {
                val fakeTimer = IslandItem(
                    key = "preview_timer",
                    pkg = packageName,
                    appName = "Clock",
                    title = "Timer",
                    text = "Countdown active",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = emptyList(),
                    isCall = false,
                    isTimer = true,
                    chronometerBase = System.currentTimeMillis() + 145_000L,
                    chronometerCountDown = true,
                    whenMs = System.currentTimeMillis() + 145_000L,
                    durationMs = 9_000L,
                    accentColor = 0xFFFF9F0A.toInt()
                )
                activeTimerItem = fakeTimer
                hapticTick()
                decideNextState(forceRebuild = true)
                handler.postDelayed({
                    if (activeTimerItem?.key == "preview_timer") {
                        activeTimerItem = null
                        decideNextState()
                    }
                }, 9_000L)
            }
            else -> {
                val fakeNotif = IslandItem(
                    key = "preview_notif_${SystemClock.elapsedRealtime()}",
                    pkg = packageName,
                    appName = "Island",
                    title = "Galaxy A52s Calibrated",
                    text = "Your Dynamic Island is lined up and ready! Tap or swipe up to test gestures.",
                    icon = null,
                    largeBitmap = null,
                    contentIntent = null,
                    actions = if (Prefs.isQuickReplies(this)) {
                        listOf(ActionBtn("Awesome", null), ActionBtn("Dismiss", null))
                    } else emptyList(),
                    isCall = false,
                    isTimer = false,
                    chronometerBase = 0L,
                    chronometerCountDown = false,
                    whenMs = System.currentTimeMillis(),
                    durationMs = Prefs.getSeconds(this) * 1000L,
                    accentColor = Prefs.resolveAccentColor(this, 0xFF5E5CE6.toInt())
                )
                enqueueItem(fakeNotif)
            }
        }
    }

    private fun decideNextState(forceRebuild: Boolean = false) {
        if (!Prefs.isEnabled(this) || !Settings.canDrawOverlays(this)) {
            transitionToMode(Mode.HIDDEN)
            return
        }

        if (Prefs.isHideLandscape(this) &&
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        ) {
            transitionToMode(Mode.HIDDEN)
            return
        }

        val desiredMode = when {
            activeItem != null && activeItem!!.isCall -> Mode.CALL
            activeItem != null -> Mode.NOTIF
            activeHud != null -> Mode.SYSTEM_HUD
            Prefs.isMedia(this) && !mediaDismissedUntilChange &&
                    (mediaPlaying || currentMode == Mode.MEDIA_BIG) &&
                    mediaTitle.isNotEmpty() -> {
                if (currentMode == Mode.MEDIA_BIG) Mode.MEDIA_BIG else Mode.MEDIA_SMALL
            }
            activeTimerItem != null && Prefs.isTimers(this) -> Mode.TIMER_SMALL
            Prefs.isIdlePill(this) -> Mode.IDLE_PILL
            else -> Mode.HIDDEN
        }

        transitionToMode(desiredMode, forceRebuild)
    }

    private fun getDimensionsForMode(mode: Mode): Pair<Int, Int> {
        val scale = Prefs.getScalePct(this) / 100f
        fun sDp(v: Float): Int = dp(v * scale)

        return when (mode) {
            Mode.HIDDEN -> Pair(sDp(36f), sDp(26f))
            Mode.IDLE_PILL -> Pair(sDp(116f), sDp(30f))
            Mode.MEDIA_SMALL -> Pair(sDp(186f), sDp(36f))
            Mode.TIMER_SMALL -> Pair(sDp(164f), sDp(36f))
            Mode.SYSTEM_HUD -> Pair(sDp(224f), sDp(44f))
            Mode.MEDIA_BIG -> Pair(sDp(348f), sDp(178f))
            Mode.CALL -> Pair(sDp(348f), sDp(132f))
            Mode.NOTIF -> {
                val hasActions = Prefs.isQuickReplies(this) && (activeItem?.actions?.isNotEmpty() == true)
                Pair(sDp(346f), if (hasActions) sDp(138f) else sDp(96f))
            }
        }
    }

    private fun ensureOverlayCreated() {
        if (windowAdded && rootContainer != null) return
        val windowManager = wm ?: return

        val container = IslandContainerView(this).apply {
            showGlowBorder = Prefs.isGlowBorder(this@IslandListenerService)
            pillAlphaPct = Prefs.getOpacityPct(this@IslandListenerService)
        }
        val frame = FrameLayout(this)
        container.addView(
            frame,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        attachGestureHandler(container)

        val initW = dp(116f)
        val initH = dp(30f)
        currentWidthPx = initW.toFloat()
        currentHeightPx = initH.toFloat()

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

        val params = WindowManager.LayoutParams(
            initW,
            initH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = dp(Prefs.getOffsetXDp(this@IslandListenerService).toFloat())
            y = computeTargetY()
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            windowManager.addView(container, params)
            rootContainer = container
            contentFrame = frame
            lp = params
            windowAdded = true
            setupSprings()
        } catch (_: Throwable) {
            windowAdded = false
        }
    }

    private fun computeTargetY(): Int {
        val rawTopDp = Prefs.getTopDp(this)
        return dp(rawTopDp.toFloat())
    }

    private fun applyWindowPositionAndStyle() {
        val container = rootContainer ?: return
        val params = lp ?: return
        val windowManager = wm ?: return

        container.showGlowBorder = Prefs.isGlowBorder(this)
        container.pillAlphaPct = Prefs.getOpacityPct(this)
        params.x = dp(Prefs.getOffsetXDp(this).toFloat())
        params.y = computeTargetY()

        val (targetW, targetH) = getDimensionsForMode(currentMode)
        setupSprings()
        widthSpring?.animateToFinalPosition(targetW.toFloat())
        heightSpring?.animateToFinalPosition(targetH.toFloat())

        if (windowAdded) {
            try {
                windowManager.updateViewLayout(container, params)
            } catch (_: Throwable) {}
        }
    }

    private fun setupSprings() {
        val style = Prefs.getSpringStyle(this)
        val (dampingW, stiffW, dampingH, stiffH) = when (style) {
            0 -> listOf(0.62f, 360f, 0.72f, 410f) // Bouncy iOS style
            1 -> listOf(0.78f, 440f, 0.82f, 480f) // Balanced
            else -> listOf(0.92f, 650f, 0.94f, 700f) // Snappy
        }

        val wHolder = FloatValueHolder(currentWidthPx)
        widthSpring = SpringAnimation(wHolder).apply {
            spring = SpringForce().apply {
                dampingRatio = dampingW
                stiffness = stiffW
            }
            addUpdateListener { _, value, _ ->
                currentWidthPx = value
                updateOverlaySize()
            }
        }

        val hHolder = FloatValueHolder(currentHeightPx)
        heightSpring = SpringAnimation(hHolder).apply {
            spring = SpringForce().apply {
                dampingRatio = dampingH
                stiffness = stiffH
            }
            addUpdateListener { _, value, _ ->
                currentHeightPx = value
                updateOverlaySize()
            }
        }
    }

    private fun updateOverlaySize() {
        val container = rootContainer ?: return
        val params = lp ?: return
        val windowManager = wm ?: return
        if (!windowAdded) return

        val w = currentWidthPx.toInt().coerceAtLeast(dp(24f))
        val h = currentHeightPx.toInt().coerceAtLeast(dp(20f))
        params.width = w
        params.height = h
        val maxRadius = dpF(34f)
        container.cornerRadiusPx = min(h / 2f, maxRadius)

        try {
            windowManager.updateViewLayout(container, params)
        } catch (_: Throwable) {}
    }

    private fun transitionToMode(newMode: Mode, forceRebuild: Boolean = false) {
        if (newMode == Mode.HIDDEN) {
            if (!windowAdded) {
                currentMode = Mode.HIDDEN
                return
            }
            currentMode = Mode.HIDDEN
            val (hideW, hideH) = getDimensionsForMode(Mode.HIDDEN)
            widthSpring?.animateToFinalPosition(hideW.toFloat())
            heightSpring?.animateToFinalPosition(hideH.toFloat())
            rootContainer?.animate()?.alpha(0f)?.setDuration(180L)?.withEndAction {
                if (currentMode == Mode.HIDDEN) {
                    removeOverlayImmediate()
                }
            }?.start()
            return
        }

        ensureOverlayCreated()
        if (!windowAdded) return

        rootContainer?.animate()?.cancel()
        rootContainer?.alpha = 1f

        val modeChanged = currentMode != newMode
        currentMode = newMode

        val accent = when (newMode) {
            Mode.CALL, Mode.NOTIF -> activeItem?.accentColor ?: 0xFF5E5CE6.toInt()
            Mode.MEDIA_SMALL, Mode.MEDIA_BIG -> Prefs.resolveAccentColor(this, mediaAccent)
            Mode.SYSTEM_HUD -> activeHud?.accentColor ?: 0xFF30D158.toInt()
            Mode.TIMER_SMALL -> 0xFFFF9F0A.toInt()
            else -> Prefs.resolveAccentColor(this, 0xFF5E5CE6.toInt())
        }
        rootContainer?.glowColor = accent

        val (targetW, targetH) = getDimensionsForMode(newMode)
        setupSprings()
        widthSpring?.animateToFinalPosition(targetW.toFloat())
        heightSpring?.animateToFinalPosition(targetH.toFloat())

        if (modeChanged || forceRebuild) {
            rebuildContentForMode(newMode)
        }

        handler.removeCallbacks(tickerRunnable)
        handler.post(tickerRunnable)
    }

    private fun removeOverlayImmediate() {
        spinAnimator?.cancel()
        val container = rootContainer
        if (windowAdded && container != null) {
            try {
                wm?.removeViewImmediate(container)
            } catch (_: Throwable) {}
        }
        windowAdded = false
        rootContainer = null
        contentFrame = null
        lp = null
    }

    private fun rebuildContentForMode(mode: Mode) {
        val frame = contentFrame ?: return
        spinAnimator?.cancel()
        liveSeekLine = null
        liveElapsedTv = null
        liveTotalTv = null
        liveEqualizerSmall = null
        liveEqualizerBig = null
        livePlayPauseIcon = null
        liveTimerTextSmall = null
        liveTimerTextBig = null

        val newView: View = when (mode) {
            Mode.IDLE_PILL -> buildIdlePillView()
            Mode.MEDIA_SMALL -> buildMediaSmallView()
            Mode.MEDIA_BIG -> buildMediaBigView()
            Mode.TIMER_SMALL -> buildTimerSmallView()
            Mode.SYSTEM_HUD -> buildSystemHudView()
            Mode.CALL -> buildCallView()
            Mode.NOTIF -> buildNotifView()
            Mode.HIDDEN -> View(this)
        }

        // Cross-fade with subtle zoom
        for (i in 0 until frame.childCount) {
            val old = frame.getChildAt(i)
            old.animate()
                .alpha(0f)
                .scaleX(0.88f)
                .scaleY(0.88f)
                .setDuration(130L)
                .withEndAction { frame.removeView(old) }
                .start()
        }

        newView.alpha = 0f
        newView.scaleX = 0.90f
        newView.scaleY = 0.90f
        frame.addView(
            newView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        newView.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(190L)
            .start()
    }

    private fun buildIdlePillView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12f), 0, dp(12f), 0)
        }
        // Subtle status dot on the left, camera hole space in center, subtle accent dot on right
        val leftDot = View(this).apply {
            background = roundedBg(0xFF282A36.toInt(), dpF(4f))
            layoutParams = LinearLayout.LayoutParams(dp(7f), dp(7f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val rightDot = View(this).apply {
            val col = Prefs.resolveAccentColor(this@IslandListenerService, 0xFF5E5CE6.toInt())
            background = roundedBg(col, dpF(4f))
            alpha = 0.65f
            layoutParams = LinearLayout.LayoutParams(dp(6f), dp(6f))
        }
        row.addView(leftDot)
        row.addView(spacer)
        row.addView(rightDot)
        return row
    }

    private fun buildMediaSmallView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9f), 0, dp(11f), 0)
        }

        val artIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(dpF(11f))
            if (mediaArt != null) {
                setImageBitmap(mediaArt)
            } else {
                background = roundedBg(0xFF252836.toInt(), dpF(11f))
            }
            layoutParams = LinearLayout.LayoutParams(dp(22f), dp(22f))
        }
        if (Prefs.isSpinArt(this) && mediaPlaying) {
            startSpinAnimation(artIv)
        }
        row.addView(artIv)

        // Center spacer leaves room for the centered Galaxy A52s camera cutout
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        row.addView(spacer)

        val eq = EqualizerView(this, barCount = 4).apply {
            barColor = Prefs.resolveAccentColor(this@IslandListenerService, mediaAccent)
            isPlaying = mediaPlaying && Prefs.isEqualizer(this@IslandListenerService)
            layoutParams = LinearLayout.LayoutParams(dp(22f), dp(16f))
        }
        liveEqualizerSmall = eq
        row.addView(eq)
        return row
    }

    private fun buildMediaBigView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(20f), dp(18f), dp(14f))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val artIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(dpF(14f))
            if (mediaArt != null) {
                setImageBitmap(mediaArt)
            } else {
                background = roundedBg(0xFF252836.toInt(), dpF(14f))
            }
            layoutParams = LinearLayout.LayoutParams(dp(54f), dp(54f))
        }
        topRow.addView(artIv)

        val metaCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(13f)
                rightMargin = dp(10f)
            }
        }

        val titleTv = TextView(this).apply {
            text = mediaTitle.ifEmpty { "Playing Media" }
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val artistTv = TextView(this).apply {
            text = mediaArtist.ifEmpty { "Unknown Artist" }
            setTextColor(0xFFB0B0B8.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        metaCol.addView(titleTv)
        metaCol.addView(artistTv)
        topRow.addView(metaCol)

        val eq = EqualizerView(this, barCount = 5).apply {
            barColor = Prefs.resolveAccentColor(this@IslandListenerService, mediaAccent)
            isPlaying = mediaPlaying && Prefs.isEqualizer(this@IslandListenerService)
            layoutParams = LinearLayout.LayoutParams(dp(28f), dp(22f))
        }
        liveEqualizerBig = eq
        topRow.addView(eq)
        root.addView(topRow)

        // Progress row
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12f)
            }
        }

        val elapsedTv = TextView(this).apply {
            text = formatMs(mediaPosition)
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        }
        liveElapsedTv = elapsedTv
        seekRow.addView(elapsedTv)

        val seekBar = ProgressLine(this).apply {
            activeColor = Prefs.resolveAccentColor(this@IslandListenerService, mediaAccent)
            progress = if (mediaDuration > 0L) (mediaPosition.toFloat() / mediaDuration.toFloat()) else 0f
            layoutParams = LinearLayout.LayoutParams(0, dp(20f), 1f).apply {
                leftMargin = dp(8f)
                rightMargin = dp(8f)
            }
            onSeek = { ratio ->
                if (mediaDuration > 0L) {
                    val targetPos = (ratio * mediaDuration).toLong()
                    try {
                        activeController?.transportControls?.seekTo(targetPos)
                        mediaPosition = targetPos
                        mediaLastStateTime = SystemClock.elapsedRealtime()
                    } catch (_: Throwable) {}
                }
                resetMediaCollapseTimer()
            }
        }
        liveSeekLine = seekBar
        seekRow.addView(seekBar)

        val totalTv = TextView(this).apply {
            text = formatMs(mediaDuration)
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        }
        liveTotalTv = totalTv
        seekRow.addView(totalTv)
        root.addView(seekRow)

        // Controls row
        val ctrlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(6f)
            }
        }

        val prevBtn = ControlIconView(this, ControlIconView.KIND_PREV).apply {
            layoutParams = LinearLayout.LayoutParams(dp(38f), dp(34f))
            setOnClickListener {
                hapticTick()
                try { activeController?.transportControls?.skipToPrevious() } catch (_: Throwable) {}
                resetMediaCollapseTimer()
            }
        }

        val playPauseBtn = ControlIconView(
            this,
            if (mediaPlaying) ControlIconView.KIND_PAUSE else ControlIconView.KIND_PLAY
        ).apply {
            layoutParams = LinearLayout.LayoutParams(dp(46f), dp(38f)).apply {
                leftMargin = dp(24f)
                rightMargin = dp(24f)
            }
            setOnClickListener {
                hapticTick()
                try {
                    if (mediaPlaying) {
                        activeController?.transportControls?.pause()
                    } else {
                        activeController?.transportControls?.play()
                    }
                } catch (_: Throwable) {}
                mediaPlaying = !mediaPlaying
                kind = if (mediaPlaying) ControlIconView.KIND_PAUSE else ControlIconView.KIND_PLAY
                invalidate()
                liveEqualizerBig?.isPlaying = mediaPlaying
                resetMediaCollapseTimer()
            }
        }
        livePlayPauseIcon = playPauseBtn

        val nextBtn = ControlIconView(this, ControlIconView.KIND_NEXT).apply {
            layoutParams = LinearLayout.LayoutParams(dp(38f), dp(34f))
            setOnClickListener {
                hapticTick()
                try { activeController?.transportControls?.skipToNext() } catch (_: Throwable) {}
                resetMediaCollapseTimer()
            }
        }

        ctrlRow.addView(prevBtn)
        ctrlRow.addView(playPauseBtn)
        ctrlRow.addView(nextBtn)
        root.addView(ctrlRow)

        return root
    }

    private fun buildTimerSmallView(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(12f), 0)
        }
        val icon = ControlIconView(this, ControlIconView.KIND_TIMER).apply {
            iconColor = 0xFFFF9F0A.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(20f), dp(20f))
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val timeTv = TextView(this).apply {
            text = computeTimerString()
            setTextColor(0xFFFF9F0A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        liveTimerTextSmall = timeTv
        row.addView(icon)
        row.addView(spacer)
        row.addView(timeTv)
        return row
    }

    private fun buildSystemHudView(): View {
        val hud = activeHud ?: SystemHudData("Island", "Ready", 0xFF30D158.toInt(), 0, 100, true)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12f), 0, dp(14f), 0)
        }

        val leftWidget: View = when (hud.hudKind) {
            0 -> BatteryRingView(this).apply {
                levelPct = hud.batteryLevel
                isCharging = hud.isCharging
                ringColor = hud.accentColor
                layoutParams = LinearLayout.LayoutParams(dp(26f), dp(26f))
            }
            1 -> ControlIconView(this, ControlIconView.KIND_BT).apply {
                iconColor = hud.accentColor
                layoutParams = LinearLayout.LayoutParams(dp(24f), dp(24f))
            }
            else -> ControlIconView(this, hud.ringerKind).apply {
                iconColor = hud.accentColor
                layoutParams = LinearLayout.LayoutParams(dp(24f), dp(24f))
            }
        }
        row.addView(leftWidget)

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        row.addView(spacer)

        val rightCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        val t1 = TextView(this).apply {
            text = hud.title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
        }
        val t2 = TextView(this).apply {
            text = hud.subtitle
            setTextColor(hud.accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 1
        }
        rightCol.addView(t1)
        rightCol.addView(t2)
        row.addView(rightCol)
        return row
    }

    private fun buildCallView(): View {
        val item = activeItem ?: return View(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(16f), dp(16f), dp(14f))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val avatar = buildAvatarView(item, sizeDp = 44f)
        topRow.addView(avatar)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12f)
                rightMargin = dp(8f)
            }
        }
        val nameTv = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val subTv = TextView(this).apply {
            text = item.text.ifEmpty { item.appName }
            setTextColor(0xFF30D158.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        textCol.addView(nameTv)
        textCol.addView(subTv)
        topRow.addView(textCol)

        // Decline & Answer round buttons
        val declineAct = item.actions.firstOrNull { it.isNegative } ?: item.actions.firstOrNull()
        val answerAct = item.actions.firstOrNull { it.isPositive } ?: item.actions.getOrNull(1)

        val declineBtn = FrameLayout(this).apply {
            background = roundedBg(0xFFFF453A.toInt(), dpF(21f))
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f)).apply {
                rightMargin = dp(10f)
            }
            val ic = ControlIconView(this@IslandListenerService, ControlIconView.KIND_PHONE_DECLINE).apply {
                layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER)
            }
            addView(ic)
            setOnClickListener {
                hapticTick()
                try { declineAct?.intent?.send() } catch (_: Throwable) {}
                dismissActiveItem()
            }
        }

        val answerBtn = FrameLayout(this).apply {
            background = roundedBg(0xFF30D158.toInt(), dpF(21f))
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f))
            val ic = ControlIconView(this@IslandListenerService, ControlIconView.KIND_PHONE_ACCEPT).apply {
                layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER)
            }
            addView(ic)
            setOnClickListener {
                hapticTick()
                try { answerAct?.intent?.send() } catch (_: Throwable) {}
                dismissActiveItem()
            }
        }

        topRow.addView(declineBtn)
        topRow.addView(answerBtn)
        root.addView(topRow)
        return root
    }

    private fun buildNotifView(): View {
        val item = activeItem ?: return View(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(16f), dp(16f), dp(14f))
        }

        val mainRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val iconView = buildAvatarView(item, sizeDp = 42f)
        mainRow.addView(iconView)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12f)
            }
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleTv = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val appBadgeTv = TextView(this).apply {
            text = item.appName
            setTextColor(item.accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = dp(6f)
            }
        }
        headerRow.addView(titleTv)
        headerRow.addView(appBadgeTv)
        textCol.addView(headerRow)

        if (item.text.isNotEmpty()) {
            val bodyTv = TextView(this).apply {
                text = item.text
                setTextColor(0xFFC8C8D0.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(2f)
                }
            }
            textCol.addView(bodyTv)
        }

        mainRow.addView(textCol)
        root.addView(mainRow)

        if (Prefs.isQuickReplies(this) && item.actions.isNotEmpty()) {
            val actRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(10f)
                }
            }
            item.actions.take(3).forEach { act ->
                val pill = TextView(this).apply {
                    text = act.label
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    background = roundedBg(0xFF262834.toInt(), dpF(14f), dp(1f), 0x33FFFFFF)
                    setPadding(dp(12f), dp(5f), dp(12f), dp(5f))
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        leftMargin = dp(8f)
                    }
                    setOnClickListener {
                        hapticTick()
                        try { act.intent?.send() } catch (_: Throwable) {}
                        dismissActiveItem()
                    }
                }
                actRow.addView(pill)
            }
            root.addView(actRow)
        }

        return root
    }

    private fun buildAvatarView(item: IslandItem, sizeDp: Float): View {
        val sz = dp(sizeDp)
        return ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(dpF(sizeDp / 2f))
            background = roundedBg(0xFF232530.toInt(), dpF(sizeDp / 2f))
            if (item.largeBitmap != null) {
                setImageBitmap(item.largeBitmap)
            } else if (item.icon != null) {
                setPadding(dp(8f), dp(8f), dp(8f), dp(8f))
                setImageDrawable(item.icon)
            } else {
                setPadding(dp(8f), dp(8f), dp(8f), dp(8f))
                try {
                    setImageDrawable(packageManager.getApplicationIcon(packageName))
                } catch (_: Throwable) {}
            }
            layoutParams = LinearLayout.LayoutParams(sz, sz)
        }
    }

    private fun attachGestureHandler(view: View) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var downTime = 0L
        var longPressed = false

        val longPressRunnable = Runnable {
            longPressed = true
            hapticTick()
            handleLongPressGesture()
        }

        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    downTime = SystemClock.elapsedRealtime()
                    longPressed = false
                    handler.postDelayed(longPressRunnable, 480L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        handler.removeCallbacks(longPressRunnable)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPressRunnable)
                    if (!longPressed) {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (dy < -dp(22f) && abs(dy) > abs(dx)) {
                            // Swipe UP -> Dismiss
                            hapticTick()
                            handleSwipeUpDismiss()
                        } else if (abs(dx) > dp(38f) && abs(dx) > abs(dy)) {
                            // Horizontal swipe -> Next/Prev track when in media mode, or dismiss notification
                            hapticTick()
                            if (currentMode == Mode.MEDIA_SMALL || currentMode == Mode.MEDIA_BIG) {
                                try {
                                    if (dx < 0) activeController?.transportControls?.skipToNext()
                                    else activeController?.transportControls?.skipToPrevious()
                                } catch (_: Throwable) {}
                            } else {
                                handleSwipeUpDismiss()
                            }
                        } else if (abs(dx) < touchSlop && abs(dy) < touchSlop &&
                            SystemClock.elapsedRealtime() - downTime < 480L
                        ) {
                            handleTapGesture()
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun handleTapGesture() {
        hapticTick()
        val tapPref = Prefs.getTapAction(this)
        when (currentMode) {
            Mode.IDLE_PILL -> {
                triggerPreview("notif")
            }
            Mode.MEDIA_SMALL -> {
                if (tapPref == 1) {
                    openMediaSessionApp()
                } else {
                    transitionToMode(Mode.MEDIA_BIG, forceRebuild = true)
                    resetMediaCollapseTimer()
                }
            }
            Mode.MEDIA_BIG -> {
                openMediaSessionApp()
            }
            Mode.NOTIF, Mode.CALL -> {
                val item = activeItem
                if (item?.contentIntent != null) {
                    try {
                        item.contentIntent.send()
                    } catch (_: Throwable) {}
                }
                dismissActiveItem()
            }
            Mode.TIMER_SMALL -> {
                try {
                    activeTimerItem?.contentIntent?.send()
                } catch (_: Throwable) {}
            }
            Mode.SYSTEM_HUD -> {
                activeHud = null
                decideNextState()
            }
            Mode.HIDDEN -> {}
        }
    }

    private fun handleLongPressGesture() {
        val lpPref = Prefs.getLongPressAction(this)
        if (lpPref == 2) {
            handleSwipeUpDismiss()
            return
        }
        when (currentMode) {
            Mode.MEDIA_SMALL -> transitionToMode(Mode.MEDIA_BIG, forceRebuild = true)
            Mode.MEDIA_BIG -> transitionToMode(Mode.MEDIA_SMALL, forceRebuild = true)
            Mode.NOTIF, Mode.CALL -> {
                try { activeItem?.contentIntent?.send() } catch (_: Throwable) {}
                dismissActiveItem()
            }
            else -> triggerPreview("music")
        }
    }

    private fun handleSwipeUpDismiss() {
        when (currentMode) {
            Mode.NOTIF, Mode.CALL -> dismissActiveItem()
            Mode.MEDIA_BIG -> transitionToMode(Mode.MEDIA_SMALL, forceRebuild = true)
            Mode.MEDIA_SMALL -> {
                mediaDismissedUntilChange = true
                decideNextState()
            }
            Mode.SYSTEM_HUD -> {
                activeHud = null
                decideNextState()
            }
            Mode.TIMER_SMALL -> {
                activeTimerItem = null
                decideNextState()
            }
            else -> {}
        }
    }

    private fun dismissActiveItem() {
        handler.removeCallbacks(autoDismissRunnable)
        activeItem = notifQueue.removeFirstOrNull()
        if (activeItem != null) {
            scheduleAutoDismiss(activeItem!!.durationMs)
            decideNextState(forceRebuild = true)
        } else {
            decideNextState()
        }
    }

    private fun openMediaSessionApp() {
        try {
            val sa = activeController?.sessionActivity
            if (sa != null) {
                sa.send()
                return
            }
            val pkg = activeController?.packageName
            if (!pkg.isNullOrEmpty()) {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun resetMediaCollapseTimer() {
        handler.removeCallbacks(mediaCollapseRunnable)
        handler.postDelayed(mediaCollapseRunnable, 8_000L)
    }

    private fun updateLiveTickers() {
        if (currentMode == Mode.MEDIA_BIG && mediaDuration > 0L) {
            val pos = if (mediaPlaying) {
                val delta = SystemClock.elapsedRealtime() - mediaLastStateTime
                (mediaPosition + max(0L, delta)).coerceAtMost(mediaDuration)
            } else {
                mediaPosition
            }
            liveSeekLine?.progress = pos.toFloat() / mediaDuration.toFloat()
            liveElapsedTv?.text = formatMs(pos)
            liveTotalTv?.text = formatMs(mediaDuration)
        }
        if (currentMode == Mode.TIMER_SMALL) {
            liveTimerTextSmall?.text = computeTimerString()
        }
    }

    private fun computeTimerString(): String {
        val t = activeTimerItem ?: return "0:00"
        val now = System.currentTimeMillis()
        val diff = if (t.chronometerCountDown || t.whenMs > now) {
            max(0L, t.whenMs - now)
        } else {
            max(0L, now - t.whenMs)
        }
        return formatMs(diff)
    }

    private fun formatMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val m = totalSec / 60L
        val s = totalSec % 60L
        return String.format("%d:%02d", m, s)
    }

    private fun startSpinAnimation(target: View) {
        spinAnimator?.cancel()
        spinAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 9_000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                target.rotation = it.animatedValue as Float
            }
            start()
        }
    }

    private fun hapticTick() {
        if (!Prefs.isHaptics(this)) return
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 29) {
                vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            } else if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createOneShot(14L, 90))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(14L)
            }
        } catch (_: Throwable) {}
    }

    private fun drawableToBitmap(drawable: Drawable?): Bitmap? {
        if (drawable == null) return null
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val w = drawable.intrinsicWidth.coerceAtLeast(64)
        val h = drawable.intrinsicHeight.coerceAtLeast(64)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, w, h)
        drawable.draw(canvas)
        return bmp
    }
}
