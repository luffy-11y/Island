# Island V5 — Android Dynamic Island

Package: `com.example.island`  
Target device profile: Samsung Galaxy A52s / One UI  
Minimum Android: 8.0 (API 26)  
Compile/target SDK: 34  
Build: Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 1.9.24, JDK 17

## Included modules

- Notification-listener based notification cards, queue, app blocklist, privacy mode and notification actions.
- MediaSession-based playback card with artwork, transport controls and seek support.
- Notification chronometer display for apps that publish a proper chronometer notification.
- Call notification actions when the phone/dialer exposes Answer and Decline PendingIntents.
- Battery, Bluetooth/headset and ringer-mode HUDs.
- Cutout/position calibration, scaling, opacity, accent, spring presets and gesture preferences.
- Custom Android Views and spring animations; no Jetpack Compose requirement.

## Important Android limitations

Android does not expose an iOS Live Activities API. Timers can only be displayed when the clock/timer app publishes a notification with chronometer metadata. Answer/decline controls are available only when the incoming-call notification exposes valid action PendingIntents. Some Samsung firmware versions restrict notification access for sideloaded apps; the user may need to allow restricted settings manually.

A third-party overlay cannot perfectly reproduce the system-owned iPhone Dynamic Island or guarantee compatibility with every app, Android skin, lock-screen state, full-screen app or OEM power manager. Media controls depend on apps publishing MediaSession data.

## Build

Open this project with Android Studio, or use the repository's GitHub Actions workflow. Run:

```bash
gradle assembleDebug --no-daemon
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The project retains the debug signing key included in the V4 archive so future debug APKs can update the same installation. Keep that key private if the project is later distributed beyond personal use.
