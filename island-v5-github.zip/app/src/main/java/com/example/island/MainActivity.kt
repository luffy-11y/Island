package com.example.island

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

class MainActivity : Activity() {

    private var overlayBadge: TextView? = null
    private var notifBadge: TextView? = null
    private var batteryBadge: TextView? = null
    private var blockedCountTv: TextView? = null

    private var topDpSlider: SliderRowView? = null
    private var offsetXSlider: SliderRowView? = null
    private var scaleSlider: SliderRowView? = null
    private var springSelector: SegmentedRowView? = null

    private var demoPill: IslandContainerView? = null
    private var demoExpanded = false
    private var demoWidthSpring: SpringAnimation? = null
    private var demoHeightSpring: SpringAnimation? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = 0xFF0A0B10.toInt()
        window.navigationBarColor = 0xFF0A0B10.toInt()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0A0B10.toInt())
            isFillViewport = true
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(18f), dp(16f), dp(36f))
        }

        // 1. Hero Header Card with Interactive Mini Dynamic Island
        content.addView(buildHeroCard())

        // 2. Quick Preview Test Bar
        content.addView(buildSectionTitle("LIVE PREVIEW TESTER"))
        content.addView(buildPreviewBarCard())

        // 3. Setup & Permissions Card (Overlay, Notification Access, Restricted Settings, Battery)
        content.addView(buildSectionTitle("REQUIRED PERMISSIONS"))
        content.addView(buildSetupCard())

        // 4. Master & Camera Cutout Calibration (Galaxy A52s)
        content.addView(buildSectionTitle("GALAXY A52S CUTOUT & POSITION"))
        content.addView(buildPositionCard())

        // 5. Smart Modules & Features
        content.addView(buildSectionTitle("ISLAND MODULES"))
        content.addView(buildModulesCard())

        // 6. Visual Style & Spring Animations
        content.addView(buildSectionTitle("ANIMATIONS & APPEARANCE"))
        content.addView(buildAppearanceCard())

        // 7. Gestures & App Filter
        content.addView(buildSectionTitle("GESTURES & APP FILTER"))
        content.addView(buildGesturesAndAppsCard())

        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionBadges()
        refreshBlockedCount()
        notifyPrefsChanged()
    }

    override fun onDestroy() {
        demoWidthSpring?.cancel()
        demoHeightSpring?.cancel()
        demoWidthSpring = null
        demoHeightSpring = null
        super.onDestroy()
    }

    private fun buildHeroCard(): View {
        val heroBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1A1D30.toInt(), 0xFF101320.toInt(), 0xFF0D0F18.toInt())
        ).apply {
            cornerRadius = dpF(24f)
            setStroke(dp(1f), 0x335E5CE6)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = heroBg
            setPadding(dp(20f), dp(22f), dp(20f), dp(22f))
        }

        // Interactive Mini Dynamic Island Demo Pill inside header
        val pill = IslandContainerView(this).apply {
            cornerRadiusPx = dpF(22f)
            showGlowBorder = true
            glowColor = 0xFF5E5CE6.toInt()
            layoutParams = LinearLayout.LayoutParams(dp(168f), dp(38f))
        }
        demoPill = pill

        val pillRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12f), 0, dp(12f), 0)
        }

        val dot = View(this).apply {
            background = roundedBg(0xFF5E5CE6.toInt(), dpF(8f))
            layoutParams = LinearLayout.LayoutParams(dp(16f), dp(16f))
        }
        val pillLabel = TextView(this).apply {
            text = "Tap me"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val eq = EqualizerView(this, barCount = 4).apply {
            barColor = 0xFF30D158.toInt()
            isPlaying = true
            layoutParams = LinearLayout.LayoutParams(dp(22f), dp(15f))
        }
        pillRow.addView(dot)
        pillRow.addView(pillLabel)
        pillRow.addView(eq)
        pill.addView(
            pillRow,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        pill.setOnClickListener {
            demoExpanded = !demoExpanded
            val targetW = if (demoExpanded) dp(268f).toFloat() else dp(168f).toFloat()
            val targetH = if (demoExpanded) dp(58f).toFloat() else dp(38f).toFloat()
            pillLabel.text = if (demoExpanded) "Island v5 • Galaxy A52s" else "Tap me"

            demoWidthSpring?.cancel()
            demoHeightSpring?.cancel()
            demoWidthSpring = SpringAnimation(FloatValueHolder(pill.width.toFloat())).apply {
                spring = SpringForce(targetW).apply {
                    dampingRatio = 0.58f
                    stiffness = 380f
                }
                addUpdateListener { _, v, _ ->
                    pill.layoutParams.width = v.toInt()
                    pill.requestLayout()
                }
                start()
            }
            demoHeightSpring = SpringAnimation(FloatValueHolder(pill.height.toFloat())).apply {
                spring = SpringForce(targetH).apply {
                    dampingRatio = 0.65f
                    stiffness = 420f
                }
                addUpdateListener { _, v, _ ->
                    pill.layoutParams.height = v.toInt()
                    pill.cornerRadiusPx = v / 2f
                    pill.requestLayout()
                }
                start()
            }
        }
        box.addView(pill)

        val title = TextView(this).apply {
            text = "Island"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(14f)
            }
        }
        box.addView(title)

        val sub = TextView(this).apply {
            text = "Dynamic Island Edition • V5 • Tuned for Galaxy A52s"
            setTextColor(0xFF9898A6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(3f)
            }
        }
        box.addView(sub)

        return box
    }

    private fun buildPreviewBarCard(): View {
        val card = createCardContainer()
        val padBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
        }

        val hint = TextView(this).apply {
            text = "Tap any button below to test how the real Island expands at the top of your screen:"
            setTextColor(0xFFB0B0BC.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        padBox.addView(hint)

        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10f)
            }
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val previews = listOf(
            Triple("Message", "notif", 0xFF5E5CE6.toInt()),
            Triple("Music Player", "music", 0xFF30D158.toInt()),
            Triple("Incoming Call", "call", 0xFF32ADE6.toInt()),
            Triple("Charging HUD", "battery", 0xFF34C759.toInt()),
            Triple("Live Timer", "timer", 0xFFFF9F0A.toInt())
        )

        previews.forEachIndexed { idx, (label, code, color) ->
            val btn = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                background = roundedBg(color, dpF(12f))
                setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx > 0) leftMargin = dp(8f)
                }
                setOnClickListener {
                    sendPreviewBroadcast(code)
                }
            }
            row.addView(btn)
        }

        hsv.addView(row)
        padBox.addView(hsv)
        card.addView(padBox)
        return card
    }

    private fun buildSetupCard(): View {
        val card = createCardContainer()

        // 1. Display over other apps
        val (row1, badge1) = buildPermissionRow(
            title = "1. Display Over Other Apps",
            subtitle = "Required so the black pill can float at the top of your screen"
        ) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
        }
        overlayBadge = badge1
        card.addView(row1)
        card.addView(buildDivider())

        // 2. Notification Access
        val (row2, badge2) = buildPermissionRow(
            title = "2. Notification Access",
            subtitle = "Required to show messages, calls, timers, and music controls"
        ) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Throwable) {
                Toast.makeText(this, "Search 'Notification access' in Settings", Toast.LENGTH_LONG).show()
            }
        }
        notifBadge = badge2
        card.addView(row2)
        card.addView(buildDivider())

        // 3. Unrestricted Battery
        val (row3, badge3) = buildPermissionRow(
            title = "3. Unrestricted Battery",
            subtitle = "Prevents Samsung One UI from putting Island to sleep"
        ) {
            try {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (_: Throwable) {
                openAppInfoScreen()
            }
        }
        batteryBadge = badge3
        card.addView(row3)
        card.addView(buildDivider())

        // Restricted settings helper box for Android 13+
        val helpBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(14f))
        }
        val helpText = TextView(this).apply {
            text = "Tip for Android 13 / 14 (Galaxy A52s): If 'Notification access' is greyed out and says 'Restricted setting', tap the button below to open App Info, tap the 3 dots (⋮) in the top-right corner, and tap 'Allow restricted settings'."
            setTextColor(0xFF9898A6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        helpBox.addView(helpText)

        val appInfoBtn = TextView(this).apply {
            text = "Open App Info (Allow Restricted Settings & Battery)"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF282A38.toInt(), dpF(12f), dp(1f), 0x445E5CE6)
            setPadding(dp(14f), dp(11f), dp(14f), dp(11f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10f)
            }
            setOnClickListener { openAppInfoScreen() }
        }
        helpBox.addView(appInfoBtn)
        card.addView(helpBox)

        return card
    }

    private fun buildPositionCard(): View {
        val card = createCardContainer()

        // Master Enable Toggle
        card.addView(
            buildToggleRow(
                title = "Enable Dynamic Island",
                subtitle = "Master switch to turn the Island overlay on or off",
                initial = Prefs.isEnabled(this)
            ) {
                Prefs.setEnabled(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        // Always-On Idle Pill
        card.addView(
            buildToggleRow(
                title = "Always-On Idle Pill",
                subtitle = "Keep a sleek compact pill around the camera hole even when idle",
                initial = Prefs.isIdlePill(this)
            ) {
                Prefs.setIdlePill(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        // Distance from top slider (-45 to +120 dp)
        val topSlider = SliderRowView(
            context = this,
            title = "Vertical Position (Distance from Top)",
            subtitle = "Use − / + to line the pill up with your Galaxy A52s camera hole (-28 dp is default)",
            minVal = -45,
            maxVal = 120,
            initialVal = Prefs.getTopDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setTopDp(this, v)
            notifyPrefsChanged()
        }
        topDpSlider = topSlider
        card.addView(topSlider)
        card.addView(buildDivider())

        // Horizontal Offset slider (-60 to +60 dp)
        val xSlider = SliderRowView(
            context = this,
            title = "Horizontal Fine-Tune (Left / Right)",
            subtitle = "0 dp is dead-center on the screen",
            minVal = -60,
            maxVal = 60,
            initialVal = Prefs.getOffsetXDp(this),
            unitSuffix = " dp"
        ) { v ->
            Prefs.setOffsetXDp(this, v)
            notifyPrefsChanged()
        }
        offsetXSlider = xSlider
        card.addView(xSlider)
        card.addView(buildDivider())

        // Overall Island Scale slider (80% to 130%)
        val szSlider = SliderRowView(
            context = this,
            title = "Island Size Scale",
            subtitle = "Adjust the overall width and height of the Island",
            minVal = 80,
            maxVal = 130,
            initialVal = Prefs.getScalePct(this),
            unitSuffix = "%"
        ) { v ->
            Prefs.setScalePct(this, v)
            notifyPrefsChanged()
        }
        scaleSlider = szSlider
        card.addView(szSlider)
        card.addView(buildDivider())

        // One-Tap Galaxy A52s Calibration Button
        val presetBox = FrameLayout(this).apply {
            setPadding(dp(16f), dp(12f), dp(16f), dp(14f))
        }
        val presetBtn = TextView(this).apply {
            text = "Reset to Optimal Galaxy A52s Camera Cutout Preset"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF5E5CE6.toInt(), dpF(12f))
            setPadding(dp(14f), dp(11f), dp(14f), dp(11f))
            setOnClickListener {
                Prefs.applyA52sPreset(this@MainActivity)
                topDpSlider?.setValue(Prefs.getTopDp(this@MainActivity), notify = false)
                offsetXSlider?.setValue(Prefs.getOffsetXDp(this@MainActivity), notify = false)
                scaleSlider?.setValue(Prefs.getScalePct(this@MainActivity), notify = false)
                springSelector?.setSelectedIndex(Prefs.getSpringStyle(this@MainActivity), notify = false)
                notifyPrefsChanged()
                sendPreviewBroadcast("notif")
                Toast.makeText(this@MainActivity, "Galaxy A52s preset applied!", Toast.LENGTH_SHORT).show()
            }
        }
        presetBox.addView(presetBtn)
        card.addView(presetBox)

        return card
    }

    private fun buildModulesCard(): View {
        val card = createCardContainer()

        card.addView(
            buildToggleRow(
                title = "Notifications",
                subtitle = "Pop up incoming messages & alerts with app icon and quick actions",
                initial = Prefs.isNotifs(this)
            ) {
                Prefs.setNotifs(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Music & Media Player",
                subtitle = "Live album art, color-matched wave equalizer, seek bar & controls",
                initial = Prefs.isMedia(this)
            ) {
                Prefs.setMedia(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Phone & App Calls",
                subtitle = "Incoming calls with green Answer and red Decline buttons",
                initial = Prefs.isCalls(this)
            ) {
                Prefs.setCalls(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Live Timers & Stopwatches",
                subtitle = "Show live countdown / chronometer from Clock notifications",
                initial = Prefs.isTimers(this)
            ) {
                Prefs.setTimers(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Charging & Battery HUD",
                subtitle = "Animate battery percentage ring when you plug in your charger",
                initial = Prefs.isBattery(this)
            ) {
                Prefs.setBattery(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Headphones & Bluetooth HUD",
                subtitle = "Show connection pill when Galaxy Buds, headphones, or speakers connect",
                initial = Prefs.isBluetooth(this)
            ) {
                Prefs.setBluetooth(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Ringer / Silent / Vibrate HUD",
                subtitle = "Show visual confirmation when switching sound mode",
                initial = Prefs.isRinger(this)
            ) {
                Prefs.setRinger(this, it)
                notifyPrefsChanged()
            }
        )

        return card
    }

    private fun buildAppearanceCard(): View {
        val card = createCardContainer()

        // Spring Physics Selector
        val spRow = SegmentedRowView(
            context = this,
            title = "Spring Animation Physics",
            options = listOf("Bouncy (iOS)", "Balanced", "Snappy"),
            initialIndex = Prefs.getSpringStyle(this)
        ) { idx ->
            Prefs.setSpringStyle(this, idx)
            notifyPrefsChanged()
            sendPreviewBroadcast("notif")
        }
        springSelector = spRow
        card.addView(spRow)
        card.addView(buildDivider())

        // Accent Theme Color Selector
        card.addView(
            SegmentedRowView(
                context = this,
                title = "Accent & Equalizer Color",
                options = listOf("Auto", "Indigo", "Green", "Coral", "Cyan", "White"),
                initialIndex = Prefs.getAccentMode(this)
            ) { idx ->
                Prefs.setAccentMode(this, idx)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        // Notification Display Duration Slider
        card.addView(
            SliderRowView(
                context = this,
                title = "Notification Popup Duration",
                subtitle = "How many seconds a normal notification stays open",
                minVal = 2,
                maxVal = 12,
                initialVal = Prefs.getSeconds(this),
                unitSuffix = " s"
            ) { v ->
                Prefs.setSeconds(this, v)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        // Pill Opacity Slider
        card.addView(
            SliderRowView(
                context = this,
                title = "Pill Background Opacity",
                subtitle = "100% is pure AMOLED black to blend into your camera hole",
                minVal = 75,
                maxVal = 100,
                initialVal = Prefs.getOpacityPct(this),
                unitSuffix = "%"
            ) { v ->
                Prefs.setOpacityPct(this, v)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Subtle Glowing Border",
                subtitle = "Draw a soft color-matched neon rim around the expanded Island",
                initial = Prefs.isGlowBorder(this)
            ) {
                Prefs.setGlowBorder(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Animated Music Equalizer",
                subtitle = "Animate dancing sound bars next to album art",
                initial = Prefs.isEqualizer(this)
            ) {
                Prefs.setEqualizer(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Spinning Vinyl Album Art",
                subtitle = "Slowly rotate album cover on the compact music pill",
                initial = Prefs.isSpinArt(this)
            ) {
                Prefs.setSpinArt(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Notification Action Buttons",
                subtitle = "Show Reply / Mark Read / Dismiss buttons inside notifications",
                initial = Prefs.isQuickReplies(this)
            ) {
                Prefs.setQuickReplies(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Privacy Mode (Hide Message Text)",
                subtitle = "Show sender name only and hide private message body text",
                initial = Prefs.isHideText(this)
            ) {
                Prefs.setHideText(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Auto-Hide in Landscape (Games & Video)",
                subtitle = "Hide the Island when your phone is turned sideways",
                initial = Prefs.isHideLandscape(this)
            ) {
                Prefs.setHideLandscape(this, it)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            buildToggleRow(
                title = "Soft Haptic Feedback",
                subtitle = "Gentle vibration tick when the Island expands or buttons are tapped",
                initial = Prefs.isHaptics(this)
            ) {
                Prefs.setHaptics(this, it)
                notifyPrefsChanged()
            }
        )

        return card
    }

    private fun buildGesturesAndAppsCard(): View {
        val card = createCardContainer()

        card.addView(
            SegmentedRowView(
                context = this,
                title = "Single Tap on Compact Pill",
                options = listOf("Expand Island", "Open App Directly"),
                initialIndex = Prefs.getTapAction(this)
            ) { idx ->
                Prefs.setTapAction(this, idx)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        card.addView(
            SegmentedRowView(
                context = this,
                title = "Long-Press Gesture",
                options = listOf("Open App", "Toggle Expand", "Dismiss"),
                initialIndex = Prefs.getLongPressAction(this)
            ) { idx ->
                Prefs.setLongPressAction(this, idx)
                notifyPrefsChanged()
            }
        )
        card.addView(buildDivider())

        // Per-App Blocklist Picker Row
        val appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            isClickable = true
            setOnClickListener { showAppBlocklistDialog() }
        }

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t1 = TextView(this).apply {
            text = "Per-App Notification Blocklist"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val t2 = TextView(this).apply {
            text = "Choose specific apps that should never pop up on the Island"
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        textCol.addView(t1)
        textCol.addView(t2)
        appRow.addView(textCol)

        val badge = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = roundedBg(0xFF2C2E3E.toInt(), dpF(10f))
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        }
        blockedCountTv = badge
        appRow.addView(badge)
        card.addView(appRow)

        refreshBlockedCount()
        return card
    }

    private fun showAppBlocklistDialog() {
        val pm = packageManager
        val allApps = try {
            pm.getInstalledApplications(0)
                .filter {
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                            pm.getLaunchIntentForPackage(it.packageName) != null
                }
                .filter { it.packageName != packageName }
                .map { info ->
                    val label = try {
                        pm.getApplicationLabel(info).toString()
                    } catch (_: Throwable) {
                        info.packageName
                    }
                    Pair(label, info.packageName)
                }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        } catch (_: Throwable) {
            emptyList()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF151620.toInt())
            setPadding(dp(16f), dp(16f), dp(16f), dp(8f))
        }

        val searchInput = EditText(this).apply {
            hint = "Search installed apps..."
            setHintTextColor(0xFF787884.toInt())
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = roundedBg(0xFF232533.toInt(), dpF(12f))
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            isSingleLine = true
        }
        root.addView(searchInput)

        val listScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(360f)
            ).apply {
                topMargin = dp(10f)
            }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        listScroll.addView(listContainer)
        root.addView(listScroll)

        fun populateApps(query: String) {
            listContainer.removeAllViews()
            val q = query.trim().lowercase()
            val filtered = if (q.isEmpty()) allApps else allApps.filter {
                it.first.lowercase().contains(q) || it.second.lowercase().contains(q)
            }
            filtered.take(80).forEach { (label, pkg) ->
                val itemRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(6f), dp(10f), dp(6f), dp(10f))
                }
                val iconIv = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(34f), dp(34f)).apply {
                        rightMargin = dp(12f)
                    }
                    try {
                        setImageDrawable(pm.getApplicationIcon(pkg))
                    } catch (_: Throwable) {}
                }
                val nameCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val n1 = TextView(this).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                    maxLines = 1
                }
                val n2 = TextView(this).apply {
                    text = pkg
                    setTextColor(0xFF80808C.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    maxLines = 1
                }
                nameCol.addView(n1)
                nameCol.addView(n2)

                val toggle = ToggleView(this).apply {
                    activeColor = 0xFFFF453A.toInt() // Red = Blocked
                    setChecked(Prefs.isAppBlocked(this@MainActivity, pkg), animate = false)
                    onChanged = {
                        Prefs.toggleAppBlocked(this@MainActivity, pkg)
                        refreshBlockedCount()
                        notifyPrefsChanged()
                    }
                }
                itemRow.addView(iconIv)
                itemRow.addView(nameCol)
                itemRow.addView(toggle)
                listContainer.addView(itemRow)
            }
        }

        populateApps("")
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                populateApps(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Block Apps from Island (Red = Blocked)")
            .setView(root)
            .setPositiveButton("Done") { d, _ -> d.dismiss() }
            .show()
    }

    private fun buildSectionTitle(label: String): View {
        return TextView(this).apply {
            text = label
            setTextColor(0xFF7C7F94.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = 0.08f
            setPadding(dp(6f), dp(20f), dp(6f), dp(8f))
        }
    }

    private fun createCardContainer(): LinearLayout {
        // Layered translucent gradient + fine white rim gives the settings
        // surfaces a restrained liquid-glass treatment without depending on
        // third-party blur libraries or breaking older One UI releases.
        val glass = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xF02B3042.toInt(), 0xE91A1E2B.toInt(), 0xF010121B.toInt())
        ).apply {
            cornerRadius = dpF(19f)
            setStroke(dp(1f), 0x36FFFFFF)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass
            elevation = dpF(2f)
            clipToOutline = true
        }
    }

    private fun buildDivider(): View {
        return View(this).apply {
            setBackgroundColor(0x16FFFFFF)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                1
            ).apply {
                leftMargin = dp(16f)
                rightMargin = dp(16f)
            }
        }
    }

    private fun buildToggleRow(
        title: String,
        subtitle: String,
        initial: Boolean,
        onToggle: (Boolean) -> Unit
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(13f), dp(16f), dp(13f))
        }

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(12f)
            }
        }

        val t1 = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val t2 = TextView(this).apply {
            text = subtitle
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        textCol.addView(t1)
        textCol.addView(t2)
        row.addView(textCol)

        val toggle = ToggleView(this).apply {
            setChecked(initial, animate = false)
            onChanged = onToggle
        }
        row.addView(toggle)

        row.setOnClickListener {
            val next = !toggle.isChecked
            toggle.setChecked(next, animate = true)
            onToggle(next)
        }
        return row
    }

    private fun buildPermissionRow(
        title: String,
        subtitle: String,
        onClick: () -> Unit
    ): Pair<View, TextView> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            isClickable = true
            setOnClickListener { onClick() }
        }

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(10f)
            }
        }

        val t1 = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val t2 = TextView(this).apply {
            text = subtitle
            setTextColor(0xFF9898A0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        textCol.addView(t1)
        textCol.addView(t2)
        row.addView(textCol)

        val badge = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        }
        row.addView(badge)
        return Pair(row, badge)
    }

    private fun refreshPermissionBadges() {
        val hasOverlay = Settings.canDrawOverlays(this)
        styleBadge(overlayBadge, hasOverlay, if (hasOverlay) "ON" else "ENABLE")

        val hasNotif = isNotificationServiceEnabled()
        styleBadge(notifBadge, hasNotif, if (hasNotif) "ON" else "ENABLE")

        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val hasBattery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        styleBadge(batteryBadge, hasBattery, if (hasBattery) "ON" else "FIX")
    }

    private fun styleBadge(tv: TextView?, ok: Boolean, label: String) {
        tv ?: return
        tv.text = label
        if (ok) {
            tv.setTextColor(0xFF30D158.toInt())
            tv.background = roundedBg(0x2430D158, dpF(10f), dp(1f), 0x6630D158)
        } else {
            tv.setTextColor(Color.WHITE)
            tv.background = roundedBg(0xFF5E5CE6.toInt(), dpF(10f))
        }
    }

    private fun refreshBlockedCount() {
        val count = Prefs.getBlockedApps(this).size
        blockedCountTv?.text = if (count == 0) "0 Blocked" else "$count Blocked"
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val myComp = ComponentName(this, IslandListenerService::class.java).flattenToString()
        return flat.split(":").any { it.equals(myComp, ignoreCase = true) }
    }

    private fun openAppInfoScreen() {
        try {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (_: Throwable) {}
    }

    private fun notifyPrefsChanged() {
        val intent = Intent(Prefs.ACTION_PREFS_CHANGED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun sendPreviewBroadcast(kind: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please enable '1. Display Over Other Apps' first!",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (!isNotificationServiceEnabled()) {
            Toast.makeText(
                this,
                "Please enable '2. Notification Access' first so the Island service starts!",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val intent = Intent(Prefs.ACTION_PREVIEW).apply {
            setPackage(packageName)
            putExtra(Prefs.EXTRA_PREVIEW_TYPE, kind)
        }
        sendBroadcast(intent)
    }
}
